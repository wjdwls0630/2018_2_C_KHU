#include<iostream>
#include<string>
#include<fstream>
using namespace std;
int main()
{
	string file1, file2;
	cout << "the program appends two files." << endl;
	cout << "Please enter file name of primary file: ";
	cin >> file1;
	ofstream fsAp("file1.txt", ios::out | ios::app | ios::binary);
	fsAp.seekp(ios::end);
	cout << "Please enter file name of secondary file: ";
	cin >> file2;
	ifstream fsIn("file2.txt", ios::in | ios::binary);
	long apndCnt = 0;
	char inChar[1];
	while (fsIn.read(inChar, sizeof(char)))
	{
		fsAp.write(inChar, 1);
		apndCnt++;
	}
	fsAp.close();
	fsIn.close();
	cout << "Append complete: " << apndCnt << " appended to the file." << endl;
	return 0;
}