#include<fstream>
#include<iostream>
using namespace std;
int main()
{
	/*int aInt = 768;
	char aChar = 'A';
	ofstream fsTextOut("data.txt");
	fsTextOut << aInt << aChar;
	fsTextOut.close();

	ofstream fsBinOut("data.bin", ios::out | ios::binary);
	fsBinOut.write((char*)&aInt, sizeof(int));
	fsBinOut.write(&aChar, sizeof(char));
	fsBinOut.close();*/

	ofstream fsOut("LAB13_01.dat", ios::out | ios::binary);
	for (int data = 1; data <= 30; data++)
		fsOut.write((char*)&data, sizeof(int));
	fsOut.close();

	ifstream fsIn("LAB13_01.dat", ios::in | ios::binary);
	int tempInt[1];
	cout << "�����͸� �ϳ��� ���� ���: " << endl;
	while (fsIn.read((char*)&tempInt, sizeof(int)))
		cout << tempInt[0] << endl;
	cout << endl;
	fsIn.close();
	return 0;
}