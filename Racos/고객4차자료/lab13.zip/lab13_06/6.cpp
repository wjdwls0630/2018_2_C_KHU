#include<iostream>
#include<iomanip>
#include<fstream>
using namespace std;
void buildFile(fstream& fsData)
{
	fsData.open("LAB13_06.dat", ios::in | ios::out | ios::trunc | ios::binary);
	for (int i = 1; i <= 10; i++)
	{
		int data = i*i;
		fsData.write((char*)&data, sizeof(int));
	}
}
void printFile(fstream& fsData)
{
	cout << "File contents in sequential order." << endl;
	fsData.seekg(ios::beg);
	int data, recNum = 0;
	while (fsData.read((char*)&data, sizeof(int)))
		cout << "Record" << setw(4) << recNum++ << " ==> " << setw(4) << data << endl;
	fsData.clear();
}
void randomPrint(fstream& fsData)
{
	cout << "\nFile contents int random sequence." << endl;
	int data, randSeek;
	for (int i = 0; i < 10; i++)
	{
		randSeek = rand() % 10;
		fsData.seekg(sizeof(int)*randSeek, ios::beg);
		fsData.read((char*)&data, sizeof(int));
		cout << "Record" << setw(4) << randSeek << " ==> " << setw(4) << data << endl;
	}
}
int main()
{
	fstream fsData;
	buildFile(fsData);
	printFile(fsData);
	randomPrint(fsData);
	return 0;
}