#include<fstream>
#include<iostream>
using namespace std;
int main()
{
	ofstream fsOut("LAB13_03.txt");
	fsOut << "0123456789abcdefghijABCDEFGHIJ!@#$%^&*()" << endl;
	fsOut.close();

	ifstream fsIn("LAB13_03.txt");
	char charAry[10];
	while (fsIn.read(charAry, 10 * sizeof(char)))
	{
		int numRead = fsIn.gcount() / sizeof(char);
		for (int i = 0; i < numRead; i++)
			cout << charAry[i] << " ";
		cout << endl;
	}
	cout << endl;
	fsIn.close();
	return 0;
}