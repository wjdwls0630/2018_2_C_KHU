#include<fstream>
#include<iostream>
using namespace std;
int main()
{
	ofstream fsOut("LAB13_02.dat", ios::out | ios::binary);
	for (int data = 1; data <= 30; data++)
		fsOut.write((char*)&data, sizeof(int));
	fsOut.close();

	ifstream fsIn("LAB13_02.dat", ios::in | ios::binary);
	int intAry[10];
	cout << "�����͸� �ѹ��� ���� ũ�⸸ŭ ���� ���: " << endl;
	while (fsIn.read((char*)&intAry, 10*sizeof(int)))
	{
		int numRead = fsIn.gcount() / sizeof(int);
		for (int i = 0; i < numRead; i++)
			cout << intAry[i] << " ";
		cout << endl;
	}
	cout << endl;
	fsIn.close();
	return 0;
}