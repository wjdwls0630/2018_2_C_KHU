#include<iostream>
using namespace std;
template<class TYPE>
class smartAry
{
protected:
	TYPE* m_ptr;
	int arySize;
public:
	smartAry(int size)
	{
		m_ptr = new TYPE[size];
		arySize = size;
	}
	~smartAry()
	{
		delete[] m_ptr;
	}
	TYPE& operator[](int idx)
	{
		return m_ptr[idx];
	}// �迭�� ���Ҹ� �������� ����
	int GetSize()
	{
		return arySize;
	}
};
template<class TYPE>
class MArray :public smartAry<TYPE>
{
private:
	int nextUnusedIdx;
public:
	MArray(int size)
		: smartAry(size)
	{
		nextUnusedIdx = 0;
	}
	bool isFull()
	{
		if (nextUnusedIdx == arySize)
			return true;
		else
			return false;
	}
	void addElem(TYPE num)
	{
		if (arySize>nextUnusedIdx)
		{
			m_ptr[nextUnusedIdx] = num;
			nextUnusedIdx++;
		}
		else
			cout << "Error : Array overflow" << endl;
	}
	void find(TYPE data)
	{
		int idx = 0;
		while (idx != arySize)
		{
			if (m_ptr[idx] == data)
			{
				cout << "Value at location " << idx << " is : " << data << endl;
				break;
			}
			else
				idx++;
		}
		if (idx == arySize)
			cout << "FAIL! Input " << data << " : Can not found" << endl;
	}
	template<class TYPE> friend void aryPrint(MArray<TYPE>&); // �� ���� ��������!!
};
template<class TYPE>
void aryPrint(MArray<TYPE>& arr)
{
	for (int i = 0; i < arr.GetSize(); i++)
		cout << "\t[" << i << "]" << arr[i];
	cout << endl;
}

int main()
{
	MArray<int> arr1(4);
	for (int i = 0; i < arr1.GetSize(); i++)
		arr1.addElem(i * 5);
	aryPrint(arr1);
	arr1.find(10);
	MArray<double> arr2(4);
	for (int i = 0; i < arr2.GetSize(); i++)
		arr2.addElem((i + 1)*3.14);
	aryPrint(arr2);
	arr2.find(9.41);
	arr2.addElem(1.15);
	return 0;
}