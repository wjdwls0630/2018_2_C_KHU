#include<iostream>
using namespace std;
template <class TYPE>
class smartAry
{
private:
	TYPE* m_ptr;
	int arySize;
public:
	smartAry(int size)
	{
		arySize = size;
		m_ptr = new TYPE[arySize];
	}
	~smartAry()
	{
		delete[] m_ptr;
	}
	TYPE& operator[] (int idx)
	{
		return m_ptr[idx];
	}
	int GetSize()
	{ 
		return arySize;
	}
};
int main()
{
	smartAry<int> arr1(4);
	arr1[0] = 1; arr1[1] = 4;
	for (int i = 0; i < 4; i++)
		cout << arr1[i] << endl;
	smartAry<double> arr2(4);
	arr2[0] = 5.5; arr2[3] = 3.14;
	for (int i = 0; i < 4; i++)
		cout << arr2[i] << endl;
	return 0;
}