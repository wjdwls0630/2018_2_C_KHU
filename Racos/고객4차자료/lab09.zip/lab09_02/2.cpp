#include<iostream>
using namespace std;
template<class TYPE>
TYPE biggest(TYPE arr[], int size)
{
	TYPE temp = arr[0];
	for (int i = 0; i < size; i++)
	{
		if (temp < arr[i])
			temp = arr[i];
		else
			;
	}
	return temp;
}
int main()
{
	int ary1[4] = { 10, 7, 11, 24 };
	cout << "Biggest Value is " << biggest(ary1, 4) << endl;
	float ary2[4] = { 3.5f, 1.12f, 3.14f, 0.25f };
	cout << "Biggest Value is " << biggest(ary2, 4) << endl;
	return 0;
}