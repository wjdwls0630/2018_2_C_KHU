#include<iostream>
using namespace std;
struct sBox
{
	int key;
	int age;
	float salary;
};
template<class TYPE, class KEY>
int search(TYPE arr[], KEY k, int size)
{
	int index = 0;
	while (index < size)
	{
		if (k != arr[index].key)
			index++;
		else
			return index;
	}
	return -1;
}
int main()
{
	int key;
	sBox arr[3] = { { 5, 32, 3.23f },{ 2, 48, 5.18f },{ 7, 60, 6.01f } };
	cin >> key;
	if (search(arr, key, 3) != -1)
	{
		cout << "Key : " << arr[search(arr, key, 3)].key << endl;
		cout << "Age : " << arr[search(arr, key, 3)].age << endl;
		cout << "Salary : " << arr[search(arr, key, 3)].salary << endl;
		cout << "found at location : " << search(arr, key, 3) << endl;
	}
	else
		cout << "Not found" << endl;
	return 0;
}