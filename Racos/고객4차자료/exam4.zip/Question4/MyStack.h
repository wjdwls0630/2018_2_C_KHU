#pragma once
#include<iostream>
#include<list>
using namespace std;
template<class TYPE>
class MyStack
{
private:
	int topIdx;
	list* stackPtr;
public:
	MyStack(int length)
	{
		stackPtr = new list<TYPE>[length];
		topIdx = -1;
	}
	~MyStack()
	{
		delete[] stackPtr;
	}
	void Push(TYPE& t)
	{
		stackPtr[topIdx]->
	}
};