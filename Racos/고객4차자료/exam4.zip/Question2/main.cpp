#include "Apartment.h"
#include "Factory.h"
#include "Store.h"
int main()
{
	Building* pBuild;
	Apartment* tmp_apart = new Apartment();
	Store* tmp_store = new Store();
	Factory* tmp_factory = new Factory();
	tmp_apart->setBuildingData(100, "apart addr", 255);
	tmp_store->setBuildingData(200, "store addr");
	tmp_factory->setBuildingData(300, "fact addr", "company name");
	tmp_apart->showDataAll();
	tmp_store->showDataAll();
	tmp_factory->showDataAll();

	tmp_apart->setBuildingAddress("Building Initial addr");
	tmp_store->setBuildingAddress("Building Initial addr");
	tmp_factory->setBuildingAddress("Building Initial addr");
	tmp_apart->showDataAll();
	tmp_store->showDataAll();
	tmp_factory->showDataAll();

	pBuild = static_cast<Building*>(tmp_apart);
	tmp_apart->setBuildingAddress("Building Initial addr");
	tmp_apart->showDataAll();
	pBuild = static_cast<Building*>(tmp_store);
	tmp_store->setBuildingAddress("Building Initial addr");
	tmp_store->showDataAll();
	pBuild = static_cast<Building*>(tmp_factory);
	tmp_factory->setBuildingAddress("Building Initial addr");
	tmp_factory->showDataAll();
	return 0;
}