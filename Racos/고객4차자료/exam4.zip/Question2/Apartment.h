#pragma once
#include "Building.h"
class Apartment :public Building
{
private:
	int m_household_number;
public:
	void setBuildingType()
	{
		m_build_type = "residence";
	}
	void setBuildingData(int i, string add, int household)
	{
		Building::setBuildingNumber(i);
		Building::setBuildingAddress(add);
		setBuildingType();
		m_household_number = household;
	}
	void showDataAll()
	{
		cout << m_build_number << "/" << m_build_address << "/" << m_build_type << "/" << m_household_number << endl;
	}
};