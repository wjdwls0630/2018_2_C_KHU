#pragma once
#include "Building.h"
class Store : public Building
{
private:
	string m_build_address_registered;
public:
	void setBuildingAddress(string add)
	{
		Building::setBuildingAddress(add);
	}
	void setBuildingType()
	{
		m_build_type = "commerce";
	}
	void setBuildingData(int num, string typ)
	{
		Building::setBuildingNumber(num);
		setBuildingAddress(m_build_address);
		setBuildingType();
		m_build_address_registered = typ;
	}
	void showDataAll()
	{
		cout << m_build_number << "/" << m_build_address << "/" << m_build_type << "/" << m_build_address_registered << endl;
	}
};