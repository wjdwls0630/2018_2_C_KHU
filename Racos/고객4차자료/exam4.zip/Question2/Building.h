#pragma once
#include<iostream>
#include<string>
#include<fstream>
using namespace std;
class Building
{
protected:
	int m_build_number;
	string m_build_address;
	string m_build_type;
public:
	Building() : m_build_address("NULL ADDR"), m_build_type("NULL TYPE") {}
	virtual void setBuildingNumber(int num) { m_build_number = num; }
	virtual void setBuildingAddress(string s) { m_build_address = s; }
	virtual void setBuildingType() { m_build_type = "NULL TYPE"; }
};