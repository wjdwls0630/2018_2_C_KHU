#pragma once
#include "Building.h"
struct SaveProduct
{
	int i;
	string add;
	string typ;
};
class Factory : public Building
{
private:
	string m_build_company;
public:
	void setBuildingType()
	{
		m_build_type = "industry";
	}
	void setBuildingData(int num, string add, string typ)
	{
		m_build_company = typ;
		Building::setBuildingNumber(num);
		Building::setBuildingAddress(add);
		setBuildingType();
	}
	void showDataAll()
	{
		cout << m_build_number << "/" << m_build_address << "/" << m_build_type << "/" << m_build_company << endl;
	}
	void writeFactoryData()
	{
	}
};