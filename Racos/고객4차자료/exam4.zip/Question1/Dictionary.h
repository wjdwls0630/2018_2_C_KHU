#pragma once
#include<iostream>
#include<string>
#include<list>
using namespace std;
class Word
{
private:
	int m_index;
	string m_word;
	string m_word_detail;
public:
	Word(string w, string d)
		: m_word(w), m_word_detail(d), m_index(1)
	{
	}
	void print()
	{
		cout << m_index << "/" << m_word << "/" << m_word_detail << endl;
	}
	bool operator>(Word& w)
	{
		return (m_word > w.m_word);
	}
	bool operator<(Word& w)
	{
		return (m_word < w.m_word);
	}
};
class Dictionary
{
private:
	list<Word> m_wordList;
public:
	Dictionary() {}
	void addWord(string s, string n)
	{
		m_wordList.push_back(Word(s,n));
	}
	void sortDictionary()
	{
		m_wordList.sort();
	}
	void showWord(string s)
	{
		list<Word>::iterator it = m_wordList.begin();
		while (it != m_wordList.end())
		{
			it++;
		}
	}
	void showAllWord()
	{
		list<Word>::iterator it = m_wordList.begin();
		while (it != m_wordList.end())
			(it++)->print();
	}
};