#include<iostream>
#include<exception>
using namespace std;
int main()
{
	cout << "Enter the dividend: ";
	double dividend;
	cin >> dividend;
	cout << "Enter the divisor: ";
	double divisor;
	cin >> divisor;
	try
	{
		cout << dividend / divisor << endl;
	}
	catch (exception& err)
	{
		cout << err.what() << endl;
	}
	return 0;
}