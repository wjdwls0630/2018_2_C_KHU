#include<iostream>
#include<new>
#include<string>
#include<iomanip>
using namespace std;
#define Q 1
#if Q==0
int main()
{
	string s1("This is the string");
	cout << "Testing out_of_range exception\n";
	int position;
	cout << "Input position : ";
	cin >> position;
	try
	{
		cout << "s1(positon) contains : " << s1.at(position) << endl;
 	}
	catch (exception& err)
	{
		cout << err.what() << endl;
	}
	cout << "End of exceptions tests\n";
	return 0;
}
#else
int main()
{
	cout << "Demonstrate memory allocation failure\n" << endl;
	try
	{
		for (int count = 0;; count++)
		{
			double* Arr = new double[1024 * 1024 * 10];
			cout << "count " << count << "Memory allocated successfully\n";
		}
	}
	catch (exception& err)
	{
		cout << "**Error 100 : Program out of memory\n **" << err.what() << endl;	
	}
	cout << "End of exceptions tests\n";
	return 0;
}
#endif