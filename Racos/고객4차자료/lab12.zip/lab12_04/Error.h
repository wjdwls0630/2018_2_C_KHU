#pragma once
#include<iostream>
using namespace std;
class Error
{
public:
	virtual void printMessage()
	{
		cout << "**Error : type Error\n";
	}
};
class Arithmatic :public Error
{
public:
	virtual void printMessage()
	{
		cout << "**Error : type Arithmatic\n";
	}
};
class DivbyZero :public Arithmatic
{
public:
	virtual void printMessage()
	{
		cout << "Error : 100 divisor 0\n";
	}
};
class DivbyNeg :public Arithmatic
{
public:
	virtual void printMessage()
	{
		cout << "**Error : 101 negative divisor\n";
	}
};
class BadOperator :public Arithmatic
{
public:
	virtual void printMessage()
	{
		cout << "**Error : 102 invalid operator\n";
	}
};