#include<iostream>
using namespace std;
int main()
{
	char s1[12] = { 'S','t','r','i', 'n', 'g', ' ', 't', 'e', 's', 't', '\0' };
	cout << "s1: " << s1 << endl;
	s1[6] = 0;
	cout << "s1: " << s1 << endl;
	char s2[12] = "String test";
	cout << "s2: " << s2 << endl;
	cout << "s1\t|\ts2" << endl;
	cout << "_________________" << endl;
	for (int i = 0; i < 12; i++)
		cout << (int)s1[i] << "\t|\t" << (int)s2[i] << endl;
	return 0;
}