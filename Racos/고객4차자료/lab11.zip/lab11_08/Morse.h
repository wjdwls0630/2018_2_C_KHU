#pragma once
#include<iostream>
#include<string>
using namespace std;
class Morse
{
private:
	bool convert(string& str1, int col, string& str2);

public:
	string encode(string& inStr);
	string decode(string& inStr);
};

bool Morse::convert(string& str1, int col, string& str2)
{
	string encDec[27][2] =
	{
		{ "A", ".-#" }, { "B", "-...#" }, { "C", "-.-.#" },
		{ "D", "-..#" }, { "E", ".#" }, { "F", "..-.#" },
		{ "G", "--.#" }, { "H", "....#" }, { "I", "..#" },
		{ "J", ".---#" }, { "K", "-.-#" }, { "L", ".-..#" },
		{ "M", "--#" }, { "N", "-.#" }, { "O", "---#" },
		{ "P", ".--.#" }, { "Q", "--.-#" }, { "R", ".-.#" },
		{ "S", "...#" }, { "T", "-#" }, { "U", "..-#" },
		{ "V", "...-" }, { "W", ".--#" }, { "X", "-..-#" },
		{ "Y", "-.--#" }, { "Z", "--..#" }, { " ", "$$#" }
	};

	bool found = false;
	int row;
	for (row = 0; row<27 && !found; row++)
		found = (str1 == encDec[row][col]);
	if (found)
		str2 = encDec[row - 1][(col + 1) % 2];
	else
		str2 = "";
	return found;
}

string Morse::encode(string& inStr)
{
	string s1;
	string s2;

	string outStr = "";
	bool error = false;
	size_t curr = 0;

	while (curr < inStr.length() && !error)
	{
		s1 = toupper(inStr[curr]);
		error = !convert(s1, 0, s2);
		outStr += s2;
		curr++;
	}

	if (!error)
		return outStr;
	else
		return ("Invalid character in Code\n");
}

string Morse::decode(string& inStr)
{
	string s1;
	string s2;

	string outStr = "";
	bool   error = false;
	size_t curr = 0;
	int    index = 0;

	while (curr < inStr.length() && !error)
	{
		index = inStr.find("#", curr);
		s1 = inStr.substr(curr, index - curr + 1);
		error = !convert(s1, 1, s2);
		outStr += s2;
		curr = index + 1;
	}

	if (!error)
		return outStr;
	else
		return ("Invalid Morse Code\n");
}
