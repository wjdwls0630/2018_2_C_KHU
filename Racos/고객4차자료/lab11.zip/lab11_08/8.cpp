#include "Morse.h"
#define FLUSH while( cin.get() != '\n' )
char menu()
{
	bool validData = true;
	char option;
	cout << "\t\tM E N U \n";
	cout << "\t\tE)  encode \n";
	cout << "\t\tD)  decode \n";
	cout << "\t\tQ)  quit\n";
	do
	{
		cout << "\nEnter option : press return key : ";
		cin >> option;
		FLUSH;
		option = toupper(option);

		if (option == 'E' || option == 'D' || option == 'Q')
			validData = true;
		else
		{
			validData = false;
			cout << "\aEnter only one of the option\n";
			cout << "\tE, D or Q\n";
		}
	} while (!validData);
	return option;
}

string getInput()
{
	string in;
	cout << "\nPlease enter line of text to be coded : \n";
	getline(cin, in);
	return in;
}

void printOutput(string& in, string& out)
{
	cout << "\nThe information entered was: \n	";
	cout << in << endl;
	cout << "The transformed information is \n	";
	cout << out << endl << endl;;
}
int main()
{
	string in;
	string out;
	bool done = false;
	char option;
	Morse mCode;

	while (!done)
	{
		option = menu();
		switch (option)
		{
		case 'E':
		case 'e':
			in = getInput();
			out = mCode.encode(in);
			printOutput(in, out);
			break;
		case 'D':
		case 'd':
			in = getInput();
			out = mCode.decode(in);
			printOutput(in, out);
			break;
		default:
			done = true;
			break;
		}
	}
	return 0;
}