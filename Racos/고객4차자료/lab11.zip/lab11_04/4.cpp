#include <iostream>
#include <string>
using namespace std;
int main()
{
	string str1 = "string convert test.";
	string str2;
	char *ary = new char[str1.length() + 1];
	strcpy(ary, str1.c_str());
	str2 = ary;
	cout << "ary : " << ary << endl;
	cout << "str2: " << str2 << endl;
	delete[] ary;
	return 0;
}