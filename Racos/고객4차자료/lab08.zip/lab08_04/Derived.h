#pragma once
#include "Base.h"
class Derived : public Base
{
private:
	int m_val3;
	int m_val4;
public:
	Derived(int x, int y)
		: Base(x,y), m_val3(x), m_val4(y)
	{}
	Derived(int x, int y, int z, int w)
		: Base(x, y), m_val3(z), m_val4(w)
	{}
	void printSum()
	{
		cout << "[Derived Class]" << m_val3 << " + " << m_val4 << " = " << m_val3 + m_val4 << endl;
	}
};