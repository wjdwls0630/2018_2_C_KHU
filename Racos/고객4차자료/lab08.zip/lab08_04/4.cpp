#include "Derived.h"
int main()
{
	cout << "[Upcasting Example]" << endl << endl;
	Base* basePtr = new Base(10, 20);
	Derived* derPtr = new Derived(30, 50);
	basePtr->printSum();
	derPtr->printSum();
	basePtr = static_cast<Base*>(derPtr); // upcasting expression
	cout << "After upcasting / Derived -> Base.." << endl;
	basePtr->printSum();
	derPtr->printSum();
	cout << endl << "[Downcasting Example1]" << endl << endl;
	Base* basePtr2 = new Derived(10, 20);
	Derived* derPtr2 = new Derived(30, 50);
	basePtr2->printSum();
	derPtr2->printSum();
	derPtr2 = static_cast<Derived*>(basePtr2); // downcasting expression
	cout << "After upcasting / Derived -> Base.." << endl;
	basePtr2->printSum();
	derPtr2->printSum();
	cout << endl << "[Downcasting Example2]" << endl << endl;
	Base* basePtr3 = new Base(10, 20);
	Derived* derPtr3 = new Derived(30, 50);
	basePtr3->printSum();
	derPtr3->printSum();
	derPtr3 = static_cast<Derived*>(basePtr3);
	cout << "After upcasting / Derived -> Base.." << endl;
	basePtr3->printSum();
	derPtr3->printSum();
	cout << "basePtr3�� Base�� ����Ű�� �־�̴�." << endl;
	return 0;
}