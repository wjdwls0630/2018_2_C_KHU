#pragma once
#include<iostream>
using namespace std;
class Base
{
protected:
	int m_Num1;
	int m_Num2;
public:
	Base(int a, int b)
		: m_Num1(a), m_Num2(b)
	{}
	void printSum()
	{
		cout << "[Base Class]" << m_Num1 << " + " << m_Num2 << " = " << m_Num1 + m_Num2 << endl;
	}
};