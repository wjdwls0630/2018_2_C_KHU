#pragma once
#include<iostream>
using namespace std;
class Base
{
protected:
	int m_Num1;
	int m_Num2;
public:
	virtual void setNum(int, int) = 0;
	virtual void printSum() = 0;
};