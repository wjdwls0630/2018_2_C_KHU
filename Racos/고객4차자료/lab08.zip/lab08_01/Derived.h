#pragma once
#include "Base.h"
class Derived : public Base
{
public:
	virtual void setNum(int x, int y)
	{
		m_Num1 = x;
		m_Num2 = y;
	}
	virtual void printSum()
	{
		cout << "�� ���� ���� " << m_Num1 + m_Num2 << "�Դϴ�." << endl;
	}
};