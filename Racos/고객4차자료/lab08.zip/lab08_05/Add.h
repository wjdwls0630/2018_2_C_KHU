#pragma once
#include<iostream>
using namespace std;
class Add
{
protected:
	double result;
public:
	Add(double r)
		: result(r)
	{}
	void add_Result()
	{
		cout << "Add result is : " << result << endl;
	}
};