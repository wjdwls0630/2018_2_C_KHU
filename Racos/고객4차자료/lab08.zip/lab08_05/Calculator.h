#pragma once
#include "Add.h"
#include "Subtract.h"
class Calculator : public Add, public Subtract
{
public:
	Calculator(double a, double b)
		: Add(a+b), Subtract(a-b)
	{}
};