#include "Calculator.h"
int main()
{
	Calculator calc(12.34, 56.78);
	calc.add_Result();
	calc.subtract_Result();
	return 0;
}