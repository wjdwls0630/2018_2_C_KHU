#pragma once
#include<iostream>
using namespace std;
class Subtract
{
protected:
	double result;
public:
	Subtract(double r)
		: result(r)
	{}
	void subtract_Result()
	{
		cout << "Subtract result is : " << result << endl;
	}
};