#pragma once
#include "Score.h"
class Student
{
protected:
	char* m_name;
	int m_ID;
	Score m_score;
public:
	Student()
		: m_score(0,0,0,0)
	{}
	Student(char* name, int id, Score sc)
		: m_score(sc.getScore())
	{
		m_ID = id;
		m_name = new char[strlen(name) + 1];
		strcpy(m_name, name);
	}
	~Student()
	{
		delete[] m_name;
	}
	void setVal(char* name, int id, Score sc)
	{
		m_ID = id;
		m_name = new char[strlen(name) + 1];
		strcpy(m_name, name);
		m_score = sc.getScore();
	}
	void printVal()
	{
		cout << "Name : " << m_name << endl;
		cout << "ID : " << m_ID << endl;
		m_score.printScore();
	}
};