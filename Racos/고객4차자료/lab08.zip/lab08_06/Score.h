#pragma once
#include<iostream>
using namespace std;
class Score
{
protected:
	int kor, eng, math, sci;
public:
	Score(int k, int e, int m, int s)
		: kor(k), eng(e), math(m), sci(s)
	{}
	void setScore(int k, int e, int m, int s)
	{
		kor = k;
		eng = e;
		math = m;
		sci = s;
	}
	Score getScore()
	{
		this->kor = Score::kor;
		this->eng = Score::eng;
		this->math = Score::math;
		this->sci = Score::sci;
		return *this;
	}
	void printScore()
	{
		cout << "Score<KOR, ENG, MATH, SCI> : " << kor << ", " << eng << ", " << math << ", " << sci << endl;
	}
};