#include "Student.h"
int main()
{
	Score chrisScore(50, 70, 100, 90);
	Score jillScore(100, 100, 70, 80);
	Score christoperScore = chrisScore.getScore();
	Student std1("Chris", 2005310924, chrisScore);
	std1.printVal();
	cout << endl;
	Student std2("Jill", 2007310477, jillScore);
	Student std3;
	std3.setVal("Christopher", 2005310924, christoperScore);
	std2.printVal();
	cout << endl;
	std3.printVal();
	return 0;
}