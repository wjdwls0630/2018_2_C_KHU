#pragma once
#include<iostream>
using namespace std;
class Polygons
{
protected:
	int area;
	int perimeter;
public:
	virtual void printArea() = 0;
	virtual void printPerimeter() = 0;
};