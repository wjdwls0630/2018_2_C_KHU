#include<iostream>
using namespace std;
template<class TYPE>
TYPE summation(TYPE a, TYPE b)
{
	return a + b;
}
template<class TYPE>
TYPE multiply(TYPE a, TYPE b)
{
	return a*b;
}
int main()
{
	int x, y;
	float a, b;
	cin >> x >> y;
	cout << "int type" << endl;
	cout << summation(x, y) << endl;
	cout << multiply(x, y) << endl;
	cin >> a >> b;
	cout << "float type" << endl;
	cout << summation(a,b) << endl;
	cout << multiply(a,b) << endl;
	return 0;
}