#include<iostream>
using namespace std;
template<class TYPE>
TYPE summation(TYPE x, TYPE y)
{
	return x + y;
}
template<class TYPE>
TYPE multiply(TYPE a, TYPE b)
{
	return a*b;
}
class Fraction
{
private:
	int numerator;
	int denominator;
public:
	Fraction(int num, int den) :numerator(num), denominator(den) {}
	void print() { cout << numerator / gcd(numerator, denominator) << "/" << denominator / gcd(numerator, denominator) << endl; }
	Fraction& operator+ (Fraction& fr)
	{
		numerator = fr.numerator*denominator+fr.denominator*numerator;
		denominator *= fr.denominator;
		return *this;
	}
	Fraction& operator* (Fraction& fr)
	{
		numerator *= fr.numerator;
		denominator *= fr.denominator;
		return *this;
	}
	int gcd(int p, int q)
	{
		if (q == 0) return p;
		return gcd(q, p % q);
	}
};
Fraction summation(Fraction& fr1, Fraction& fr2)
{
	return fr1 + fr2;
}
Fraction multiply(Fraction& fr1, Fraction& fr2)
{
	return fr1 * fr2;
}
int main()
{
	Fraction fr1(3, 4);
	Fraction fr2(4, 5);
	Fraction answer = fr1 + fr2;
	Fraction answer2 = fr1*fr2;
	Fraction answer3 = summation(fr1,fr2);
	Fraction answer4 = multiply(fr1,fr2);
	cout << "By overloading +: ";
	answer.print();
	cout << "By overloading *: ";
	answer2.print();
	cout << "By using specialized function: ";
	answer3.print();
	cout << "By using specialized function: ";
	answer4.print();
	return 0;
}