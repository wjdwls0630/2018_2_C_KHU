#include "shape.h"
void Shape::setvalues(int x, int y)
{
	width = x;
	height = y;
}
int Shape::area()
{
	return width*height;
}