#include "Rectangle.h"
int Rectangle::area()
{
	return width*height;
}