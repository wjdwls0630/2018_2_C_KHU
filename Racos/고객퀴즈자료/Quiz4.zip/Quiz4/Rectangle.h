#pragma once
#include "shape.h"
class Rectangle : public Shape
{
public:
	int area();
};