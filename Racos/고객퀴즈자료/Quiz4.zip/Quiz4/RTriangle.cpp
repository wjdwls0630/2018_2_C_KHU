#include "RTriangle.h"
int RTriangle::area()
{
	return width*height*0.5;
}