#pragma once
#include "shape.h"
class RTriangle : public Shape
{
public:
	int area();
};