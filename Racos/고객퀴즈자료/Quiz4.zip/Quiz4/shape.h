#pragma once
#include<iostream>
using namespace std;
class Shape
{
protected:
	int width;
	int height;
public:
	void setvalues(int, int);
	virtual int area();
};