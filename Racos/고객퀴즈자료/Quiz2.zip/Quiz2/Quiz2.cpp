#include<iostream>
using namespace std;
int* getSum(int a[], int b[], int asize, int bsize)
{
	if (asize <= bsize)
	{
		int* answer = new int[bsize];
		for (int i = 0; i < asize; i++)
			*(answer + i) = *(a + i) * *(b + i);
		return answer;
		delete[] answer;
	}
	else
	{
		int* answer = new int[asize];
		for (int i = 0; i < bsize; i++)
			answer[i] = a[i] * b[i];
		return answer;
		delete[] answer;
	}
}
void putNum(int a[], int size)
{
	cout << "Enter the numbers: ";
	for (int i = 0; i < size; i++)
		cin >> a[i];
}
int main()
{
	int asize, bsize;
	cout << "How namy numbers?: ";
	cin >> asize;
	int* pa = new int[asize];
	putNum(pa, asize);
	cout << "How many numbers?: ";
	cin >> bsize;
	int* pb = new int[bsize];
	putNum(pb, bsize);
	int* pc = getSum(pa, pb, asize, bsize);
	int fsize = asize > bsize ? bsize : asize;
	cout << "The sum of arrays is: ";
	for (int i = 0; i < fsize; i++)
		cout << *(pc + i) << " ";
	cout << endl;
	delete[] pa;
	delete[] pb;
	return 0;
}