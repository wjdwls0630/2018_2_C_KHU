#pragma once
#include "Lecture.h"
class Student
{
protected:
	static int lecnum;
	char* m_name;
	int m_ID;
	Lecture* leclist;
public:
	Student(char* name, int id, int num)
	{
		m_ID = id;
		leclist = new Lecture[num];
		m_name = new char[strlen(name) + 1];
		strcpy(m_name, name);
	}
	~Student()
	{
		delete[] leclist;
		delete[] m_name;
	}
	void printVal()
	{
		cout << "Name : " << m_name << endl;
		cout << "ID : " << m_ID << endl;
		for (int i = 0; i < lecnum; i++)
		{
			leclist[i].printName();
			leclist[i].printScore();
		}
	}
	void addLecture(char* n, int s)
	{
		leclist[lecnum].getName(n);
		leclist[lecnum].getScore(s);
		lecnum++;
	}
};