#pragma once
#include<iostream>
using namespace std;
class Lecture
{
protected:
	char* name;
	int score;
public:
	Lecture()
		: score(0)
	{}
	void getName(char*n)
	{
		name = new char[strlen(n) + 1];
		strcpy(name, n);
	}
	void getScore(int s)
	{
		score = s;
	}
	void printName()
	{
		cout << name << endl;
	}
	void printScore()
	{
		cout << score << endl;
	}
};