#include "Lecture.h"
#include "Student.h"
int Student::lecnum = 0;
int main()
{
	int num;
	cin >> num;
	Student std("Ed",2014103969,num);
	char* list = new char[100];
	int score;
	for (int i = 0; i < num; i++)
	{
		cin >> list;
		cin >> score;
		std.addLecture(list, score);
	}
	std.printVal();
	delete[] list;
	return 0;
}