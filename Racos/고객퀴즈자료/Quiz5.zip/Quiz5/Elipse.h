#pragma once
#include "Polygons.h"
class Elipse : public Polygons
{
protected:
	int a;
	int b;
public:
	Elipse(int x, int y)
		: a(x), b(y)
	{}
	void printArea()
	{
		area = PI*a*b;
		cout << "Area of Elipse: " << area << endl;
	}
	void printPerimeter()
	{
		perimeter = PI*(5 * (a + b) / 4 - a*b / (a + b));
		cout << "Perimeter of Elipse: " << perimeter << endl;
	}
};