#pragma once
#include "Polygons.h"
class RegularHexagon : public Polygons
{
protected:
	int a;
public:
	RegularHexagon(int x)
		: a(x)
	{}
	void printArea()
	{
		area = 3*sqrt(3)/2*pow(a,2);
		cout << "Area of RegularHexagon: " << area << endl;
	}
	void printPerimeter()
	{
		perimeter = 6*a;
		cout << "Perimeter of RegularHexagon: " << perimeter << endl;
	}
};