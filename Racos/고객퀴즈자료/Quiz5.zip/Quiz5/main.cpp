#include "Elipse.h"
#include "RegularHexagon.h"
#include "RegularPentagon.h"
int main()
{
	Polygons* poly[3] = { new Elipse(3,4), new RegularHexagon(5), new RegularPentagon(6) };
	for (int i = 0; i < 3; i++)
	{
		poly[i]->printArea();
		poly[i]->printPerimeter();
		cout << endl;
	}
	for (int i = 0; i < 3; i++)
		delete poly[i];
	return 0;
}