#pragma once
#include "Polygons.h"
class RegularPentagon : public Polygons
{
protected:
	int a;
public:
	RegularPentagon(int x)
		: a(x)
	{}
	void printArea()
	{
		area = sqrt(25+10*sqrt(5))*pow(a, 2);
		cout << "Area of Pentagon: " << area << endl;
	}
	void printPerimeter()
	{
		perimeter = 6 * a;
		cout << "Perimeter of Pentagon: " << perimeter << endl;
	}
};