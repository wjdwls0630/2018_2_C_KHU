#pragma once
#include<iostream>
using namespace std;
#define PI 3.14
class Polygons
{
protected:
	double area;
	double perimeter;
public:
	virtual void printArea() = 0;
	virtual void printPerimeter() = 0;
};