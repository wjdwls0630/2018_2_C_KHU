#pragma once
#include<iostream>
#include<exception>
using namespace std;
class Exception
{
public:
	virtual const char* what() const throw()
	{
		return "**Error : type Error\n";
	}
};
class Arithmatic :public Exception
{
public:
	virtual const char* what() const throw()
	{
		return "**Error : type Arithmatic\n";
	}
};
class DivbyZero :public Arithmatic
{
public:
	virtual const char* what() const throw()
	{
		return "**Error : 100 divisor 0\n";
	}
};
class DivbyNeg :public Arithmatic
{
public:
	virtual const char* what() const throw()
	{
		return "**Error : 101 negative divisor\n";
	}
};
class BadOperator :public Arithmatic
{
public:
	virtual const char* what() const throw()
	{
		return "**Error : 102 invalid operator\n";
	}
};