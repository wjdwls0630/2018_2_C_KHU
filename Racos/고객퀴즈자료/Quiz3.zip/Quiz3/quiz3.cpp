#include<iostream>
#include "KHULecture.h"
using namespace std;
int main()
{
	KHULecture khu1;
	khu1.print();
	KHULecture khu2("ProgBasics", "CSE102");
	khu2.print();
	khu2.setName("ComArchitect");
	khu2.setCode("CSE102");
	khu2.setStudent(60);
	khu2.print();
	return 0;
}