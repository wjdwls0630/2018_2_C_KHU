class KHULecture
{
private:
	char* lecname;
	char lecCode[10];
	int nStudents;
public:
	KHULecture();
	KHULecture(char* name, char code[]);
	~KHULecture();
	void setName(char* anothername);
	void setCode(char c[]);
	void setStudent(int num);
	void print();
};