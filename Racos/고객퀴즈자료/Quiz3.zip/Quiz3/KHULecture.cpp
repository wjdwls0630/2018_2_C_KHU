#include<iostream>
#include "KHULecture.h"
using namespace std;
KHULecture::KHULecture()
{
	lecname = new char[20];
	strcpy(lecname, "genericLecture");
	strcpy(lecCode, "CSE101");
	nStudents = 0;
}
KHULecture::KHULecture(char* name, char code[])
{
	lecname = new char[20];
	strcpy(lecname, name);
	strcpy(lecCode, code);
	nStudents = 0;
}
KHULecture::~KHULecture()
{
	delete lecname;
}
void KHULecture::setName(char* anothername)
{
	strcpy(lecname, anothername);
}
void KHULecture::setCode(char c[])
{
	strcpy(lecCode,c);
}
void KHULecture::setStudent(int num)
{
	nStudents = num;
}
void KHULecture::print()
{
	cout << "Class name: " << lecname << endl;
	cout << "Class code: " << lecCode << endl;
	cout << "Num of students: " << nStudents << endl;
}