#include<iostream>
#include<vector>
#include<list>
#include<string>
using namespace std;
#define SOL 1 // list, vector ������ ����� ���� ������.
class Lecture
{
private:
	string SubjectName;
	int score;

public:
	Lecture(string SN, int s) : SubjectName(SN), score(s) {}
	void print()
	{
		cout << SubjectName << ", " << "Score: " << score << endl;
	}
};
#if SOL==1 // vector�� �̿��Ͽ� �������� ���
int main()
{
	vector<Lecture> v;
	int num;
	cout << "How many subjects?: ";
	cin >> num;
	cout << "Please enter the name of subject and scores for " << num << " times." << endl;
	cout << "If you finish putting the subject's name, please put '/' at the end of subject's name. Then put the score." << endl;
	int score;
	string subject;
	for (int i = 0; i < num; i++)
	{
		getline(cin, subject, '/');
		cin >> score;
		v.push_back(Lecture(subject, score));
	}
	vector<Lecture>::iterator it = v.begin();
	while (it != v.end())
		(it++)->print();
	return 0;
}
#else // list�� �̿��Ͽ� �������� ���
int main()
{
	list<Lecture> l;
	int num;
	cout << "How many subjects?: ";
	cin >> num;
	cout << "Please enter the name of subject and scores for " << num << " times." << endl;
	cout << "If you finish putting the subject's name, please put '/' at the end of subject's name. Then put the score." << endl;
	int score;
	string subject;
	for (int i = 0; i < num; i++)
	{
		getline(cin, subject, '/');
		cin >> score;
		l.push_back(Lecture(subject, score));
	}
	list<Lecture>::iterator it = l.begin();
	while (it != l.end())
		(it++)->print();
	return 0;
}
#endif