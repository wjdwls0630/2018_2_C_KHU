#include "Rectangle.h"
void initializer(Rectangle& r, int w = 0, int h = 0)
{
	r.width = w;
	r.height = h;
}
void store(Rectangle& r, int w, int h)
{
	r.width = w;
	r.height = h;
}
void printArea(Rectangle& r)
{
	cout << r.width * r.height << endl;
}
int main()
{
	Rectangle arrRect[3];
	initializer(arrRect[0], 3, 5);
	initializer(arrRect[1], 2, 2);
	initializer(arrRect[2]);
	store(arrRect[2], 5, 5);
	for (int i = 0; i < 3; i++)
	{
		cout << i << " : ";
		printArea(arrRect[i]);
	}
	return 0;
}