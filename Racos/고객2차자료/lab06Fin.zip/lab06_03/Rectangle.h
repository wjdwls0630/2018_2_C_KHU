#pragma once
#include<iostream>
using namespace std;
struct Rectangle
{
	int width;
	int height;
};