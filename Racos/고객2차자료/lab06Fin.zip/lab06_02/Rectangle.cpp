#include "Rectangle.h"
Rectangle::Rectangle()
	: width(0), height(0)
{}
Rectangle::Rectangle(int w, int h)
	: width(w), height(h)
{}
void Rectangle::store(int w, int h)
{
	width = w;
	height = h;
}
void Rectangle::printArea()
{
	cout << "Area = " << width*height << endl;
}