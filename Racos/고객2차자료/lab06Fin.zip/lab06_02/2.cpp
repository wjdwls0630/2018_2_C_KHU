#include "Rectangle.h"
int main()
{
	Rectangle arrRect[3] = { Rectangle(3,5), Rectangle(2,2), Rectangle() };
	arrRect[2].store(5, 5);
	for (int i = 0; i < 3; i++)
	{
		cout << i << " : ";
		arrRect[i].printArea();
	}
	return 0;
}