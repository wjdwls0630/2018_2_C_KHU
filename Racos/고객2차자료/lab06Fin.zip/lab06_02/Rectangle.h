#pragma once
#include<iostream>
using namespace std;
class Rectangle
{
private:
	int width;
	int height;
public:
	Rectangle();
	Rectangle(int, int);
	void store(int, int);
	void printArea();
};