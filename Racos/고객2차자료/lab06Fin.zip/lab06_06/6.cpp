#include<iostream>
using namespace std;
typedef int* PINT;
typedef int INT;
typedef unsigned long U32;
typedef unsigned short U16;
typedef unsigned char U8;
int main()
{
	PINT pInt = new INT[3];
	U32 uA = -1;
	U16 uB = -1;
	U8 uC = -1;
	pInt[0] = uA;
	pInt[1] = uB;
	pInt[2] = uC;
	cout << "U32's -1 : " << pInt[0] << endl;
	cout << "U16's -1 : " << pInt[1] << endl;
	cout << "U8's -1 : " << pInt[2] << endl;
	delete pInt;
	return 0;
}