#include<iostream>
using namespace std;
enum months{JAN=1,FEB,MAR,APR,MAY,JUN,JUL,AUG,SEP,OCT,NOV,DEC};
bool isLeapYear(int y)
{
	if (y % 4 == 0 && (y % 100 != 0) || (y % 400 == 0))
		return true;
	else
		return false;
}
int main()
{
	int y, m, d;
	cout << "Input Year: ";
	cin >> y;
	cout << "Input Month: ";
	cin >> m;
	switch (m)
	{
	case JAN:
	case MAR:
	case MAY:
	case JUL:
	case AUG:
	case OCT:
	case DEC:
		d = 31;
		break;
	case APR:
	case JUN:
	case SEP:
	case NOV:
		d = 30;
		break;
	case FEB:
		if (isLeapYear(y) == true)
			d = 29;
		else
			d = 28;
		break;
	}
	cout << y << "���� " << m << "������ �ϼ��� " << d << "���Դϴ�." << endl;
	return 0;
}