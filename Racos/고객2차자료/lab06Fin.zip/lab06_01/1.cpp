#include "Fraction.h"
int main()
{
	Fraction* pFr;
	pFr = new Fraction;
	pFr->store(2, 3);
	pFr->print();
	delete pFr;
	return 0;
}