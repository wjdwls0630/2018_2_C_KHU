#pragma once
#include<iostream>
using namespace std;
class Fraction
{
private:
	int* pnumer;
	int* pdenom;
public:
	Fraction();
	~Fraction();
	void store(int, int);
	void print();
};