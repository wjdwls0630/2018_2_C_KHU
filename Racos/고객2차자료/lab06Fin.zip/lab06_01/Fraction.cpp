#include "Fraction.h"
Fraction::Fraction()
{
	pnumer = new int;
	pdenom = new int;
}
Fraction::~Fraction()
{
	delete pnumer;
	delete pdenom;
}
void Fraction::store(int num, int denom)
{
	*pnumer = num;
	*pdenom = denom;
}
void Fraction::print()
{
	cout << *pnumer << "/" << *pdenom << endl;
}