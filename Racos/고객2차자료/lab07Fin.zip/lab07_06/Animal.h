#pragma once
#include<iostream>
using namespace std;
class Animal
{
public:
	Animal();
	void talkStaticBinding();
	virtual void talkDynamicBinding();
};