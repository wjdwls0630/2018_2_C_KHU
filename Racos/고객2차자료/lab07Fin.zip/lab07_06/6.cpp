#include "Cat.h"
#include "Dog.h"
int main()
{
	Animal* animalPtr1 = new Dog();
	Animal* animalPtr2 = new Cat();
	animalPtr1->talkStaticBinding();
	animalPtr1->talkDynamicBinding();
	animalPtr2->talkStaticBinding();
	animalPtr2->talkDynamicBinding();
	delete animalPtr1;
	delete animalPtr2;
	return 0;
}