#include "Square.h"
Square::Square(int i)
	: side(i)
{}
void Square::calArea()
{
	area = (int)pow(side, 2);
}
void Square::calPerimeter()
{
	perimeter = 4 * side;
}