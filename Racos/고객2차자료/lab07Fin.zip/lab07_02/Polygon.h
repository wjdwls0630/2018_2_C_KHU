#pragma once
#include<iostream>
using namespace std;
class Polygon
{
protected:
	int area;
	int perimeter;
public:
	void printArea();
	void printPerimeter();
};