#pragma once
#include "Polygon.h"
class Square : public Polygon
{
protected:
	int side;
public:
	Square(int);
	void calArea();
	void calPerimeter();
};