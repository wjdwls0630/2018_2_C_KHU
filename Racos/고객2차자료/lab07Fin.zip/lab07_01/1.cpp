#include<iostream>
using namespace std;
class Base
{
private:
	int m_num1;
	int m_num2;
public:
	void setNum(int val1, int val2)
	{
		m_num1 = val1;
		m_num2 = val2;
	}
	inline void printSum();
};
class Derived : public Base
{

};
void Base::printSum()
{
	cout << "�� ���� ���� " << m_num1 + m_num2 << "�Դϴ�." << endl;
}
int main()
{
	Derived der;
	int num1, num2;
	cout << "�� ���� �Է��ϼ��� : " << endl;
	cin >> num1 >> num2;
	der.setNum(num1, num2);
	der.printSum();
}