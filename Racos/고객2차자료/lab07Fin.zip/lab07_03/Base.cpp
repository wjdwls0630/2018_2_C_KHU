#include "Base.h"
void Base::set(int x)
{
	i = x;
}
int Base::ret()
{
	return i;
}