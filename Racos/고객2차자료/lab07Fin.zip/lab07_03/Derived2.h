#pragma once
#include "Derived1.h"
class Derived2 : public Derived1
{
private:
	int k;
public:
	void initialize(int,int,int);
	void printVal();
};