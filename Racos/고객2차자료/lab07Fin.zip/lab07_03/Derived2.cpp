#include "Derived2.h"
void Derived2::initialize(int x, int y, int z)
{
	set(x);
	j = y;
	k = z;
}
void Derived2::printVal()
{
	cout << "�Է��� ���� " << ret() << ", " << j << ", " << k << " �Դϴ�." << endl;
}