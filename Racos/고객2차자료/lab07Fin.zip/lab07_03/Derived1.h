#pragma once
#include "Base.h"
class Derived1: public Base
{
protected:
	int j;
};