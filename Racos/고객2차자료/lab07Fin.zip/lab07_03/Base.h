#pragma once
#include<iostream>
using namespace std;
class Base
{
private:
	int i;
public:
	void set(int);
	int ret();
};