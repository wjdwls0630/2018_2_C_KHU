#pragma once
#include "Polygon.h"
class Rectangle : public Polygon
{
protected:
	int sideA;
	int sideB;
public:
	Rectangle(int, int);
	void calArea();
	void calPerimeter();
	void printArea();
	void printPerimeter();
};