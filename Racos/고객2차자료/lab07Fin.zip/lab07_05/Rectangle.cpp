#include "Rectangle.h"
Rectangle::Rectangle(int x, int y)
	: sideA(x), sideB(y)
{}
void Rectangle::calArea()
{
	area = sideA*sideB;
}
void Rectangle::calPerimeter()
{
	perimeter = 2 * (sideA + sideB);
}
void Rectangle::printArea()
{
	cout << "���簢�� : ";
	Polygon::printArea();
}
void Rectangle::printPerimeter()
{
	cout << "���簢�� : ";
	Polygon::printPerimeter();
}