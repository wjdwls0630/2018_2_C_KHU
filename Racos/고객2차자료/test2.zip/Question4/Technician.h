#pragma once
#include "Employee.h"
class Technician : public Employee
{
public:
	Technician(char* name, TYPE t, int a, int s, int ab, int tst)
		: Employee(name, t, a, s, ab, tst)
	{}
	void caltotal()
	{
		if (type == temployee)
			total = (float)stance*0.2f + ability*0.3f + test*0.5f;
		else if (type == tofficial)
			total = (float)stance*0.1f + ability*0.4f + test*0.5f;
		if (total >= 90)
			rank = 'A';
		else if (total >= 80 && total < 90)
			rank = 'B';
		else if (total >= 70 && total < 80)
			rank = 'C';
		else if (total >= 60 && total < 70)
			rank = 'D';
		else
			rank = 'D';
	}
	void print()
	{
		Employee::print();
	}
};