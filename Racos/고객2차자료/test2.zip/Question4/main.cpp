#include "Employee.h"
#include "Admin.h"
#include "Sales.h"
#include "Technician.h"
char* Employee::companyname = "KHUCompany";
int main()
{
	Admin a1("Lee",aemployee,32,50,60,65);
	a1.caltotal();
	a1.print();
	cout << endl;
	a1.set_type(aofficial);
	a1.caltotal();
	a1.print();
	cout << endl;
	Sales s1("Choi", semployee, 36, 80, 85, 85);
	s1.caltotal();
	s1.print();
	cout << endl;
	Technician t1("Kim", temployee, 41, 70, 75, 80);
	t1.caltotal();
	t1.print();
	cout << endl;
	return 0;
}