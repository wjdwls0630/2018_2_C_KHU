#include "Dog.h"
#include "Cat.h"
int Pet::petcount = 0;
int main()
{
	Pet* p1 = new Cat("Mya", 4, ������, small, female);
	Pet* p2 = new Dog("Puppy", 8, ����, medium, male);
	p1->show();
	cout << endl;
	p2->show();
	cout << endl;
	Pet::count();
	return 0;
}