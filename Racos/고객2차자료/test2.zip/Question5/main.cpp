#include "Employee.h"
#include "Admin.h"
#include "Sales.h"
#include "Technician.h"
char* Employee::companyname = "KHUCompany";
int main()
{
	Employee* ptr[3] = { new Admin("Lee",aemployee,32,50,60,65),new Sales("Choi", semployee, 36, 80, 85, 85) ,new Technician("Kim", temployee, 41, 70, 75, 80) };
	Admin a1("Lee",aemployee,32,50,60,65);
	for (int i = 0; i < 3; i++)
		ptr[i]->caltotal();
	for (int i = 0; i < 3; i++)
	{
		ptr[i]->print();
		cout << endl;
	}
	for (int i = 0; i < 3; i++)
		delete ptr[i];
	return 0;
}