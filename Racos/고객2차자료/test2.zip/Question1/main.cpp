#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	srand((unsigned int)time(NULL));
	int size = rand() % 11 + 10;
	cout << "�迭�� ũ�� (10~20): " << size << endl;
	int* arr = new int[size];
	int sum = 0;
	for (int i = 0; i < size; i++)
	{
		int num = rand() % 500 + 1;
		*(arr+i) = num;
		sum += arr[i];
	}
	cout << "�迭�� ��: ";
	for (int i = 0; i < size; i++)
		cout << *(arr + i) << " ";
	cout << endl;
	cout << setprecision(1);
	cout << fixed;
	float avg = (float)sum / size;
	float min = avg;
	int target = 0;
	for (int i = 0; i < size; i++)
	{
		if (abs(*(arr + i) - avg) < min)
		{
			min = abs(*(arr + i) - avg);
			target = i;
		}
		else
			;
	}
	cout << "�ּ� ���� ��: " << min << endl;
	cout << "�ּ� ������ ���� ���� ��: " << target << endl;
	delete[] arr;
	return 0;
}