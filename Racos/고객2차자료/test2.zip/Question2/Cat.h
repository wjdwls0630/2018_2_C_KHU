#pragma once
#include "Pet.h"
class Cat : public Pet
{
public:
	Cat(char* n, int a, int t, int x, int s)
		: Pet(n, a, t, x, s)
	{
	}
	virtual void show()
	{
		cout << "�������Դϴ�." << endl;
		Pet::show();
		cout << endl;
	}
};