#pragma once
#include "Pet.h"
class Dog : public Pet
{
public:
	Dog(char* n, int a, int t, int x, int s)
		: Pet(n,a,t,x,s)
	{
	}
	virtual void show()
	{
		cout << "�������Դϴ�." << endl;
		Pet::show();
		cout << endl;
	}
};