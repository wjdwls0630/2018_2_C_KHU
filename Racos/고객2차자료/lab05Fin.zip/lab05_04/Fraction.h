#ifndef FRACTION_H
#define FRACTION_H
#include<iostream>
using namespace std;
class Fraction
{
private:
	int numer;
	int denom;
public:
	Fraction();
	Fraction(int, int);
	Fraction(const Fraction&);
	~Fraction();
	int GCD(int, int);
	void print();
	void operator=(const Fraction&);
	friend Fraction operator+(const Fraction&, const Fraction&);
	friend Fraction operator-(const Fraction&, const Fraction&);
	friend Fraction operator*(const Fraction&, const Fraction&);
	friend Fraction operator/(const Fraction&, const Fraction&);
};
#endif // !FRACTION_H
