#include "Fraction.h"
Fraction operator+(const Fraction& fr1, const Fraction& fr2)
{
	int numer = fr1.numer*fr2.denom + fr1.denom*fr2.numer;
	int denom = fr1.denom*fr2.denom;
	return Fraction(numer, denom);
}
Fraction operator-(const Fraction& fr1, const Fraction& fr2)
{
	int numer = fr1.numer*fr2.denom - fr1.denom*fr2.numer;
	int denom = fr1.denom*fr2.denom;
	return Fraction(numer, denom);
}
Fraction operator*(const Fraction& fr1, const Fraction& fr2)
{
	int numer = fr1.numer*fr2.numer;
	int denom = fr1.denom*fr2.denom;
	return Fraction(numer, denom);
}
Fraction operator/(const Fraction& fr1, const Fraction& fr2)
{
	int numer = fr1.numer*fr2.denom;
	int denom = fr1.denom*fr2.numer;
	return Fraction(numer, denom);
}
int main()
{
	Fraction fr1(3, 5);
	Fraction fr2(7, 10);
	Fraction fr3;
	fr3 = fr1 + fr2;
	cout << "value of fr3 after fr3=fr1+fr2 operation : ";
	fr3.print();
	fr3 = fr1 - fr2;
	cout << "value of fr3 after fr3=fr1-fr2 operation : ";
	fr3.print();
	fr3 = fr1 * fr2;
	cout << "value of fr3 after fr3=fr1*fr2 operation : ";
	fr3.print();
	fr3 = fr1 / fr2;
	cout << "value of fr3 after fr3=fr1/fr2 operation : ";
	fr3.print();
	return 0;
}