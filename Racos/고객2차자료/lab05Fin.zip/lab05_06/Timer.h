#ifndef TIMER_H
#define TIMER_H
#include<iostream>
using namespace std;
class Timer
{
private:
	int nMin;
	int nSec;
	static int nIterations;
public:
	Timer();
	Timer(int min, int sec);
	void print();
	static void printdecrement();
	friend Timer operator+(const Timer&, const Timer&);
	Timer operator--(int);
	Timer operator=(const Timer& ti);
	bool operator==(const Timer& ti);
	bool operator<(const Timer& ti);
	bool operator!=(const Timer&);
};
#endif // !TIMER_H
