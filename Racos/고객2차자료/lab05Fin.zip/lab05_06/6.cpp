#include"Timer.h"
int Timer::nIterations = 0;
Timer zero;
Timer operator+(const Timer& t1, const Timer& t2)
{
	int min = t1.nMin + t2.nMin;
	int sec = t1.nSec + t2.nSec;
	if (sec >= 60)
	{
		sec %= 60;
		min += 1;
	}
	return Timer(min, sec);
}
#define C 2
#if C==1
int main()
{
	Timer timer1(1, 20);
	Timer timer2(0, 50);
	Timer timer3 = timer1 + timer2;
	cout << "timer3 is ";
	timer3.print();
	while (zero < timer3)
		timer3--;
	cout << "After loop, timer3 is ";
	timer3.print();
	cout << "zero is ";
	zero.print();
	cout << "decrement is ";
	timer3.printdecrement();
	return 0;
}
#else
int main()
{
	Timer timer1(1, 20);
	Timer timer2(0, 50);
	Timer timer3 = timer1 + timer2;
	cout << "timer3 is ";
	timer3.print();
	while (zero != timer3)
		timer3--;
	cout << "After loop, timer3 is ";
	timer3.print();
	cout << "zero is ";
	zero.print();
	cout << "decrement is ";
	timer3.printdecrement();
	return 0;
}
#endif