#include"Timer.h"
Timer::Timer()
	: nMin(0), nSec(0)
{}
Timer::Timer(int min, int sec)
	: nMin(min), nSec(sec)
{}
void Timer::print()
{
	if (nMin < 10)
	{
		if (nSec<10)
			cout << "0" << nMin << ":0" << nSec << endl;
		else
			cout << "0" << nMin << ":" << nSec << endl;
	}
	else
	{
		if (nSec<10)
			cout << nMin << ":0" << nSec << endl;
		else
			cout << nMin << ":" << nSec << endl;
	}
}
void Timer::printdecrement()
{
	cout << nIterations << endl;
}
Timer Timer::operator--(int)
{
	if (nSec != 0)
		nSec--;
	else
	{
		nMin--;
		nSec += 59;
	}
	nIterations++;
	return Timer(nMin, nSec);
}
Timer Timer::operator=(const Timer& ti)
{
	int min = ti.nMin;
	int sec = ti.nSec;
	return Timer(min, sec);
}
bool Timer::operator==(const Timer& ti)
{
	if (nMin == ti.nMin && nSec == ti.nSec)
		return true;
	else
		return false;
}
bool Timer::operator<(const Timer& ti)
{
	if (nMin < ti.nMin)
		return true;
	else
	{
		if (nSec == 0 && ti.nSec == 0)
			return false;
		else
			return true;
	}
}
bool Timer::operator!=(const Timer& ti)
{
	if (nMin != ti.nMin && nSec != ti.nSec)
		return true;
	else
		return false;
}