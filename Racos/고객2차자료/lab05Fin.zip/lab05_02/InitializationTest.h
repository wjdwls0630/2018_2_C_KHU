#ifndef INITIALIZATIONTEST_H
#define INITIALIZATIONTEST_H
#include<iostream>
using namespace std;
class InitializationTest
{
private:
	int nFirst;
	int nSecond;
public:
	InitializationTest(int nF, int nS)
		: nFirst(nF), nSecond(nS)
	{}
	void print();
};
void InitializationTest::print()
{
	cout << "nFirst = " << nFirst << endl;
	cout << "nSecond = " << nSecond << endl;
}
#endif // !INTIALIZATIONTEST_H