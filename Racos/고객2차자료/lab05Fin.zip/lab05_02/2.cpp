#include "InitializationTest.h"
int main()
{
	InitializationTest myTest(100, 200);
	myTest.print();
	return 0;
}