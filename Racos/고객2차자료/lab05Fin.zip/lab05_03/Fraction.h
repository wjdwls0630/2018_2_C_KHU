#ifndef FRACTION_H
#define FRACTION_H
#include<iostream>
using namespace std;
class Fraction
{
private:
	int numer;
	int denom;
public:
	Fraction();
	Fraction(int, int);
	Fraction(const Fraction&);
	~Fraction();
	int GCD(int, int);
	void print();
	void operator=(const Fraction&);
	void operator+=(const Fraction&);
	Fraction operator++();
	Fraction operator++(int);
};
#endif // !FRACTION_H
