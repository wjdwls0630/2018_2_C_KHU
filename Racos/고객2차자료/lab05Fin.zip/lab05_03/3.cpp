#include "Fraction.h"
int main()
{
	Fraction fr1(3, 5);
	Fraction fr2;
	fr2 = fr1;
	cout << "value of fr2 after fr2 = fr1 operation : ";
	fr2.print();
	fr2 += fr1;
	cout << "value of fr2 after fr2 += fr1 operation : ";
	fr2.print();
	fr2++;
	cout << "value of fr2 after fr2++ operation : ";
	fr2.print();
	++fr2;
	cout << "value of fr2 after ++fr2 operation : ";
	fr2.print();
	return 0;
}