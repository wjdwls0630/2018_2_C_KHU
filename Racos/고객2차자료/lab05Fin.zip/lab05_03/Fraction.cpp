#include "Fraction.h"
Fraction::Fraction()
	: numer(0),denom(1)
{}
Fraction::Fraction(int n, int d)
	: numer(n), denom(d)
{}
Fraction::Fraction(const Fraction& fr)
{
	this->numer = fr.numer;
	this->denom = fr.denom;
}
Fraction::~Fraction()
{}
void Fraction::print()
{
	cout << numer / GCD(numer, denom) << "/" << denom / GCD(numer, denom) << endl;
}
int Fraction::GCD(int x, int y)
{
	if (y == 0)
		return x;
	else
		return GCD(y, x%y);
}
void Fraction::operator=(const Fraction& fr)
{
	this->numer = fr.numer;
	this->denom = fr.denom;
}
void Fraction::operator+=(const Fraction& fr)
{
	this->numer = this->numer*fr.denom + this->denom*fr.numer;
	this->denom *= fr.denom;
}
Fraction Fraction::operator++()
{
	this->numer += this->denom;
	return *this;
}
Fraction Fraction::operator++(int)
{
	Fraction save(*this);
	this->numer += this->denom;
	return save;
}