#include "Fraction.h"
Fraction::Fraction()
	: numer(0),denom(1), nSubtactCount(0)
{}
Fraction::Fraction(int n, int d)
	: numer(n), denom(d), nSubtactCount(0)
{}
Fraction::Fraction(const Fraction& fr)
{
	this->numer = fr.numer;
	this->denom = fr.denom;
	nSubtactCount = 0;
}
Fraction::~Fraction()
{}
void Fraction::printStatic_Add()
{
	cout << nAddCount << endl;
}
//void Fraction::printStatic_Subtract()
//{
//	cout << nSubtactCount << endl;
//} // static������ �ƴ϶�� static�Լ��� ���ִ´�.
void Fraction::printNonstatic_Subtract()
{
	cout << nSubtactCount << endl;
}
void Fraction::add(const Fraction& fr)
{
	this->numer = this->numer*fr.denom + this->denom*fr.numer;
	this->denom *= fr.denom;
	nAddCount++;
}
void Fraction::subtract(const Fraction& fr)
{
	this->numer = this->numer*fr.denom - this->denom*fr.numer;
	this->denom *= fr.denom;
	nSubtactCount++;
}