#ifndef FRACTION_H
#define FRACTION_H
#include<iostream>
using namespace std;
class Fraction
{
private:
	int numer;
	int denom;
	static int nAddCount;
	int nSubtactCount;
public:
	Fraction();
	Fraction(int, int);
	Fraction(const Fraction&);
	~Fraction();
	static void printStatic_Add();
	/*static void printStatic_Subtract();*/
	void printNonstatic_Subtract();
	void add(const Fraction&);
	void subtract(const Fraction&);
};
#endif // !FRACTION_H
