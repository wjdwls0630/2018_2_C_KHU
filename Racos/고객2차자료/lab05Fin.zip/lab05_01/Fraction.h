#ifndef FRACTION_H
#define FRACTION_H
#include<iostream>
using namespace std;
class Fraction
{
private:
	int numer;
	int denom;
public:
	inline void print();
	void store(int n, int d)
	{
		numer = n;
		denom = d;
	}
};
#endif // !FRACTION_H
