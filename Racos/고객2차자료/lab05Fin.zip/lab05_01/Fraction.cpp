#include "Fraction.h"
void Fraction::print()
{
	cout << numer / denom << endl;
}