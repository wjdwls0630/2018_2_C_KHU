#include "Fraction.h"
int main()
{
	Fraction fr1;
	fr1.store(2, 3);
	fr1.print();
	return 0;
}