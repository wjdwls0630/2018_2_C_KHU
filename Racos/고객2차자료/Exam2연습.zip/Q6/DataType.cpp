#include "DataType.h"
DataType::DataType()
	: m_nType(NONE)
{}
DataType::DataType(DataType& dt)
{
	m_nType = dt.m_nType;
	switch (dt.m_nType)
	{
	case NONE:
		break;
	case STRING:
		m_Data.pStr = new char[strlen(dt.m_Data.pStr) + 1];
		strcpy(m_Data.pStr, dt.m_Data.pStr);
		break;
	case FLOAT:
		m_Data.fFloat = dt.m_Data.fFloat;
		break;
	case INTEGER:
		m_Data.nInt = dt.m_Data.nInt;
		break;
	}
}
DataType::DataType(char* s)
{
	m_nType = STRING;
	m_Data.pStr = new char[strlen(s) + 1];
	strcpy(m_Data.pStr, s);
}
DataType::DataType(double d)
{
	m_nType = FLOAT;
	m_Data.fFloat = d;
}
DataType::DataType(int i)
{
	m_nType = INTEGER;
	m_Data.nInt = i;
}
DataType::~DataType()
{
	if (m_nType == STRING)
		delete[] m_Data.pStr;
	else
		;
}
void DataType::printData()
{
	switch (m_nType)
	{
	case STRING:
		cout << m_Data.pStr << endl;
		break;
	case FLOAT:
		cout << m_Data.fFloat << endl;
		break;
	case INTEGER:
		cout << m_Data.nInt << endl;
		break;
	default:
		cout << endl;
		break;
	}
}
DataType DataType::operator+(DataType& dt)
{
	if (this->m_nType == dt.m_nType)
	{
		if (dt.m_nType == INTEGER)
			return DataType(this->m_Data.nInt + dt.m_Data.nInt);
		else if (dt.m_nType == STRING)
		{
			char* newstring = new char[strlen(this->m_Data.pStr) + strlen(dt.m_Data.pStr) + 1];
			strcpy(newstring, this->m_Data.pStr);
			strcat(newstring, dt.m_Data.pStr);
			return DataType(newstring);
		}
		else if (dt.m_nType == FLOAT)
			return DataType(this->m_Data.fFloat + dt.m_Data.fFloat);
		else
			return DataType();
	}
	else
	{
		cout << "���������� ��ġ���� �ʽ��ϴ�" << endl;
		return DataType();
	}
}
DataType DataType::operator=(DataType& dt)
{
	m_nType = dt.m_nType;
	switch (dt.m_nType)
	{
	case NONE:
		break;
	case STRING:
		m_Data.pStr = new char[strlen(dt.m_Data.pStr) + 1];
		strcpy(m_Data.pStr, dt.m_Data.pStr);
		break;
	case FLOAT:
		m_Data.fFloat = dt.m_Data.fFloat;
		break;
	case INTEGER:
		m_Data.nInt = dt.m_Data.nInt;
		break;
	}
	return *this;
}