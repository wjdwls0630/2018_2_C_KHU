#include "DataType.h"
DataType operator+(char* c, DataType& dt)
{
	char* newstring = new char[strlen(c) + strlen(dt.m_Data.pStr) + 1];
	strcpy(newstring, c);
	strcat(newstring, dt.m_Data.pStr);
	return DataType(newstring);
}
int main()
{
	DataType IntA(55);
	DataType IntB(-45);
	DataType IntC;
	IntC = IntA + IntB;
	IntC.printData();

	DataType FloatA(3.14);
	DataType FloatB(-1.0);
	DataType FloatC;
	FloatC = IntA + FloatB;
	FloatC = FloatA + FloatB;
	FloatC.printData();

	DataType StringA("Hello");
	DataType StringB("World");
	DataType StringC;
	StringC = StringA + StringB;
	StringC.printData();
	DataType StringD("Bye !!!");
	DataType StringE;
	StringE = "Good" + StringD;
	StringE.printData();
	return 0;
}