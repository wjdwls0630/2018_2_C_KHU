#pragma once
#include<iostream>
using namespace std;
union DATA
{
	char* pStr;
	double fFloat;
	int nInt;
};
enum Types {NONE, STRING, FLOAT, INTEGER};
class DataType
{
private:
	int m_nType;
	DATA m_Data;
public:
	DataType();
	DataType(DataType&);
	DataType(char*);
	DataType(double);
	DataType(int);
	~DataType();
	void printData();
	DataType operator+(DataType&);
	friend DataType operator+(char*, DataType&);
	DataType operator=(DataType&);
};