#pragma once
#include<iostream>
#include<iomanip>
using namespace std;
struct TRANSACTION
{
	int amount;
	char memo[50];
};
class BankAccount
{
private:
	static const int MAX_HISTORY_SIZE;
	static int nTotalBankBalance;
	int AccountNo;
	int balance;
	TRANSACTION history[20];
	int historyCount;
public:
	BankAccount()
		: balance(0), historyCount(0)
	{
		AccountNo = rand();
	}
	BankAccount(int);
	void PrintAccount();
	static void PrintBank();
	void Deposit(int, char*);
	void Withdraw(int, char*);
};