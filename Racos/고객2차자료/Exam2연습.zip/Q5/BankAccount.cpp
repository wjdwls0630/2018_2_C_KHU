#include "BankAccount.h"
BankAccount::BankAccount(int b)
	: AccountNo(rand()), balance(b), historyCount(0)
{
	history[historyCount].amount = b;
	strcpy(history[historyCount].memo, "���»���");
	nTotalBankBalance += b;
	historyCount++;
}
void BankAccount::PrintAccount()
{
	cout << "======================" << endl;
	cout << "Account No. " << AccountNo << " Information" << endl;
	cout << "Balance : " << balance << endl;
	cout << "Recent history" << endl;
	for (int i = 0; i < historyCount; i++)
		cout << i << " : " << history[i].amount << "\t" << history[i].memo << endl;
}
void BankAccount::PrintBank()
{
	cout << endl << "Total Bank Balance =======" << endl;
	cout << nTotalBankBalance << endl;
}
void BankAccount::Deposit(int amount, char* memo)
{
	nTotalBankBalance += amount;
	balance += amount;
	history[historyCount].amount = amount;
	strcpy(history[historyCount].memo, memo);
	historyCount++;
	if (historyCount > MAX_HISTORY_SIZE)
		cout << "ERROR!!! �ŷ������� �ʰ��Ǿ����ϴ� !!!" << endl;
}
void BankAccount::Withdraw(int amount, char* memo)
{
	nTotalBankBalance -= amount;
	balance -= amount;
	history[historyCount].amount = -amount;
	strcpy(history[historyCount].memo, memo);
	historyCount++;
	if (historyCount > MAX_HISTORY_SIZE)
		cout << "ERROR!!! �ŷ������� �ʰ��Ǿ����ϴ� !!!" << endl;
}