#pragma once
#include<iostream>
using namespace std;
class SalineSolution
{
private:
	int solweight;
	float concent;
public:
	SalineSolution(int, float);
	SalineSolution(int, int);
	friend SalineSolution operator+(SalineSolution&, SalineSolution&);
	friend SalineSolution operator+(SalineSolution&, int);
	SalineSolution operator=(SalineSolution&);
	void print();
};