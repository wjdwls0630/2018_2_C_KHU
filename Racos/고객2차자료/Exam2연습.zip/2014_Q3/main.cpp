#include "SalineSolution.h"
SalineSolution operator+(SalineSolution& s1, SalineSolution& s2)
{
	return SalineSolution(s1.solweight + s2.solweight, (s1.concent / 100 * s1.solweight + s2.concent / 100 * s2.solweight) / (s1.solweight + s2.solweight) * 100);
}
SalineSolution operator+(SalineSolution& s, int amt)
{
	return SalineSolution(s.solweight + amt, (s.concent * s.solweight + amt) / (s.solweight + amt) * 100);
}
int main()
{
	SalineSolution cupA(100, (float)20.);
	SalineSolution cupB(200, 10);
	SalineSolution cupC = cupA + cupB;
	cupC = cupC + 5;
	cupC.print();
	return 0;
}