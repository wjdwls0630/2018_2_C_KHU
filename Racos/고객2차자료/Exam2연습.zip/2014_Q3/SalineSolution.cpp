#include "SalineSolution.h"
SalineSolution::SalineSolution(int solutionWeight, float concentration)
{
	solweight = solutionWeight;
	concent = concentration;
}
SalineSolution::SalineSolution(int solutionWeight, int saltWeight)
{
	solweight = solutionWeight;
	concent = (float)saltWeight/solutionWeight;
}
SalineSolution SalineSolution::operator=(SalineSolution& ss)
{
	return SalineSolution(ss.solweight, ss.concent);
}
void SalineSolution::print()
{
	cout << "����: " << solweight << endl;
	cout << "��: " << concent << "%" << endl;
}