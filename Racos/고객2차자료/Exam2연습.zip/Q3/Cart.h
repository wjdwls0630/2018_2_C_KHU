#pragma once
#include<iostream>
using namespace std;
struct PRODUCT
{
	int pID;
	int price;
};
class Cart
{
private:
	int productID[10];
	int nProducts;
public:
	Cart();
	Cart(const Cart&);
	void add(int);
	void remove(int);
	void print();
	void print(PRODUCT[]);
};