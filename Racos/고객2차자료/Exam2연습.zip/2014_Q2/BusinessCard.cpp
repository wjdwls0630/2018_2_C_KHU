#include "BusinessCard.h"
BusinessCard::BusinessCard()
{
	schoolname = new char[10];
	personname = new char[10];
	phonenum = 0;
	s_num++;
}
BusinessCard::BusinessCard(char* sn, char* pn, int pnum)
{
	delete[] schoolname;
	schoolname = new char[strlen(sn) + 1];
	strcpy(schoolname, sn);
	delete[] personname;
	personname = new char[strlen(pn) + 1];
	strcpy(personname, pn);
	phonenum = pnum;
	s_num++;
}
BusinessCard::BusinessCard(const BusinessCard& bc)
{
	delete[] schoolname;
	schoolname = new char[strlen(bc.schoolname) + 1];
	strcpy(schoolname, bc.schoolname);
	delete[] personname;
	personname = new char[strlen(bc.personname) + 1];
	strcpy(personname, bc.personname);
	phonenum = bc.phonenum;
	s_num++;
}
BusinessCard::~BusinessCard()
{
	cout << "�Ҹ��� ȣ�� - " << s_num << "��° ������ �����Ǿ����ϴ�." << endl;
	s_num--;
	delete[] schoolname;
	delete[] personname;
}
void BusinessCard::input(char* sn, char* pn, int pnum)
{
	delete schoolname;
	schoolname = new char[strlen(sn) + 1];
	strcpy(schoolname, sn);
	delete personname;
	personname = new char[strlen(pn) + 1];
	strcpy(personname, pn);
	phonenum = pnum;
}
void BusinessCard::view()
{
	cout << "��ȣ: " << s_num << " / �Ҽ�: " << schoolname << " / �̸�: " << personname << " / Tel: " << phonenum << endl;
}