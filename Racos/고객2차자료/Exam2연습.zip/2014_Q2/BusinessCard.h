#pragma once
#include<iostream>
using namespace std;
class BusinessCard
{
private:
	static int s_num;
	char* schoolname;
	char* personname;
	int phonenum;
public:
	BusinessCard();
	BusinessCard(char*, char*, int);
	BusinessCard(const BusinessCard&);
	~BusinessCard();
	void input(char*, char*, int);
	void view();
};