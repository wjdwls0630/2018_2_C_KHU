#include "Solution.h"
int main()
{
	int targetnum, targetcon;
	Solution sols[5] = {Solution(100,10.f,Solution::SALT), Solution(150,15.f,Solution::SUGAR) ,Solution(70,10.f,Solution::COFFEE) 
		,Solution(200,5.f,Solution::SALT) ,Solution(170,20.f,Solution::COFFEE) };
	cout << "���� (1: SALT, 2: SUGAR, 3: COFFEE, 4: ANY) : ";
	cin >> targetnum;
	cout << "�ּ� �� : ";
	cin >> targetcon;
	for (int i = 0; i < 5; i++)
	{
			if ((targetnum==4 || sols[i].getType() == targetnum) && targetcon <= sols[i].getConcent())
				sols[i].print();
			else
				continue;
	}
	return 0;
}