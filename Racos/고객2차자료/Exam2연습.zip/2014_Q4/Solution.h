#pragma once
#include<iostream>
using namespace std;
class Solution
{
public:
	enum SoluteType { SALT = 1, SUGAR, COFFEE };
private:
	int solweight;
	float concent;
	SoluteType type;
public:
	Solution(int solutionWeight, float concentration, SoluteType soluteType=SALT)
		: solweight(solutionWeight), concent(concentration), type(soluteType)
	{}
	SoluteType getType()
	{
		return type;
	}
	float getConcent()
	{
		return concent;
	}
	void print()
	{
		char* names[4] = { "","SALT","SUGAR","COFFEE" };
		cout << "����: " << names[type] << ", ��: " << concent << "%, ����: " << solweight << "g" << endl;
	}
};