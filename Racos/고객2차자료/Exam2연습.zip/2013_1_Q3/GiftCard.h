#pragma once
#include<iostream>
using namespace std;
class GiftCard
{
private:
	int balance;
	int approval;
	int charge;
	int* pChargeArr;
	int* pApprovalArr;
public:
	GiftCard();
	GiftCard(int);
	~GiftCard();
	void Charge(int);
	bool Approval(int);
	int GetChargeNumber()
	{
		return charge;
	}
	inline int GetApprovalNumber();
	void ResetCard();
	friend GiftCard operator+(const GiftCard&, const GiftCard&);
	friend std::ostream& operator<<(std::ostream&, const GiftCard&);
	GiftCard& operator=(const GiftCard&);
	GiftCard& operator+=(const GiftCard&);
	const GiftCard& operator++();
};
int GiftCard::GetApprovalNumber()
{
	return approval;
}