#include "GiftCard.h"
GiftCard::GiftCard()
	: balance(100000), approval(0), charge(0)
{
	pApprovalArr = new int[100];
	pChargeArr = new int[100];
}
GiftCard::GiftCard(int b)
	: balance(b), approval(0), charge(0)
{
	pApprovalArr = new int[100];
	pChargeArr = new int[100];
}
GiftCard::~GiftCard()
{
	delete[] pApprovalArr;
	delete[] pChargeArr;
}
void GiftCard::Charge(int ChargeMoney)
{
	balance += ChargeMoney;
	pChargeArr[charge++] = ChargeMoney;
}
bool GiftCard::Approval(int ApprovalMoney)
{
	if (ApprovalMoney > balance)
		return false;
	else
	{
		balance -= ApprovalMoney;
		pApprovalArr[approval++] = ApprovalMoney;
		return true;
	}
}
void GiftCard::ResetCard()
{
	approval = 0, charge = 0;
	for (int i = 0; i < charge; i++)
		pChargeArr[i] = 0;
	/*for (int i = 0; i < approval; i++)
	pApprovalArr[i] = 0;*/
}
GiftCard& GiftCard::operator=(const GiftCard& rhs)
{
	balance = rhs.balance;
	charge = rhs.charge;
	approval = rhs.approval;
	for (int i = 0; i < rhs.charge; i++)
		pChargeArr[i] = rhs.pChargeArr[i];
	for (int i = 0; i < rhs.approval; i++)
		pApprovalArr[i] = rhs.pApprovalArr[i];
	return *this;
}
GiftCard& GiftCard::operator+=(const GiftCard& rhs)
{
	balance += rhs.balance;
	int totcharge = charge + rhs.charge;
	int totapproval = approval + rhs.approval;
	for (int i = charge; i < totcharge; i++)
		pChargeArr[i] += rhs.pChargeArr[i - charge];
	for (int i = approval; i < totapproval; i++)
		pApprovalArr[i] += rhs.pApprovalArr[i - approval];
	charge = totcharge;
	approval = totapproval;
	return *this;
}
const GiftCard& GiftCard::operator++()
{
	balance += 10000;
	pChargeArr[charge++] = 10000;
	return *this;
}