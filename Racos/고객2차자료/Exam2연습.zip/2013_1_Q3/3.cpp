#include "GiftCard.h"
GiftCard operator+(const GiftCard& lhs, const GiftCard& rhs)
{
	GiftCard* temp = new GiftCard(0);
	temp->balance = lhs.balance + rhs.balance;
	temp->charge = lhs.charge + rhs.charge;
	temp->approval = lhs.approval + rhs.approval;
	for (int i = 0; i < rhs.charge; i++)
		temp->pChargeArr[i] = rhs.pChargeArr[i];
	for (int i = rhs.charge; i < temp->charge; i++)
		temp->pChargeArr[i] = lhs.pChargeArr[i - rhs.charge];
	for (int i = 0; i < rhs.approval; i++)
		temp->pApprovalArr[i] = rhs.pApprovalArr[i];
	for (int i = rhs.approval; i < temp->approval; i++)
		temp->pApprovalArr[i] = lhs.pApprovalArr[i - rhs.approval];
	return *temp;
}
std::ostream& operator<<(std::ostream& os, const GiftCard& rhs)
{
	os << "�ܾ� : " << rhs.balance << "\n";
	os << "����Ƚ�� : " << rhs.approval << "\n";
	for (int i = 0; i < rhs.approval; i++)
		os << i + 1 << "��° ���� �ݾ� : " << rhs.pApprovalArr[i] << " ��\n";
	os << "����Ƚ�� : " << rhs.charge << "\n";
	for (int i = 0; i < rhs.charge; i++)
		os << i + 1 << "��° ���� �ݾ� : " << rhs.pChargeArr[i] << " ��\n";
	return os;
}
int main()
{
	GiftCard c1;
	c1.Charge(20000);
	c1.Charge(15000);
	c1.Approval(2000);
	c1.Approval(3000);
	c1.Approval(42000);
	cout << c1 << endl;
	GiftCard c2;
	c2 = c1;
	++c2;
	cout << c2 << endl;
	c1.ResetCard();
	c1.Approval(1500);
	GiftCard c3(0);
	c3.Charge(100);
	if (c3.Approval(20000) == false)
		cout << "���� �ݾ��� �ܾ� ���� �����ϴ�." << endl;
	c3 = c3 + c2;
	cout << c3 << endl;
	c3.ResetCard();
	c3 += c1;
	cout << c3 << endl;
	int nApprovalNum = c3.GetApprovalNumber();
	int nChargeNum = c2.GetChargeNumber();
	cout << " c3�� ���� Ƚ���� : " << nApprovalNum << " �� �Դϴ�." << endl;
	cout << " c2�� ���� Ƚ���� : " << nChargeNum << " �� �Դϴ�." << endl;
	return 0;
}