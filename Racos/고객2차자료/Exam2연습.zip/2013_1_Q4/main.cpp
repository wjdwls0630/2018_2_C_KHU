#include<iostream>
using namespace std;
typedef char* Name;
enum Year {FIRST=1,SECOND,THIRD,FOURTH};
class Students
{
private:
	Name name;
	int year;
	static int studentNum;
public:
	Students(Name nname, int nyear)
	{
		name = new char[20];
		strcpy(name, nname);
		year = nyear;
		studentNum++;
	}
	~Students()
	{
		studentNum--;
		delete[] name;
	}
	void print()
	{
		cout << "�̸�: " << name << ", �г�: " << year << endl;
	}
	static int getNumStudents()
	{
		return studentNum;
	}
};
int Students::studentNum = 0;
int main()
{
	cout << "���� �л� ��: " << Students::getNumStudents() << endl;
	Students std[3] = { Students("ö��",FIRST),Students("����",SECOND) ,Students("�浿",THIRD) };
	for (int i = 0; i < 3; i++)
		std[i].print();
	Students* st = new Students("�Ѹ�", FOURTH);
	cout << "���� �л� ��: " << st->getNumStudents() << endl;
	delete st;
	cout << "���� �л� ��: " << Students::getNumStudents() << endl;
	return 0;
}