#pragma once
#include<iostream>
using namespace std;
struct PRODUCT
{
	int pID;
	int price;
};
class Cart
{
private:
	int* productID;
	int size;
	int nProducts;
	static const PRODUCT productPriceAry[];
public:
	Cart();
	Cart(int);
	Cart(const Cart&);
	~Cart();
	friend void add(Cart&, int);
	friend void remove(Cart&, int);
	void print();
};