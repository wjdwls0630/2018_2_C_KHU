#include "Cart.h"
Cart::Cart()
	: nProducts(0), size(10)
{
	productID = new int[size];
	for (int i = 0; i < size; i++)
		productID[i] = 0;
}
Cart::Cart(int s)
	: nProducts(0), size(s)
{
	productID = new int[size];
	for (int i = 0; i < size; i++)
		productID[i] = 0;
}
Cart::Cart(const Cart& ca)
	: nProducts(ca.nProducts), size(ca.size)
{
	delete[] productID;
	productID = new int[size];
	for (int i = 0; i < size; i++)
		productID[i] = ca.productID[i];
}
Cart::~Cart()
{
	delete[] productID;
}
void Cart::print()
{
	if (nProducts != 0)
	{
		cout << endl << "PID\tPrice" << endl;
		cout << "==============" << endl;
		for (int i = 0; i < nProducts; i++)
		{
			for (int j = 0; j < 6; j++)
			{
				if (productID[i] == productPriceAry[j].pID)
					cout << productPriceAry[j].pID << "\t" << productPriceAry[j].price << endl;
			}
		}
		cout << endl;
	}
	else
		cout << endl;
}