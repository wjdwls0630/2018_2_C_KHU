#include<iostream>
using namespace std;
enum color{red,rose=0,crimpson=0,scarlet,aqua=3};
int main()
{
	cout << red << endl; // 0
	cout << rose << endl;
	cout << crimpson << endl;
	cout << scarlet << endl; // 1
	cout << aqua << endl;
	return 0;
}