#pragma once
#include "Condiment.h"
class Milk : public Condiment
{
public:
	Milk(Beverage* bever) : Condiment(bever)
	{
		strcpy(description, bever->GetDescription());
		strcat(description, " + ����");
	}
	char* GetDescription()
	{
		return description;
	}
	int getCost()
	{
		return 700 + bever->getCost();
	}
};