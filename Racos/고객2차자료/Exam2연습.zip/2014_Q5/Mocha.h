#pragma once
#include "Condiment.h"
class Mocha : public Condiment
{
public:
	Mocha(Beverage* bever) : Condiment(bever)
	{
		strcpy(description, bever->GetDescription());
		strcat(description, " + ��ī");
	}
	char* GetDescription()
	{
		return description;
	}
	int getCost()
	{
		return 800 + bever->getCost();
	}
};