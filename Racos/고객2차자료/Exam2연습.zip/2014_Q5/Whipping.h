#pragma once
#include "Condiment.h"
class Whipping : public Condiment
{
public:
	Whipping(Beverage* bever) : Condiment(bever)
	{
		strcpy(description, bever->GetDescription());
		strcat(description, " + ����");
	}
	char* GetDescription()
	{
		return description;
	}
	int getCost()
	{
		return 500 + bever->getCost();
	}
};