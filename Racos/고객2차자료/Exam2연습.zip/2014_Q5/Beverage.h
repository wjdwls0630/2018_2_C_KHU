#pragma once
#include<iostream>
using namespace std;
class Beverage
{
protected:
	char description[1024];
public:
	Beverage()
	{
		strcpy(description, "���� ����");
	}
	virtual ~Beverage()
	{}
	virtual char* GetDescription()
	{
		return description;
	}
	virtual int getCost()
	{
		return 0;
	}
};