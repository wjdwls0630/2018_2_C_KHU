#pragma once
#include "Condiment.h"
class Water : public Condiment
{
public:
	Water(Beverage* bever) : Condiment(bever)
	{
		strcpy(description, bever->GetDescription());
		strcat(description, " + ��");
	}
	char* GetDescription()
	{
		return description;
	}
	int getCost()
	{
		return 200 + bever->getCost();
	}
};