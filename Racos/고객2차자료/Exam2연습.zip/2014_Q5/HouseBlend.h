#pragma once
#include "Beverage.h"
class HouseBlend : public Beverage
{
public:
	HouseBlend()
	{
		strcpy(description, "�Ͽ콺 ������ Ŀ��");
	}
	char* GetDescription()
	{
		return description;
	}
	int getCost()
	{
		return 2500;
	}
};