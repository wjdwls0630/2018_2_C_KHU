#pragma once
#include "Beverage.h"
class Espresso :public Beverage
{
public:
	Espresso()
	{
		strcpy(description, "����������");
	}
	char* GetDescription()
	{
		return description;
	}
	int getCost()
	{
		return 1800;
	}
};