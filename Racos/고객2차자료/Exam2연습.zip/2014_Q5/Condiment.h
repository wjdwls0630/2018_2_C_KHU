#pragma once
#include "Beverage.h"
class Condiment : public Beverage
{
protected:
	Beverage* bever;
public:
	Condiment(Beverage* bever)
	{
		this->bever = bever;
	}
	virtual ~Condiment()
	{
		delete bever;
	}
};