#include "Espresso.h"
#include "HouseBlend.h"
#include "Water.h"
#include "Mocha.h"
#include "Milk.h"
#include "Whipping.h"
void Display(Beverage* bever)
{
	cout << bever->GetDescription() << ", " << bever->getCost() << "��" << endl;
}
int main()
{
	Beverage* bever = new Espresso();
	Display(bever);
	delete bever;

	bever = new Espresso();
	bever = new Water(bever);
	Display(bever);
	delete bever;
	
	bever = new HouseBlend();
	bever = new Mocha(bever);
	bever = new Whipping(bever);
	Display(bever);
	delete bever;
	
	bever = new HouseBlend();
	bever = new Mocha(bever);
	bever = new Whipping(bever);
	bever = new Whipping(bever);
	Display(bever);
	delete bever;
	return 0;
}