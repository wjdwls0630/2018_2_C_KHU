#pragma once
#include "DigitalTV.h"
class PdpTV : public DigitalTV
{
private:
	bool mAcPDP;
public:
	PdpTV()
		: mAcPDP(true), DigitalTV()
	{}
	void setAcPDP(bool acpdp)
	{
		mAcPDP = acpdp;
	}
	void printTVInfo()
	{
		cout << "PDP TV" << endl;
		DigitalTV::printTVInfo();
		if (mAcPDP == true)
			cout << "AC PDP TV" << endl;
		else
			cout << "DC PDP TV" << endl;
	}
};