#include "CrtTV.h"
#include "LcdTV.h"
#include "PdpTV.h"
#include "ProjectionTV.h"
int main()
{
	BaseTV* myTVs[4];
	LcdTV lcdTV;
	lcdTV.setBrandName("LG");
	lcdTV.setPrice(1000000);
	lcdTV.setScreenSize(60);
	lcdTV.setHangWall(true);
	lcdTV.setSmartTV(false);
	lcdTV.setLED(false);
	lcdTV.set3DTV(false);
	myTVs[0] = &lcdTV;

	PdpTV pdpTV;
	pdpTV.setBrandName("Samsung");
	pdpTV.setPrice(500000);
	pdpTV.setScreenSize(42);
	pdpTV.setHangWall(false);
	pdpTV.setSmartTV(true);
	pdpTV.setAcPDP(false);
	myTVs[1] = &pdpTV;

	CrtTV crtTV;
	crtTV.setBrandName("Sony");
	crtTV.setPrice(100000);
	crtTV.setScreenSize(21);
	crtTV.setDigitalSupport(true);
	crtTV.setFlat(true);
	myTVs[2] = &crtTV;

	ProjectionTV prjTV;
	prjTV.setBrandName("Sharp");
	prjTV.setPrice(200000);
	prjTV.setScreenSize(54);
	prjTV.setDigitalSupport(false);
	prjTV.setProjectionMethod(0);
	myTVs[3] = &prjTV;

	for (int i = 0; i < 4; i++)
	{
		myTVs[i]->printTVInfo();
		cout << endl;
	}
	return 0;
}