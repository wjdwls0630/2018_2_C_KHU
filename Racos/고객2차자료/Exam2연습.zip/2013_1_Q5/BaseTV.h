#pragma once
#include<iostream>
using namespace std;
class BaseTV
{
protected:
	char* mBrandName;
	int mPrice;
	int mScreenSize;
public:
	BaseTV()
		: mPrice(0), mScreenSize(0)
	{
		mBrandName = new char[100];
	}
	~BaseTV()
	{
		delete[] mBrandName;
	}
	virtual void printTVInfo()
	{
		cout << "��ǥ : " << mBrandName << endl;
		cout << "���� : " << mPrice << endl;
		cout << "ȭ�� ũ�� : " << mScreenSize << " Inch" << endl;
	}
	void setBrandName(char* BrandName)
	{
		strcpy(mBrandName, BrandName);
	}
	void setPrice(int Price)
	{
		mPrice = Price;
	}
	void setScreenSize(int ScreenSize)
	{
		mScreenSize = ScreenSize;
	}
};