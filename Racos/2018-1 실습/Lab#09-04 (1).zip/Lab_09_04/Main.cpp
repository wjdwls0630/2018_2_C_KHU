#include <iostream>
using namespace std;
 
 
 
class Stack {
private:
    int* p_list;
    int size;
    int MAX_SIZE;
    static int numStacks;
public:
    friend class SpyStack;
    friend int get_num_common_items(Stack& s1, Stack& s2);
    Stack(int _MAX_SIZE = 1000) {
        MAX_SIZE = _MAX_SIZE;
        p_list = new int[MAX_SIZE];
        size = 0;
        numStacks++;
    }
    ~Stack() {
        delete[] p_list;
        numStacks--;
    }
 
    void push(int _item) {
        if (size < MAX_SIZE) {
            int index = find_index(_item);
            if (index < 0){
                p_list[size] = _item;
                size++;
            }
        }
        else {
            cout << "Error: out of memory" << endl;
        }
    }
    int pop() {
        if (size > 0) {
            size--;
            return p_list[size];
        }
        else {
            cout << "Error: No item exists in the list" << endl;
            return -1;
        }
    }
    void print() const {
        cout << "Items in the list: ";
        for (int i = 0; i < size; i++) {
            cout << p_list[i] << ",";
        }
        cout << endl;
    }
    int get_size() { return size; }
    int get_item(int _index) {
        int item = -1;
        if (_index < size) {
            return p_list[_index];
        }
        else {
            return item;
        }
    }
    int find_index(int _item) {
        int index = -1;
        for (int i = 0; i < size; i++) {
            if (_item == p_list[i]) {
                return i;
            }
        }
        return index;
    }
 
 
    void operator+=(Stack& other) {
 
 
        for (int i = 0; i < other.size; i++) {
            push(other.p_list[i]);
        }
    }
 
 
    bool operator==(Stack& other) {
        bool is_same = true;
        if (size == other.size) {
            for (int i = 0; i < size; i++) {
                if (p_list[i] != other.p_list[i]) {
                    is_same = false;
                    break;
                }
            }
        }
        else {
            is_same = false;
        }
        return is_same;
    }
    int get_num_stacks() { return numStacks; }
 
};
 
class SpyStack {
public:
    void print_all_info(Stack& s) {
        
        s.print();
    }
};
 
int get_num_common_items(Stack& s1, Stack& s2) {
    int num_common_items = 0;
    for (int i = 0; i < s1.size; i++) {
        if (s2.find_index(s1.p_list[i]) >= 0) {
            num_common_items++;
        }
    }
    return num_common_items;
}
 
int Stack::numStacks = 0;
 



int main()
{
	Stack s1, s2;
	s1.push(1);
	s1.push(2);
	s1.push(3);

	s2.push(1);
	s2.push(2);
	s2.push(5);

	s1.print();
	s2.print();

	s1 += s2;

	s1.print();
	s2.print();
	cout << "s1 == s2 ? " << (s1 == s2) << endl;

	s1.pop(); // 5 out
	s1.pop(); // 3 out
	s2.pop(); // 5 out
	cout << "s1 == s2 ? " << (s1 == s2) << endl;


	return 0;
}