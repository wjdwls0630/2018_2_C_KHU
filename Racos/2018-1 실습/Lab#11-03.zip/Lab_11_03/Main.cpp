#include <iostream>
#include <list>
#include <cmath>
using namespace std;


//sum, mean, var, stddev, normalization함수 작성
double sum(list<double> d)
{
   double sum = 0;
   list<double>::iterator iter = begin(d);
   for (iter = begin(d); iter != end(d); iter++)
   {
      sum += *iter;
   }
   return sum;
}
double mean(list<double> d)
{
   
   return sum(d) / d.size();
}
double var(list<double> d)
{
   double var = 0;
   list<double>::iterator iter = begin(d);
   for (iter = begin(d); iter != end(d); iter++)
   {
      var += pow((*iter - mean(d)), 2);
   }
   return var / d.size();
   
}
double stddev(list<double>d)
{
   return sqrt(var(d));
}
void print(list<double>d)
{
   list<double>::iterator iter = begin(d);
   for(iter=begin(d); iter!= end(d); iter++)
   {
      cout << *iter <<" ";
   }
}
void normalization(list<double>d)
{
   double temp=0;
   list<double>::iterator iter = begin(d);
   for(iter = begin(d); iter!=end(d); iter++)
   {
      temp = (*iter-mean(d))/stddev(d);
      cout << temp <<' ';
   }
}
int main()
{
   //아래의 list1 사용
   double double_arr[10] = { 644.4, 381.65, 844.92, 430.42, 79.87, 225.03, 823.27, 317.29, 788.4, 426.12 };
   list<double> list1;
   for (int i = 0; i < 10; i++)
      list1.push_back(double_arr[i]);
   cout <<"sum : "<< sum(list1) << endl;
   cout <<"mean : "<< mean(list1) << endl;
   cout <<"var : "<< var(list1) << endl;
   cout << "stddev : "<<stddev(list1) << endl;
   cout << "before normalization" << endl;
   print(list1);
   cout << endl;
   cout << "after normalization" << endl;
   normalization(list1);
   
   return 0;
}