#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
	int a, b;
	do
	{
		cout << "num1 : ";
		cin >> a;
		cout << "num2 : ";
		cin >>b;
		if(a!=b)
		{
		cout<<"num1 != num2"<<endl;
		}
		else 
		{
		cout<<"num1 == num2"<<endl;
		break;
		}
	}
	while(true);
	
	return 0;
}

