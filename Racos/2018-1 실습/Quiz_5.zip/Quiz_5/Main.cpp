
#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>
#include <vector>
using namespace std;

class Student
{
private:
	string name;
	int number;
	string major;
	vector<string> list;
	vector<char> grade;

public:
	Student();
	~Student();
	Student(string n, int num, string maj);
	void setName(string n);
	void setID(int num);
	void setdept(string maj);
	void print();
	void addGrade(string a, char b);
	void print_worst_grade();
	void print_best_grade();

	float getGPA();
};


Student::Student()
{
}

Student::Student(string n, int num, string maj)
{
	this->name = n;
	this->number = num;
	this->major = maj;
}


Student::~Student()
{
}

void Student::setName(string n)
{
	(*this).name = n;
}
void Student::setID(int num)
{
	(*this).number = num;
}
void Student::setdept(string maj)
{
	(*this).major = maj;
}
void Student::print()
{
	cout << name << " " << endl;
	cout << number << " " << endl;
	cout << major << endl;
}

void Student::addGrade(string a, char b)
{
	list.push_back(a);
	grade.push_back(b);
}
	void Student::print_worst_grade()
	{}
	void Student::print_worst_grade()
	{}



float Student::getGPA()
{
	float result = 0;
	for (unsigned int i = 0; i < grade.size(); i++)
	{
		int a = 0;
		char b = grade[i];
		switch (b)
		{
		case 'A': a = 4; break;
		case 'B': a = 3; break;
		case 'C': a = 2; break;
		case 'D': a = 1; break;
		case 'F': a = 0; break;
      }

      result += a;
   }
   return result / grade.size();
}





int main()
{
	Student jobs("jobs", 2017101010, "Korean");
	jobs.print();
	

	jobs.addGrade("OOP", 'F');
	jobs.addGrade("Computer netwok", 'B');
	jobs.addGrade("Computer structure", 'C');
	jobs.addGrade("Computer graphics", 'D');
	

	cout << jobs.getGPA() << endl;
	
	


	Student Wozniak("Wozniak", 2016101010, "computer");
	Wozniak.print();
	

	Wozniak.addGrade("OOP", 'F');
	Wozniak.addGrade("Computer netwok", 'D');
	Wozniak.addGrade("Computer structure", 'B');
	Wozniak.addGrade("Computer graphics", 'C');

	

	cout << Wozniak.getGPA() << endl;



	Student Gates;

	Gates.setName("Gates");
	Gates.setID(2018101010);
	Gates.setdept("Architecture");

	Gates.print();
	

	Gates.addGrade("OOP", 'F');
	Gates.addGrade("Computer netwok", 'A');
	Gates.addGrade("Computer structure", 'D');
	Gates.addGrade("Computer graphics", 'C');


	cout << Gates.getGPA() << endl;


	return 0;
}

