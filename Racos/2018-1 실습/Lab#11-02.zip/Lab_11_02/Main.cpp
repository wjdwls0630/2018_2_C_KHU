#include <iostream>
#include <string>
#include <list>
using namespace std;

template<typename T1, typename T2>

int compare(const T1& a, const T2& b)
{
   if (a == b)
      return 1;
   else if (a > b)
      return 0;
   else
      return 2;
}
template <typename T>
void ascend_sort(T arr[])
{
   
   T temp = 0;
   for (int i = 0; i < 10; i++)
   {
      for (int j = 0; j < 9; j++)
      {
         if (compare(arr[j],arr[j + 1])==0)
         {
            temp = arr[j];
            arr[j] = arr[j + 1];
            arr[j + 1] = temp;
         }
      }

   }
   for (int i = 0; i < 10; i++)
   {
      cout << arr[i] << " ";
   }
   cout << "\n";
}
template <typename T>
void descend_sort(T arr[])
{

   T temp = 0;
   for (int i = 0; i < 10; i++)
   {
      for (int j = 0; j < 9; j++)
      {
         if (compare(arr[j], arr[j + 1]) == 2)
         {
            temp = arr[j];
            arr[j] = arr[j + 1];
            arr[j + 1] = temp;
         }
      }

   }
   for (int i = 0; i < 10; i++)
   {
      cout << arr[i] << " ";
   }
   cout << "\n";
}

int main()
{
   //아래의 배열 사용
   int int_arr[10] = { 168, 752, 500, 436, 89, 112, 275, 508, 779, 377 };
   double double_arr[10] = { 644.4, 381.65, 844.92, 430.42, 79.87, 225.03, 823.27, 317.29, 788.4, 426.12 };
   cout << "Ascending sort of integer array" << "\n";
   ascend_sort(int_arr);
   cout << "Descending sort of integer array" << "\n";
   descend_sort(int_arr);
   cout << "Ascending sort of double array" << "\n";
   ascend_sort(double_arr);
   cout << "Descending sort of double array" << "\n";
   descend_sort(double_arr);
   return 0;
}