#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
	int a, b;
	
	
	do
	{	cout << "num1 : ";
	cin >> a;
	cout << "num2 : ";
	cin >>b;
	cout <<endl;

	}
	while(a!=b);
	cout<<"num1==num2";
	return 0;
}

