#include <iostream>

using namespace std;

int main() 

{

	int num1, num2, in, num;

 

		cout<<"1. 같은 수 찾기"<<endl<<"2. 홀수 짝수 찾기"<<endl<<"3. Lab#04-5"<<endl;

		cin>>in;

		switch (in)

		{

			case 1://같은 수 찾기

				cout<<"num1 : ";

				cin>>num1;

				cout<<"num2 : ";

				cin>>num2;

				if(num1==num2)

					cout<<"num1 == num2"<<endl<<endl<<endl;

				else

					cout<<"num1 != num2"<<endl<<endl<<endl;

				

				break;

				

			case 2://홀짝찾기

				cout<<"num : ";

				cin>>num;

				if(num%2==1)

					cout<<"odd number"<<endl<<endl<<endl;

				else

					cout<<"even number"<<endl<<endl<<endl;

				break;

				

			case 3://랩

				cout<<"num : ";

				cin>>num;

				for(int i=num;i>=1;i--)

				{

					for(int j=1;j<=i;j++)

						cout<<j<<" ";

						cout<<endl;

				}

				cout<<endl<<endl;

				break;

				

			default:

				cout<<"error";

		}

	

	return 0;

}