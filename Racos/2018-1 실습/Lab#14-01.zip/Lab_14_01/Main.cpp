#include <iostream>
#include <vector>
using namespace std;

class Stack
{
private:
	vector<int> v_list;
	int size;
	int MAX_SIZE;
public:
	Stack(int MAX_SIZE = 1000);
	~Stack();
	int find_index(int item);
	void push(int item);
	int pop();
	void print() const;
	int get_size();
	int get_item(int index);
};
Stack::Stack(int MAX_SIZE)
{
	vector<int> v_list(0);
	size = 0;
	//vector 크기
}
Stack::~Stack()
{
	v_list.clear();
	size = 0;
}
int Stack::find_index(int item)
{
	int check = -1;
	for (unsigned i = 0; i < size; i++)
	{
		if (v_list.at(i) == item)
			check = i;
	}
	return check;
}
void Stack::push(int item)
{
	if (find_index(item) == -1)
	{
		v_list.push_back(item);
		size++;
	}
}
int Stack::pop()
{
	v_list.pop_back();
	size--;
	return v_list.at(size - 1);
}
void Stack::print() const
{
	cout << "Items in the list: ";
	for (unsigned i = 0; i < size; i++)
	{
		cout << v_list.at(i) << ",";
	}
	cout << endl;
}
int Stack::get_size()
{
	return size;
}
int Stack::get_item(int index)
{
	return v_list.at(index);
}
int main()
{
	Stack s1;
	s1.push(4);
	s1.push(4);
	s1.push(2);
	s1.push(2);
	s1.push(1);
	s1.push(5);
	s1.print();

	s1.pop();
	s1.print();
	cout << "Size of Stack: " << s1.get_size() << endl;

	try
	{
		int index = 2, item_val = 1;
		cout << "The value at " << index << " th index: " << s1.get_item(index) << endl;
		cout << item_val << " is located at " << s1.find_index(item_val) << endl;

		index = 5, item_val = 100;
		cout << "The value at " << index << " th index: " << s1.get_item(index) << endl;
		cout << item_val << " is located at " << s1.find_index(item_val) << endl;
	}
	catch (exception&e)
	{
		cout << e.what() << endl;
	}
	return 0;
}

/*
#include <iostream>
#include <vector>
using namespace std;

class Stack
{
private:
   vector<int> v_list;
   int MAX_SIZE;
public:
   Stack(int MAX_SIZE = 1000);
   ~Stack();
   int find_index(int item);
   void push(int item);
   int pop();
   void print() const;
   int get_size();
   int get_item(int index);
};
Stack::Stack(int MAX_SIZE)
{
   vector<int> v_list(0);
}
Stack::~Stack()
{
   v_list.clear();
}
int Stack::find_index(int item)
{
   int check = -1;
   for (unsigned i = 0; i < v_list.size(); i++)
   {
      if (v_list[i] == item)
         check = i;
   }
   return check;
}
void Stack::push(int item)
{
   if (find_index(item) == -1)
   {
      v_list.push_back(item);
      
   }
}
int Stack::pop()
{
   v_list.pop_back();
   return v_list[v_list.size()-1];
}
void Stack::print() const
{
   cout << "Items in the list: ";
   for (unsigned i = 0; i < v_list.size(); i++)
   {
      cout << v_list[i] << ",";
   }
   cout << endl;
}
int Stack::get_size()
{
   return v_list.size();
}
int Stack::get_item(int index)
{
   return v_list.at(index);
}
int main()
{
   Stack s1;
   s1.push(4);
   s1.push(4);
   s1.push(2);
   s1.push(2);
   s1.push(1);
   s1.push(5);
   s1.print();

   s1.pop();
   s1.print();
   cout << "Size of Stack: " << s1.get_size() << endl;

   try
   {
      int index = 2, item_val = 1;
      cout << "The value at " << index << " th index: " << s1.get_item(index) << endl;
      cout << item_val << " is located at " << s1.find_index(item_val) << endl;

      index = 5, item_val = 100;
      cout << "The value at " << index << " th index: " << s1.get_item(index) << endl;
      cout << item_val << " is located at " << s1.find_index(item_val) << endl;
   }
   catch (exception&e)
   {
      cout << e.what() << endl;
   }
   return 0;
}

*/