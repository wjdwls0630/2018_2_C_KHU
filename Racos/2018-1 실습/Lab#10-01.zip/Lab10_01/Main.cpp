#include<iostream>
#include<iomanip>
#include<vector>
#include<string>
using namespace std;

//unit
class Pos2D
{
private:
   int x;
   int y;
public:
   Pos2D(int x1 = 0, int y1 = 0);
   int getX(); 
   int getY();
   void setX(int x1);
   void setY(int y1);
};
Pos2D::Pos2D(int x1, int y1)
   : x(x1), y(y1)
{
}
int Pos2D::getX() 
{ 
   return x; 
}
int Pos2D::getY()
{ 
   return y; 
}
void Pos2D::setX(int x1)
{ 
   x = x1; 
}
void Pos2D::setY(int y1) 
{
   y = y1; 
}

class Pos3D : public Pos2D
{
private:
   string whereisunit[3];
   string location;
public:
   Pos3D();
   void setloc(int i);
   void printloc();
};

Pos3D::Pos3D()
{
   whereisunit[0] = "Ground";
   whereisunit[1] = "Hill";
   whereisunit[2] = "Air";
}
void Pos3D::setloc(int i)
{ 
   location = whereisunit[i];
}
void Pos3D::printloc()
{ 
   cout << location << endl; 
}


class Unit
{
private:
   Pos3D pos;
   float attackPoint;
   float energy;
public:
   Unit();
   Unit(int a, int b, float atkP, float e, int l);
   float getattackPoint();
   float getenergy();
   void setpos(int a, int b, int l);
   void setattackPoint(float atkP);
   void setenergy(float e);
   void print();
   virtual void activeSpecialAbility() = 0;
};
Unit::Unit() 
{
}
Unit::Unit(int a, int b, float atkP, float e, int l)
   : attackPoint(atkP), energy(e)
{
   pos.setX(a); pos.setY(b); pos.setloc(l);
}
float Unit::getattackPoint() 
{
   return attackPoint; 
}
float Unit::getenergy() 
{
   return energy;
}
void Unit::setpos(int a, int b, int l) 
{
   pos.setX(a); pos.setY(b); pos.setloc(l);
}
void Unit::setattackPoint(float atkP) 
{
   attackPoint = atkP;
}
void Unit::setenergy(float e)
{
   energy = e;
}
void Unit::print()
{
   cout << pos.getX() << ", " << pos.getY() << ", " << attackPoint << ", " << energy << ", ";
   pos.printloc();
}


//Zergling
class Zergling : public Unit
{
private:
   int numberOfDefenseUp;
public:
   Zergling(int x, int y, int l);
   void activeSpecialAbility();
};
Zergling::Zergling(int x, int y, int l) 
   : numberOfDefenseUp(3)
{
   setpos(x, y, l);
   setattackPoint(21.5f);
   setenergy(50.0f);
}
void Zergling::activeSpecialAbility()
{
   if (numberOfDefenseUp != 0)
   {
      numberOfDefenseUp--;
      cout << "DefenseUp is active" << endl;
   }
   else
      cout << "DefenseUp is inactive" << endl;
}

//Marine
class Marine : public Unit
{
private:
   bool isSteamPacked;
public:
   Marine(int x, int y, int l);
   void activeSpecialAbility();
};
Marine::Marine(int x, int y, int l) 
   : isSteamPacked(true)
{
   setpos(x, y, l);
   setattackPoint(32.1f);
   setenergy(104.0f);
}
void Marine::activeSpecialAbility()
{
   if (isSteamPacked)
   {
      setattackPoint(getattackPoint()*1.5f);
      setenergy(getenergy() - 20.0f);
      cout << "SteamPack is active" << endl;
      isSteamPacked = false;
   }
   else
      cout << "SteamPack is inactive" << endl;
}

//BattleCruiser
class BattleCruiser : public Unit
{
private:
   int numberOfYamato;
public:
   BattleCruiser(int x, int y, int l);
   void activeSpecialAbility();
};
BattleCruiser::BattleCruiser(int x, int y, int l) 
   : numberOfYamato(3)
{
   setpos(x, y, l);
   setattackPoint(82.4f);
   setenergy(250.0f);
}
void BattleCruiser::activeSpecialAbility()
{
   if (numberOfYamato != 0)
   {
      numberOfYamato--;
      cout << "Yamato is active" << endl;
   }
   else
      cout << "Yamato is inactive" << endl;
}

int main()
{

   Unit* p[3] = { new Marine(2,4,3), new Zergling(4,7,1), new BattleCruiser(6,3,1) };
   for (int i = 0; i < 3; i++)
      p[i]->activeSpecialAbility();
   for (int i = 0; i < 3; i++)
      delete p[i];
   return 0;
}