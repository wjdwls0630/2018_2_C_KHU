#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>
#include <vector>
using namespace std;

class Student
{
private:
   string name;
   int number;
   string major;
   vector<string> list;
   vector<char> grade;

public:
   Student();
   ~Student();
   Student(string n, int num, string maj);
   void setName(string n);
   void setID(int num);
   void setdept(string maj);
   void print();
   void addGrade(string a, char b);
   void printGrades();

};


Student::Student()
{
}

Student::Student(string n, int num, string maj)
{
   this->name = n;
   this->number = num;
   this->major = maj;
}


Student::~Student()
{
}

void Student::setName(string n)
{
   (*this).name = n;
}
void Student::setID(int num)
{
   (*this).number = num;
}
void Student::setdept(string maj)
{
   (*this).major = maj;
}
void Student::print()
{
   cout << name << " " << number << " " << major << endl;
}

void Student::addGrade(string a, char b)
{
   list.push_back(a);
   grade.push_back(b);
}

void Student::printGrades()
{
   for (unsigned int i = 0; i < grade.size(); i++)
   {
      cout << list[i] << " " << grade[i] << endl;
   }
}


int main()
{
   Student harry("Harry", 2017101234, "SWCON");
   Student ron;

   harry.addGrade("Programming", 'B');
   harry.addGrade("English", 'A');
   harry.addGrade("Writing", 'B');
   
  
   harry.printGrades();

   return 0;
}
