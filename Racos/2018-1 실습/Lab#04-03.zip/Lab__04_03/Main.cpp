#include <iostream>

using namespace std;

int main()
{

 	double set, now;
int re=1;
while(re<=3)
{
	cout<<"현재온도: ";
	cin>>now;
	cout<<"설정온도: ";
	cin>>set;

	if(now-set>4)
		cout<<"에어컨 강하게 작동"<<endl;
	else if(now-set>2)
		cout<<"에어컨 약하게 작동"<<endl;

	else if(now-set<-4)
		cout<<"히터 강하게 작동"<<endl;

	else if(now-set<-2)
		cout<<"히터 약하게 작동"<<endl;

	else
 	cout<<"현상유지" <<endl;
	

re++;
}
	while(now!=-100)
{
	cout<<"현재온도: ";
	cin>>now;
	cout<<"설정온도: ";
	cin>>set;

	if(now==-100)
	cout << "프로그램 종료" << endl;
	else if(now-set>4)
		cout<<"에어컨 강하게 작동"<<endl;
	else if(now-set>2)
		cout<<"에어컨 약하게 작동"<<endl;

	else if(now-set<-4)
		cout<<"히터 강하게 작동"<<endl;

	else if(now-set<-2)
		cout<<"히터 약하게 작동"<<endl;

	else
 	cout<<"현상유지" <<endl;
}

return 0;
}
