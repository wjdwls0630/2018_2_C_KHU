#include <iostream>
using namespace std;

void swap(int* a, int* b) 
{
	int temp = *a;
	*a = *b;
	*b = temp;
}
void print(const float* result )
{
	cout << "var1/var2 = " << *result <<endl;
}
	
	
int main() 
{
	int var1 =5, var2=10;
	cout << "var1 = " << var1 << ", var2 = " << var2 <<'\n';
	swap(&var1, &var2);
	cout << "var1 = " << var1 << ", var2 = " << var2 <<'\n';
	float protoresult = (float)var1/var2 ;
	const float* result =&protoresult;
	print(result);
	return 0;
}