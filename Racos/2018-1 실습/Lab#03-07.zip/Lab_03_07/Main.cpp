#include <iostream>
using namespace std;

void swap_call_by_value(int x, int y)
{   int temp = x;
 x=y;
 y=temp;
}

void swap_call_by_reference(int& x, int& y)
{ 
	int temp = x;
 x=y;
 y=temp;
}

void get_data(int& x, int& y)
{
	cout << "두개 정수 입력 : " ;
	cin >> x >> y ;
	
}

int main() 
{
	int x, y;
	
	get_data(x,y);
	cout << "Before swap_call_by_value: x= " <<x << ", y= " << y <<endl;
	 swap_call_by_value(x,y);
	cout << "After swap_call_by_value: x= " <<x << ", y= " << y<<endl;
	cout << "Before swap_call_by_reference: x= " <<x << ", y= " << y <<endl;
	 swap_call_by_reference(x,y);
	cout << "After swap_call_by_reference: x= " <<x << ", y= " << y<<endl;
	

	return 0;
}