#include <iostream>
#include <string>
#include <vector>
using namespace std;

class student
{
	public:
	
	
	private:
	string name, gwa;
	int number;
	vector<string>list;
	vector<char>grade;
}

int main()
{
  
}