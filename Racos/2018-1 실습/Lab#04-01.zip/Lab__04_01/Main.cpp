#include <iostream>
using namespace std;





int main() {

	double a, b;
	cin >>a >>b;
	cout << "현재온도: " <<a <<endl;
	cout << "설정온도: " << b << endl;
	if (a-b>=2)
		cout  << "에어컨 작동" ;
	else if (a-b<=-2)
		cout << "히터 작동" ;
	
	else
		cout << "현상 유지" ;
	
	return 0;
}