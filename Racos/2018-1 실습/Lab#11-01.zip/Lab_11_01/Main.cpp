#include<iostream>
#include<string>
using namespace std;

template<typename T1, typename T2>
int compare(T1 a, T2 b)
{
   if (a > b)
      return 0;
   else if (a < b)
      return 2;
   else
      return 1;
}
int main()
{
   float a=1, b=2.2;
   char c='A', d='S';
   string e="10", f="Z";
   string g = "'ABC'", h = "'ABC'";
   cout << " compare " << a << " and " << b <<" : "<< compare(a, b) << endl;
   cout << " compare " << c << " and " << d << " : " << compare(c, d) << endl;
   cout << " compare " << e << " and " << f << " : " << compare(e, f) << endl;
   cout << " compare " << g << " and " << h << " : " << compare(g, h) << endl;
   return 0;

}