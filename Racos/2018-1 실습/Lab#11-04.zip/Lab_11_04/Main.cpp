#include <iostream>
#include <string>
#include <list>
using namespace std;

template<typename T1, typename T2>

int compare(T1 a, T2 b) {
   if (a > b)
      return 0;
   else if (a == b)
      return 1;
   else
      return 2;
}

int main()
{
   //아래의 배열 사용
   int int_arr[10] = { 168, 752, 500, 436, 89, 112, 275, 508, 779, 377 };
   double double_arr[10] = { 644.4, 381.65, 844.92, 430.42, 79.87, 225.03, 823.27, 317.29, 788.4, 426.12 };

   [](int *arr) {
      for (int i = 0; i < 9; i++) {
         for (int k = i + 1; k < 10; k++)
         {
            if (compare(arr[i], arr[k]) == 0)
            {
               int temp = arr[i];
               arr[i] = arr[k];
               arr[k] = temp;
            }
         }
      }
      cout << "Asceding sort of integer array" << endl;
      for (int i = 0; i < 10; i++)
      {
         cout << arr[i] << " ";
      }
      cout << endl;
   }(int_arr);

   [](int *arr) {
      for (int i = 9; i >= 1; i--) {
         int upper = i;
         for (int k = i - 1; k >= 0; k--)
         {
            if (compare(arr[upper], arr[k]) == 0)
            {
               int temp = arr[i];
               arr[i] = arr[k];
               arr[k] = temp;
            }
         }
      }
      cout << "Descending sort of interger array" << endl;
      for (int i = 0; i < 10; i++)
      {
         cout << arr[i] << " ";
      }
      cout << endl;
   }(int_arr);

   [](double *arr) {
      for (int i = 0; i < 9; i++) {
         for (int k = i + 1; k < 10; k++)
         {
            if (compare(arr[i], arr[k]) == 0)
            {
               double temp = arr[i];
               arr[i] = arr[k];
               arr[k] = temp;
            }
         }
      }
      cout << "Asceding sort of double array" << endl;
      for (int i = 0; i < 10; i++)
      {
         cout << arr[i] << " ";
      }
      cout << endl;
   }(double_arr);

   [](double *arr) {
      for (int i = 9; i >= 1; i--) {
         int upper = i;
         for (int k = i - 1; k >= 0; k--)
         {
            if (compare(arr[upper], arr[k]) == 0)
            {
               double temp = arr[i];
               arr[i] = arr[k];
               arr[k] = temp;
            }
         }
      }
      cout << "Descending sort of double array" << endl;
      for (int i = 0; i < 10; i++)
      {
         cout << arr[i] << " ";
      }
      cout << endl;
   }(double_arr);

   return 0;
}