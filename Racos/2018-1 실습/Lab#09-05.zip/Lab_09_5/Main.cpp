#include <iostream>
#include <vector>
using namespace std;
void print(vector<int> list) {
	for (int i : list)
	cout << i << "  ";
	cout << endl;
}
void clear(vector<int>&  list)
{
	for (int &i : list)
	i = 0;
}
int main() {
	vector<int> list = { 2,4,6,8 };
	print(list);
	clear(list);
	print(list);

	system("pause");
	return 0;
}
