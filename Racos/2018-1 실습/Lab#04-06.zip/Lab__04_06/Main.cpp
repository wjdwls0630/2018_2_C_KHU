#include <iostream>

using namespace std;

int main()
{
	float total = 0;
	float usernum;
	float count = 0;
	while (usernum!=-100)
	{
		cout << "숫자를 입력하시오: ";
		cin >> usernum;
		if (usernum != -100)
		{
			total += usernum;
			count++;
		}
		else
		{cout << "평균은 " << total / count << " 입니다." << endl;}
	}
	return 0;
}