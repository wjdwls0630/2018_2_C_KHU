#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>
using namespace std;
int main() {//이후실행이 안됨
	double sum = 0.0;
	double size;
	cout << "pls enter the number of valuse to process: ";
	cin >> size;
	if (size > 0)
	{
		cout << "pls enter the " << size << "numbers: ";
		vector<double> list(size);//벡터 사이즈 설정
		for (int i = 0; i < size; i++) {
		cin >> list[i];
		sum += list[i];
	}
	cout << "the average of ";
	for (int i = 0; i < size-1; i++)
	{
		cout << list[i] << ", ";
	}
		cout << list[size - 1] << " is " << sum / size << endl;
	}

}
