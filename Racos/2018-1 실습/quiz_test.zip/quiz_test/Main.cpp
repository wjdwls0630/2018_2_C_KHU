#include <iostream>
using namespace std;



void print_string(int IDN);
void print_year(int& IDN);
void print_month(int& IDN);
void print_day(int& IDN);

int main()
{
	int IDN;
	cout << "주민번호 앞자리를 입력하세요 : ";
	cin >> IDN;

	print_string(IDN);
	return 0;
}

/* 작성 */

void print_string(int IDN)
{
	cout << "당신은 " << print_year << "년 " << print_month << "월 " << print_day << "일에 태어났습니다." << endl;
}

void print_year(int IDN)
{
	
cout << "19" << IDN/10000 ;}
void print_month(int& IDN)
{
}
void print_day(int& IDN)
{}