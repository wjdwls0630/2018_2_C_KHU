#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;

int main() {
	int size;
	int temp;
	int jump = 1;
	string line;
	ofstream matrix;
	ifstream ftrix;
	matrix.open("ntrix");
	ftrix.open("ntrix");
	cout << "pls enter the table size : ";
	cin >> size;
	cout << "      ";
	for (int column = 1; column <= size; column++) {
		cout << setw(4) << column;
	}
	cout << '\n';
	cout << "     +";
	for (int column = 1; column <= size; column++) {
		cout << "----";
	}
	cout << '\n';
	for (int row = 1; row <= size; row++) {
		cout << setw(4) << row << " |";
		for (int column = 1; column <= size; column++) {
			cout << setw(4) << row * column;
			matrix << setw(4) << row * column;
		}
		cout << '\n';
		matrix << '\n';
	}
	matrix.close();
	cout << "몇번째 row 출력? : ";
	cin >> temp;
	while (getline(ftrix, line)) 
	{
		if (jump == temp) {
			cout << line << '\n';
		}
		jump++;
	}
	ftrix.close();
	return 0;
}