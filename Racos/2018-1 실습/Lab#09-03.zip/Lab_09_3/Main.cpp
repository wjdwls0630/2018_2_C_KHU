#include <iostream>
#include <vector>

using namespace std;

int main() 
{
	double sum = 0.0;
	const int NUMBER_OF_ENTRIES = 5;
	vector<double> numbers(NUMBER_OF_ENTRIES);
	int a = numbers.size();
	cout << "Please enter " << a << " numbers: ";
	
	for (double &input : numbers) 
	{
		cin >> input;
	}
	
	cout << "The average of ";
	for (double result : numbers)
	{
		cout << result << ", ";
		sum+=result;
	}
		cout << numbers[a - 1] << " is "<< sum/a <<'\n';
}