#include <iostream>
#include <vector>
#include <iomanip>
using namespace std;
using Matrix = vector<vector<double>>;
void populate_matrix(Matrix& m)
{
	cout << "enter the" << m.size() << "rows of matrix" << endl;
	for (unsigned row = 0; row < m.size(); row++)
	{
		cout << "Row #" << row << " (enter " << m[row].size() << "valuse):";
		for (double& elem : m[row])
		{cin >> elem;}
	}
}
void print_matrix(const Matrix m) 
{
	for (auto row : m)
	{
		for (double elem : row)
		{
			cout << setw(5) << elem;
		}
	cout << endl;
	}
}
int main() {
	int rows, columns;
	cout << "how many rows? ";
	cin >> rows;
	cout << "how many columns? ";
	cin >> columns;
	Matrix mat(rows, vector<double>(columns));
	populate_matrix(mat);
	print_matrix(mat);
	
	
	return 0;
}

/* 2차원벡터 지정
#include <iostream>
#include <vector>
#include <iomanip>
#include <ctime>
using namespace std;
int main()
{
	int i = 0;
	int j = 0;
	cout << "차원 입력";
	cin >> i >> j;
	using M = vector<vector<int>>;
	M vec(i, vector<int>(j));
	for (int x = 0; x < i; x++)
	{
		for (int y = 0; y < j; y++)
		{
			vec[x][y] = x + y;
			cout << vec[x][y] << " ";
		}
		cout << endl;
	}
}
*/