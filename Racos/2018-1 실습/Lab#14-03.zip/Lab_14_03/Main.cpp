#include <iostream>
#include <fstream>
#include <string>
using namespace std;

class PDexception : public std::exception
{
	string message;
public:
	PDexception(const string &fname) : message("Error : File \"" + fname + "\" not found")
	{}
	virtual const char* what() const throw ()
	{
		return message.c_str();
	}
};
void check_file(const string &fname);

int main()
{
	ifstream ifs_tree;
	try
	{
		check_file("tree.txt");
	}
	catch (exception &e)
	{
		cout << e.what() << '\n';
	}

	ofstream ofs_tree("tree.txt");

	int height;
	string tree;
	int row = 0;

	cout << "Enter height of tree: ";
	cin >> height;
	cout << "Enter character of tree: ";
	cin >> tree;

	int i = 0;

	while (row < height)
	{
		int count = 0;
		while (count < height - row)
		{
			cout << " ";
			ofs_tree << " ";
			count++;
		}
		count = 0;
		while (count < 2 * row + 1)
		{
			if (i == tree.length())
				i = 0;
			cout << tree[i];
			ofs_tree << tree[i];
			i++;
			count++;
		}
		cout << '\n';
		ofs_tree << '\n';
		row++;
		if (row == height)
		{
			row--;
			int count2 = 0;
			cout << " ";
			ofs_tree << " ";
			while (count2 < 2 * row + 1)
			{
				cout << "-";
				ofs_tree << "-";
				count2++;
			}
			cout << '\n';
			ofs_tree << '\n';
			count2 = 0;
			row = 0;

			while (count2 < height - row - 1)
			{
				cout << " ";
				ofs_tree << " ";
				count2++;
			}
			row = height;
			if (row > 2)
			{

				cout << "|||\n";
				ofs_tree << "|||\n";
			}

			else
			{
				std::cout << " |\n";
				ofs_tree << " |\n";
			}
		}
	}
	ofs_tree.close();
	ifs_tree.close();
}
void check_file(const string &fname)
{
	ifstream ifs(fname);
	if (ifs.is_open())
	{
		string line;
		while (getline(ifs, line))
		{
			cout << line << '\n';
		}
	}
	else
	{
		throw PDexception(fname);
	}
}