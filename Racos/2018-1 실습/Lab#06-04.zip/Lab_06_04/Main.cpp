#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int add(int &a, int &b);
int subtract(int &a, int &b);
int multiply(int &a, int &b);
float divide(int &a, int &b);

int main()
{


	ofstream prac4out;
	prac4out.open("prac4.txt");


	if (!prac4out)
	{
		cout << "Error 100 opening prac4.txt";
		exit(100);
	}


	string option;
	int  v1, v2;

	while (1)
	{
		cout << "\n 어떤 사칙연산을 하시겠습니까? \n add \n substract \n multiply \n divide \n stop(프로그램 종료) \n  " << endl;
		cout << " ";
		prac4out << "\n 어떤 사칙연산을 하시겠습니까? \n add \n substract \n multiply \n divide \n stop(프로그램 종료) \n  " << endl;
		prac4out << " ";
		cin >> option;
		prac4out << option;

		if (option == "stop")
		{
			prac4out << "stop" << endl;
			break;
		}

		cout << "\n 두 수를 입력하세요 : ";
		prac4out << "\n 두 수를 입력하세요 : ";
		cin >> v1 >> v2;
		prac4out << v1 << " " << v2;
		cout << "\n 답: ";
		prac4out << "\n 답: ";


		if (option == "add")
		{
			cout << add(v1, v2) << endl;
			prac4out << add(v1, v2) << endl;
		}
		if (option == "subtract")
		{
			cout << subtract(v1, v2) << endl;
			prac4out << subtract(v1, v2) << endl;
		}
		if (option == "multiply")
		{
			cout << multiply(v1, v2) << endl;
			prac4out << multiply(v1, v2) << endl;
		}
		if (option == "divide")
		{
			cout << divide(v1, v2) << endl;
			prac4out << divide(v1, v2) << endl;
		}
	}

	cout << " \n\n ---------  prac4 text 파일 출력 ---------- " << endl;

	string line;
	ifstream prac4in;
	prac4in.open("prac4.txt");


	while (getline(prac4in, line))
	{
		cout << line << endl;
	}

	prac4in.close();
	prac4out.close();



	return 0;
}


int add(int &a, int &b)
{
	return a + b;
}

int subtract(int &a, int &b)
{
	return a - b;
}

int multiply(int &a, int &b)
{
	return a * b;
}

float divide(int &a, int &b)
{
	return (float)a / b;
}

