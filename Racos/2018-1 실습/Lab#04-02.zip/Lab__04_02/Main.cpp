#include <iostream>

using namespace std;

int main()

{

 

	double set, now;

	

	cout<<"현재온도: ";

	cin>>now;

	cout<<"설정온도: ";

	cin>>set;

	

	if(now-set>=4)

		cout<<"에어컨 강하게 작동";

	

	else if(now-set>2)

		cout<<"에어컨 약하게 작동";

	

	else if(now-set<=-4)

		cout<<"히터 강하게 작동";

	

	else if(now-set<-2)

		cout<<"히터 약하게 작동";

	

	else

		cout<<"현상유지";

	

	return 0;

}