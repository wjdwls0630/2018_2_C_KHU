#include <iostream>
using namespace std;

int main()
{
	int a[] = { 2, 4, 6, 8, 10, 12, 14, 16, 18, 20 }, 
	char *p;
	p =&a[0];  //char랑 int 가 다르니까
	for (int i = 0; i < 10; i++) 
	{
		cout << *p <<" "; 
		p++;  
	}	
	
	cout <<'\n';
}

