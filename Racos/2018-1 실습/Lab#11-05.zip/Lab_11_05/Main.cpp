#include <iostream>
#include <list>
#include <cmath>
using namespace std;

int main()
{
   //아래의 list1 사용
   double double_arr[10] = { 644.4, 381.65, 844.92, 430.42, 79.87, 225.03, 823.27, 317.29, 788.4, 426.12 };
   list<double> list1;
   for (int i = 0; i < 10; i++)
      list1.push_back(double_arr[i]);

   double mean = 0;
   double var = 0;
   double stddev = 0;

   [](list<double> list1) {
      double sum = 0.;
      for (auto iter = begin(list1); iter != end(list1); iter++)
      {
         sum += *iter;
      }
      cout << "sum : " << sum << endl;
   }(list1);

   [](list<double> list1, double& mean) {
      double sum = 0.;
      int count = 0;
      for (auto iter = begin(list1); iter != end(list1); iter++)
      {
         sum += *iter;
         count++;
      }
      mean = sum / count;
      cout << "mean : " << mean << endl;
   }(list1, mean);

   [](list<double> list1, double mean, double& var) {
      double sum = 0;
      int count = 0;
      for (auto iter = begin(list1); iter != end(list1); iter++)
      {
         sum += pow((*iter - mean), 2);
         count++;
      }
      var = sum / count;
      cout << "var : " << var << endl;
   }(list1, mean, var);

   [](list<double> list1, double var, double& stddev) {
      stddev = sqrt(var);
      cout << "stddev : " << stddev << endl;
   }(list1, var, stddev);

   cout << "before normalization" << endl;
   for (auto iter = begin(list1); iter != end(list1); iter++)
   {
      cout << *iter << " ";
   }

   cout << endl << "after normalization" << endl;
   for (auto iter = begin(list1); iter != end(list1); iter++) {
      {
         cout << (*iter - mean) / stddev << " ";
      }
   }
   cout << endl;

   return 0;
}