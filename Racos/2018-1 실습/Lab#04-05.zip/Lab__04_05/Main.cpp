#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
	int set, count;
	cout << "몇줄? : ";
	cin >> set;
	count = 1;
	while (set >= count)
	{
		while (count <= set)
		{
			cout << setw(2) <<count ;
			count++;
		}
		cout << endl;
		count = 1;
		set--;
	}

	return 0;
}