#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int add(int &a, int &b);
int subtract(int &a, int &b);
int multiply(int &a, int &b);
float divide(int &a, int &b);

int main()
{


	string op;
	int  v1, v2;

	while (1)
	{
		cout << "\n 어떤 사칙연산을 하시겠습니까? \n add \n substract \n multiply \n divide \n stop(프로그램 종료) \n  " << endl;
		cout << " ";

		cin >> op;

		if (op == "stop")
			break;

		cout << "\n 두 수를 입력하세요 : ";
		cin >> v1 >> v2;
		cout << "\n 답: ";


		if (op == "add")
		{
			cout << add(v1, v2) << endl;
		}
		if (op == "subtract")
		{
			cout << subtract(v1, v2) << endl;
		}
		if (op == "multiply")
		{
			cout << multiply(v1, v2) << endl;
		}
		if (op == "divide")
		{
			cout << divide(v1, v2) << endl;
		}
	}


	return 0;
}


int add(int &a, int &b)
{
	return a + b;
}

int subtract(int &a, int &b)
{
	return a - b;
}

int multiply(int &a, int &b)
{
	return a * b;
}

float divide(int &a, int &b)
{
	return (float)a / b;
}

