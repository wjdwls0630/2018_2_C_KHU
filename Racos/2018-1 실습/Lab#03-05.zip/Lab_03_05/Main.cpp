#include <iostream>
using namespace std;

int increment(int x){
	cout << "beginnig  execution of the increment , x=  " << x << endl;
	x++ ;
	
	cout << "end execution of the increment , x= " << x << endl;
	return x;
}
//증가되지 않았던 이유 = 함수 안에서만 적용 -- 함수종료후에는 원상복귀(로컬변수)

int main() {
	int x=5;
	cout  << "before incrment = " << x << endl;
	x=increment(x);
	
	cout << "after increment = " << x;
	
	
	
	
	
	
	
	
	return 0;
}