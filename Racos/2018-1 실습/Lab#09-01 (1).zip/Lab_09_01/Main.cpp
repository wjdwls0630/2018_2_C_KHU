#include <iostream>
using namespace std;

class Stack
{
private:
   int* p_list;
   int size;
   int MAX_SIZE;

public:
   Stack(int _MAX_SIZE = 1000) {
      MAX_SIZE = _MAX_SIZE;
      p_list = new int[MAX_SIZE];
      size = 0;
   }
   ~Stack()
   {
      delete[] p_list;
   }
   void push(int _item)
   {
      if (size < MAX_SIZE)
      {
         int index = find_index(_item);
         if (index < 0)
         {
            p_list[size] = _item;
            size++;
         }
      }
      else
      {
         cout << "Error: out of memory" << endl;
      }
   }
   int pop()
   {
      if (size > 0)
      {
         size--;
         return p_list[size];
      }
      else
      {
         cout << "Error: No item exists in the list" << endl;
         return -1;
      }
   }
   void print() const
   {
      cout << "Items in the list: ";
      for (int i = 0; i < size; i++)
      {
         cout << p_list[i] << ",";
      }
      cout << endl;
   }
   int get_size() { return size; }
   int get_item(int _index)
   {
      int item = -1;
      if (_index < size)
      {
         return p_list[_index];
      }
      else
      {
         return item;
      }
   }
   int find_index(int _item)
   {
      int index = -1;
      for (int i = 0; i < size; i++)
      {
         if (_item == p_list[i])
         {
            return i;
         }
      }
      return index;
   }
};

int main()
{
   Stack s1;
   s1.push(4);    //아이템 추가
   s1.push(4);
   s1.push(2);
   s1.push(2);
   s1.push(1);
   s1.push(5);
   s1.print();
   s1.pop();   //아이템 제거
   s1.print();
   cout << "Size of Stack: " << s1.get_size() << endl; //현재 크기
   int index = 2, item_val = 1;
   cout << "The value at " << index << " th index: " << s1.get_item(index) << endl;
   cout << item_val << " is located at " << s1.find_index(item_val) << endl;
   index = 5, item_val = 100;
   cout << "The value at " << index << " th index: " << s1.get_item(index) << endl;
   cout << item_val << " is located at " << s1.find_index(item_val) << endl;
   return 0;
}