#include <iostream>
using namespace std;
 
int pow_int(int x, int y){
  if (y==0)
		return 1;
	else 
		return x* pow_int(x, y-1);
}
int main() {
	int x,y ;
	cout << "정수 2개 입력 : " ;
  cin >> x >> y ;
	cout <<pow_int(x,y);
	
	
	
	
	
	return 0;
}