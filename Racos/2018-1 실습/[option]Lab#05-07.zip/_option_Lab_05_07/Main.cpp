#include <iostream>

using namespace std;

int main() 

{
	int cash, sum, op;
	cash=0;
	sum=0;

	while(cash<500)//500원 이상 돈넣기
	{
		cout<<"insert coin : ";
		cin>>cash;
		sum+=cash;

	}


	while(sum>=500)

	{

		cout<<"coin : "<<sum<<endl;//합계 출력
		cout<<"[select menu]"<<endl
			<<"[1] coke -> 500"<<endl
			<<"[2] sprite -> 500"<<endl
			<<"[3] fanta -> 500"<<endl
			<<"[4] hot6 -> 500"<<endl
			<<"[5] terminate"<<endl;

			cin>>op;

		switch(op)

		{
			case 1:
				sum=sum-500;
				break;

			case 2:
				sum=sum-500;
				break;

			
			case 3:
				sum=sum-500;
				break;

			case 4:
				sum=sum-500;
				break;

				case 5:
				cout<<"refund : "<<sum;

				return 0;
		}

	}

			cout<<"refund : "<<sum;

 

	return 0;

}


