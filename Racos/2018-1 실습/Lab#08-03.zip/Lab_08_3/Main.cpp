#include <iostream>
#include <string>
#include <vector>
using namespace std;

class student
{
	public:
	student( string Name, int Number, string Gwa):
	name(Name), number(Number), gwa(Gwa)
	{}
	student()
	{}
	void setName(string a)
	{
		name = a;
	}
	void setID(int a)
	{
	number = a;
	}
	void setdept(string a)
	{
	gwa =a;
	}
	void print()
	{ 
		cout << name <<" " << number << " " << gwa;}
	
	
	private:
	string name;
	string gwa;
	int number;
	vector<string>list;
	vector<char>grade;
};


int main()
{
	student ron;
	ron.setName("Harry");
	ron.setID(2017101234);
	ron.setdept("SWCON");
	ron.print();
	return 0;
}