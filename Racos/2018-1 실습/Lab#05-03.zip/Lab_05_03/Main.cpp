#include <iostream>
#include <iomanip>
#include<cmath>
using namespace std;

int main()
{
	int a, b;

	while(true)
	{
	cout << "num1 : ";
	cin >> a;
	cout << "num2 : ";
	cin >>b;
		if(a!=b)
		{
		cout<<"num1 != num2"<<endl;
		}
		else if((a%2)!=1)
		{
		cout<<"num1 == num2"<<endl;
	  cout<<"even number"<<endl;
		}
		else 
		{
		cout<<"num1 == num2"<<endl;
	  cout<<"odd number"<<endl;
		break;
		}
}
	
	return 0;
}

