#include <iostream>
using namespace std;

int main()
{
	double set;
	double now=24;
	while(set!=-100)
	{
		cout<<"현재온도는 "<<now<<"도 입니다."<<endl;
		cout<<"설정온도: ";
		cin>>set;
		
		if(set==-100)
		{		cout<<"안뇽~"<<endl; }
		
		else if(now-set>4)
		{
			cout<<"에어컨 강하게 작동"<<endl<<endl;
			now-=0.8;
		}
		else if(now-set>2)
		{
			cout<<"에어컨 약하게 작동"<<endl<<endl;
			now-=0.4;
		}
	  else if(now-set<=-4)
		{
			cout<<"히터 강하게 작동"<<endl<<endl;
			now+=1.2;
		}
		else if(now-set<-2)
		{
			cout<<"히터 약하게 작동"<<endl<<endl;
			now+=0.6;
		}
		else
		{
			cout<<"현상유지"<<endl<<endl;
		}
	}

	return 0;

}