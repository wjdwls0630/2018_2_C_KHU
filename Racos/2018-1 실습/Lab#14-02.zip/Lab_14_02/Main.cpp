#include <iostream>
#include <string>
using namespace std;

class PDexception : public exception
{
	string message;
public:
	PDexception()
		: message("Error(out of range)")
	{
	}
	virtual const char* what() const throw ()
	{
		return message.c_str();
	}
};

class Stack
{
private:
	int* p_list;
	int size;
	int MAX_SIZE;
public:
	Stack(int MAX_SIZE = 1000);
	~Stack();
	int find_index(int item);
	void push(int item);
	int pop();
	void print() const;
	int get_size();
	int get_item(int index);
};

Stack::Stack(int MAX_SIZE)
{
	p_list = new int[MAX_SIZE];
	size = 0;
}

Stack::~Stack()
{
	delete[] p_list;
}

int Stack::find_index(int item)
{
	int check = -1;
	for (int i = 0; i < size; i++)
	{
		if (*(p_list + i) == item)
			check = i;
	}
	return check;
}

void Stack::push(int item)
{
	if (size > MAX_SIZE + 1)
	{
		throw PDexception();
	}
	else
	{
		if (find_index(item) == -1)
		{
			*(p_list + size) = item;
			size++;
		}
	}
}

int Stack::pop()
{
	if (size == 0)
	{
		throw PDexception();
	}
	else
	{
		size--;
		return *(p_list + size + 1);
	}
}

void Stack::print() const
{
	cout << "Items in the list: ";
	for (int i = 0; i < size; i++)
	{
		cout << *(p_list + i) << ",";
	}
	cout << endl;
}

int Stack::get_size()
{
	return size;
}

int Stack::get_item(int index)
{
	if (index <= size)
		return *(p_list + index);
	else
		return -1;
}




int main()
{
	Stack s1(2); // MAX_SIZE = 2
	try
	{
		s1.push(1); // [1, x] size = 1
		s1.push(2); // [1, 2] size = 2
		s1.push(3); // out of memory
	}
	catch (exception &e)
	{
		cout << e.what() << endl;
	}
	s1.print();
	try
	{
		s1.pop();
		s1.pop();
		s1.pop(); // no item
		s1.pop(); // no item
	}
	catch (exception &e)
	{
		cout << e.what() << endl;
	}
	s1.print();

	return 0;
}