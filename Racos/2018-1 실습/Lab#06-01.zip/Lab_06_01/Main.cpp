#include <iostream>
#include <string>
#include <fstream>
#include <cmath>
using namespace std;

int main() {
	int height;
	cout << "Enter height of tree: ";
	cin >> height;
	string a;
	cout << "원하는 글자: ";
	cin >> a;
	int size = a.size();
	int row = 0;

	

	ofstream prac1o;

	prac1o.open("prac1.txt");


	while (row < height)
{
	int count = 0;
	while (count < size*(height - row))
	{
		cout << " ";
		prac1o << " ";
		count++;
	}

count = 0;
	while (count < 2 * row + 1)
	{
		cout << a;
		prac1o << a;
		count++;
	}

	cout << endl;
	prac1o << endl;
	row++;
}
	for (int j = 0; j < 5; j++)
	{
		for (int i = 0; i < size*(height / 2 + 1); i++)
		{
			cout << " ";
			prac1o << " ";
		}
		for (int x = 0; x < height; x++)
		{
			cout << a;
			prac1o << a;
		}
		cout << endl;
		prac1o << endl;
	}

	cout << "    ********크리스마스 축하********    " << endl;
	prac1o << "    ********크리스마스 축하********    " << endl;

	prac1o.close();

	cout << " \n  ---------------파일 출력 후 입력---------------    " << endl;

	string line;
	ifstream prac1i;
	prac1i.open("prac1.txt");


	while (getline(prac1i, line))
	{
		cout << line << endl;
	}

	prac1i.close();

	return 0;
}