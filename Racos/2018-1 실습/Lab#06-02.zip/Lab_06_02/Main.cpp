#include<iostream>
#include<cstdlib>
#include<ctime>
#include<fstream>
using namespace std;

void initialize_die() {
	srand(static_cast<unsigned>(time(0)));
}
void show_first(int aspots)
{
	switch (aspots) {
	case 1:
		cout << "|       |\n";
		break;
	case 2:
	case 3:
		cout << "|   *   |\n";
		break;
	case 4:
	case 5:
		cout << "| *   * |\n";
		break;
	case 6:
		cout << "| * * * |\n";
		break;
	default:
		cout << " *** Error: illegal die value ***\n";
		break;
	}
}
void show_second(int aspots)
{
	switch (aspots) {
	case 1:
	case 3:
	case 5:
		cout << "|   *   |\n";
		break;
	case 2:
	case 4:
	case 6:
		cout << "|       |\n";
		break;
	default:
		cout << " *** Error: illegal die value ***\n";
		break;
	}
}
void show_third(int aspots)
{
	switch (aspots) {
	case 1:
		cout << "|       |\n";
		break;
	case 2:
	case 3:
		cout << "|   *   |\n";
		break;
	case 4:
	case 5:
		cout << "| *   * |\n";
		break;
	case 6:
		cout << "| * * * |\n";
		break;
	default:
		cout << " *** Error: illegal die value ***\n";
		break;
	}
}
void show_die(int spots, int aspots) {
	cout << "+-------+\t+-------+\n";
	switch (spots) {
	case 1:
		cout << "|       |\t";
		show_first(aspots);
		cout << "|   *   |\t";
		show_second(aspots);
		cout << "|       |\t";
		show_third(aspots);
		break;
	case 2:
		cout << "|   *   |\t";
		show_first(aspots);
		cout << "|       |\t";
		show_second(aspots);
		cout << "|   *   |\t";
		show_third(aspots);
		break;
	case 3:
		cout << "|   *   |\t";
		show_first(aspots);
		cout << "|   *   |\t";
		show_second(aspots);
		cout << "|   *   |\t";
		show_third(aspots);
		break;
	case 4:
		cout << "| *   * |\t";
		show_first(aspots);
		cout << "|       |\t";
		show_second(aspots);
		cout << "| *   * |\t";
		show_third(aspots);
		break;
	case 5:
		cout << "| *   * |\t";
		show_first(aspots);
		cout << "|   *   |\t";
		show_second(aspots);
		cout << "| *   * |\t";
		show_third(aspots);
		break;
	case 6:
		cout << "| * * * |\t";
		show_first(aspots);
		cout << "|       |\t";
		show_second(aspots);
		cout << "| * * * |\t";
		show_third(aspots);
		break;
	default:
		cout << " *** Error: illegal die value ***\n";
		break;
	}
	cout << "+-------+\t+-------+\n";
}
void printCongrats(int spots, int aspots)
{
	if ((spots == 6) && (aspots == 6))
		cout << "Very lucky!\n";
	else if ((spots == 1) && (aspots == 1))
		cout << "Very unlucky...\n";
	else if ((spots == 5) && (aspots == 5))
		cout << "Pretty lucky\n";
	else if ((spots == 4) && (aspots == 4))
		cout << "lucky\n";
	else
		;
}
int roll() {
	return rand() % 6 + 1;
}
int main() {
	initialize_die();
	int count;
	ofstream oFile("result.txt");

	while (1)
	{
		cout << "주사위 몇 번? (9999입력시 시스템 종료): ";
		cin >> count;
		if (count == 9999)
			break;

		int dice1, dice2;
		for (int i = 0; i < count; i++)
		{
			dice1 = roll();
			dice2 = roll();
			show_die(dice1, dice2);
			printCongrats(dice1, dice2);
			cout << dice1 << " " << dice2 << "\n";
			oFile << dice1 << " " << dice2 << "\n";
		}

	}


	oFile.close();

	cout << "\n ------------ 파일 출력 후 입력 ------------" << endl;

	ifstream iFile("result.txt");
	char c;
	while (iFile.get(c))
		cout << c;
	iFile.close();

	return 0;
}

