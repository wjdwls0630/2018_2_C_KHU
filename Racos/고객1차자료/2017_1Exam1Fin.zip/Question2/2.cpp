#include<iostream>
#include<iomanip>
using namespace std;
int maxValues(int** arr, int num)
{
	int max = 0;
	int i = 0;
	do
	{
		if (max >= arr[num][i])
			;
		else
			max = arr[num][i];
		if (arr[num][i+1] > 100 || arr[num][i+1] < 0)
			break;
		i++;
	} while (1);
	return max;
}
int main()
{
	srand((unsigned int)time(NULL));
	int lines;
	cin >> lines;
	int** arr = new int*[lines];
	for (int i = 0; i < lines; i++)
	{
		int col = rand() % 6 + 1;
		arr[i] = new int[col];
		for (int j = 0; j < col; j++)
		{
			arr[i][j] = rand() % 100 + 1;
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
	int* ans = new int[lines];
	for (int i = 0; i < lines; i++)
		ans[i] = maxValues(arr, i);
	for (int i = 0; i < lines; i++)
		cout << ans[i] << " ";
	cout << endl;
	for (int i = 0; i < lines; i++)
		delete[] arr[i];
	delete arr;
	delete[] ans;
	return 0;
}