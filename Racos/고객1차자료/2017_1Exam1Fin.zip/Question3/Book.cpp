#include "Book.h"
Book::Book()
	: price(100), point(0), pnum(0), amount(1)
{
	name = new char[20];
	strcpy(name, "anybook");
	cout << name << " å ����" << endl;
}
Book::Book(char* bname)
	: price(100), point(0), pnum(0), amount(1)
{
	name = new char[20];
	strcpy(name, bname);
	cout << name << " å ����" << endl;
}
Book::Book(char* bname, int pr, int po, int pn, int am)
	: price(pr), point(po), pnum(pn), amount(am)
{
	name = new char[20];
	strcpy(name, bname);
	cout << name << " å ����" << endl;
}
Book::Book(const Book& b)
	: price(b.price), point(b.point), pnum(b.pnum), amount(b.amount)
{
	name = new char[20];
	strcpy(name, b.name);
	cout << name << " å ����" << endl;
}
Book::~Book()
{
	delete name;
}
void Book::changeName(char* bname)
{
	cout << name << " -> " << bname << "���� �̸� �ٲ�" << endl;
	strcpy(name, bname);
}
void Book::addPoint(int p)
{
	point = (point*pnum + p);
	pnum += 1;
	point /= pnum;
}
void Book::addBook()
{
	amount += 1;
	cout << name << ": ��� 1�� ����" << endl;
}
void Book::releaseBook()
{
	if (amount == 0)
		cout << name << ": ����� ���� ��� �Ұ�!!" << endl;
	else
	{
		amount -= 1;
		cout << name << ": ��� 1�� ����" << endl;
	}
}
void Book::printInfo()
{
	cout << name << ": " << "����(" << point << "), ����(" << price << "), ���(" << amount << ")" << endl;
}