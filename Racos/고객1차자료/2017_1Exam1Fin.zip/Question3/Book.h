#ifndef BOOK_H
#define BOOK_H
#include<iostream>
using namespace std;
class Book
{
private:
	char* name;
	int price;
	int point;
	int pnum;
	int amount;
public:
	Book();
	Book(char*);
	Book(char*, int, int, int, int);
	Book(const Book&);
	~Book();
	void changeName(char*);
	void addPoint(int);
	void addBook();
	void releaseBook();
	void printInfo();
};
#endif // !BOOK_H