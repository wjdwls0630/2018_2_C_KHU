#ifndef BATTLE_KHURUISER_H
#define BATTLE_KHURUISER_H
#include<iostream>
using namespace std;
class Battle_KHUruiser
{
private:
	char* name;
	int energy;
	int damage;
	int shield;
	int xvalue;
	int yvalue;
	int range;
	int speed;
public:
	Battle_KHUruiser(char*, int, int, int, int, int, int, int);
	~Battle_KHUruiser();
	void moveLeft();
	void moveRight();
	void moveUp();
	void moveDown();
	void Attack(Battle_KHUruiser&);
	void printStatus();
	char* GetName();
};
#endif // !BATTLE_KHURUISER_H
