#include<iostream>
using namespace std;
int* vectorsum(int* a, int* b)
{
	int* temp = new int[10];
	for (int i = 0; i < 10; i++)
		temp[i] = a[i] + b[i];
	return temp;
	delete temp;
	temp = NULL;
}
void vectorsubtract(int* a, int* b, int* c)
{
	for (int i = 0; i < 10; i++)
		c[i] = a[i] - b[i];
}
void vectorInnerProduct(int* a, int* b, int& c)
{
	for (int i = 0; i < 10; i++)
		c += a[i] * b[i];
}
int main()
{
	int x[10] = { 1,2,3,4,5,6,7,8,9,10 };
	int y[10] = { 11,12,13,14,15,16,17,18,19,20 };
	int* xsy = vectorsum(x, y);
	for (int i = 0; i < 10; i++)
		cout << xsy[i] << " ";
	cout << endl;
	int* z = new int[10];
	vectorsubtract(x, y, z);
	for (int i = 0; i < 10; i++)
		cout << z[i] << " ";
	cout << endl;
	int w = 0;
	vectorInnerProduct(x, y, w);
	cout << w << endl;
	delete z;
	return 0;
}