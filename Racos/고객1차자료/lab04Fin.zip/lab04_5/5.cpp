#include<iostream>
#include<iomanip>
#include"Fraction.h"
using namespace std;
void getData(int& nNumer, int& nDenom)
{
	cout << "Please enter the numeratot" << setw(5) << ": ";
	cin >> nNumer;
	cout << "Please enter the denumeratot" << setw(3) << ": ";
	cin >> nDenom;
}
int main()
{
	cout << "Fraction computer." << endl;
	int nNumer = 0, nDenom = 0, nMenu = 1;
	while (nMenu)
	{
		cout << "Please choose a operator item" << endl;
		cout << "0. Exit" << endl << "1. Add" << endl << "2. Subtract" << endl << "3. Multiply" << endl << "4. Divide" << endl;
		cout << "Operator item : ";
		cin >> nMenu;
		if (nMenu == 0)
			continue;
		if (nMenu < 0 || nMenu > 4)
		{
			cout << "Please choose the correct menu item!" << endl;
			continue;
		}
		cout << "Please enter the first fraction." << endl;
		getData(nNumer, nDenom);
		CFraction fr1(nNumer, nDenom);
		cout << "Please enter the second fraction." << endl;
		getData(nNumer, nDenom);
		CFraction fr2(nNumer, nDenom);
		cout << endl;
		switch (nMenu)
		{
		case 1:
			fr1.add(fr2);
			break;
		case 2:
			fr1.subtract(fr2);
			break;
		case 3:
			fr1.multiply(fr2);
			break;
		case 4:
			fr1.divide(fr2);
			break;
		default:
			break;
		}
		cout << endl << endl;
	}
	cout << endl << "Thank you for using fractions." << endl;
	return 0;
}