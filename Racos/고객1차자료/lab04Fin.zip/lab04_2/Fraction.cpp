#include<iostream>
#include"Fraction.h"
using namespace std;
CFraction::CFraction()
{
}
CFraction::CFraction(int nNumer, int nDenom)
{
	int GCD = GreatestComDiv(nNumer, nDenom);
	if (nDenom == 0)
	{
		cout << "Can not divide by 0!" << endl;
		exit(100);
	}
	else if (nDenom > 0)
	{
		m_nNumerator = nNumer / GCD;
		m_nDenominator = nDenom / GCD;
	}
	else
	{
		nNumer *= -1;
		nDenom *= -1;
		m_nNumerator = nNumer / GCD;
		m_nDenominator = nDenom / GCD;
	}
}
CFraction::CFraction(const CFraction& fr)
{
	int GCD = GreatestComDiv(fr.m_nNumerator, fr.m_nDenominator);
	if (fr.m_nDenominator == 0)
	{
		cout << "Can not divide by 0!" << endl;
		exit(100);
	}
	else if (fr.m_nDenominator > 0)
	{
		m_nNumerator = fr.m_nNumerator / GCD;
		m_nDenominator = fr.m_nDenominator / GCD;
	}
	else
	{
		m_nNumerator = fr.m_nNumerator*(-1) / GCD;
		m_nDenominator = fr.m_nDenominator*(-1) / GCD;
	}
}
void CFraction::store(int nNumer, int nDenom)
{
	int GCD = GreatestComDiv(nNumer, nDenom);
	if (nDenom == 0)
	{
		cout << "Can not divide by 0!" << endl;
		exit(100);
	}
	else if (nDenom > 0)
	{
		m_nNumerator = nNumer / GCD;
		m_nDenominator = nDenom / GCD;
	}
	else
	{
		nNumer *= -1;
		nDenom *= -1;
		m_nNumerator = nNumer / GCD;
		m_nDenominator = nDenom / GCD;
	}
}
void CFraction::print(void) const
{
	cout << m_nNumerator << "/" << m_nDenominator << endl;
}
int CFraction::GreatestComDiv(int nNumer, int nDenom)
{
	if (nDenom == 0)
	{
		if (nNumer <= 0)
			return nNumer*(-1); // �� ���� ��ȣ�� �ٸ� ��� �ִ������� ������ �Ǿ������. �̰��� ����� �ٲ��ֱ� ���� �� �ڵ带 �߰�.
		else
			return nNumer;
	}
	else
		return GreatestComDiv(nDenom, nNumer%nDenom);
}