#include<iostream>
#include<iomanip>
#include"Fraction.h"
using namespace std;
void getData(int& nNumer, int& nDenom)
{
	cout << "Please enter the numeratot" << setw(5) << ": ";
	cin >> nNumer;
	cout << "Please enter the denumeratot" << setw(3) << ": ";
	cin >> nDenom;
}
int main()
{
	cout << "This program creates a fraction." << endl;
	int nNumer = 0, nDenom = 0;
	getData(nNumer, nDenom);
	CFraction fr1(nNumer, nDenom);
	cout << "fr1 contains: ";
	fr1.print();
	CFraction fr2;
	getData(nNumer, nDenom);
	fr2.store(nNumer, nDenom);
	cout << "fr2 contains: ";
	fr2.print();
	cout << endl;
	cout << "Thank you for using fractions." << endl;
	return 0;
}