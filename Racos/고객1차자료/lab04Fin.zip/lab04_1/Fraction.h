class CFraction
{
private:
	int m_nNumerator;
	int m_nDenominator;
public:
	CFraction(int nNumer, int nDenom);
	CFraction();
	CFraction(const CFraction &fr);
	void store(int nNumer, int nDenom);
	void print(void) const;
};
