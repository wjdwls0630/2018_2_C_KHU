#include<iostream>
#include"Fraction.h"
using namespace std;
CFraction::CFraction()
{
}
CFraction::CFraction(int nNumer, int nDenom)
{
	if (nDenom == 0)
	{
		cout << "Can not divide by 0!" << endl;
		exit(100);
	}
	else if (nDenom < 0)
	{
		nNumer *= -1;
		m_nNumerator = nNumer;
		m_nDenominator = -nDenom;
	}
	else
	{
		m_nNumerator = nNumer;
		m_nDenominator = nDenom;
	}
}
CFraction::CFraction(const CFraction& fr)
{
	if (fr.m_nDenominator == 0)
	{
		cout << "Can not divide by 0!" << endl;
		exit(100);
	}
	else if (fr.m_nDenominator < 0)
	{
		m_nNumerator = fr.m_nNumerator*(-1);
		m_nDenominator = fr.m_nDenominator;
	}
	else
	{
		m_nNumerator = fr.m_nNumerator;
		m_nDenominator = fr.m_nDenominator;
	}
} // ��ü���� �����ϴ� ���̶� .�� �̿���
void CFraction::store(int nNumer, int nDenom)
{
	if (nDenom == 0)
	{
		cout << "Can not divide by 0!" << endl;
		exit(100);
	}
	else if (nDenom < 0)
	{
		nNumer *= -1;
		m_nNumerator = nNumer;
		m_nDenominator = -nDenom;
	}
	else
	{
		m_nNumerator = nNumer;
		m_nDenominator = nDenom;
	}
}
void CFraction::print(void) const
{
	cout << m_nNumerator << "/" << m_nDenominator << endl;
}