#include<iostream>
#include<iomanip>
#include"Fraction.h"
using namespace std;
void getData(int& nNumer, int& nDenom)
{
	cout << "Please enter the numeratot" << setw(5) << ": ";
	cin >> nNumer;
	cout << "Please enter the denumeratot" << setw(3) << ": ";
	cin >> nDenom;
}
int main()
{
	cout << "This program creates a fraction." << endl;
	int nNumer = 0, nDenom = 0;
	getData(nNumer, nDenom);
	CFraction fr1(nNumer, nDenom);
	cout << "fr1 contains: ";
	fr1.print();
	cout << setw(20) << "&fr1 = 0x" << &fr1 << endl;
	fr1.printThisValue();
	CFraction fr2(fr1);
	cout << "fr2 contains: ";
	fr2.print();
	cout << setw(20) << "&fr2 = 0x" << &fr2 << endl;
	fr2.printThisValue();
	cout << endl << endl;
	CFraction fr3(fr1);
	CFraction fr4(fr1);
	cout << setw(20) << "&fr3 = 0x" << &fr3 << endl;
	cout << setw(20) << "&fr4 = 0x" << &fr4 << endl;
	fr3.printThisWithArgument(fr3);
	cout << "Thank you for using fractions." << endl;
	return 0;
}