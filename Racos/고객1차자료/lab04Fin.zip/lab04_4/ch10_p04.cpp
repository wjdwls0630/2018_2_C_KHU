#include<iostream>
#include<iomanip>
#include"Fraction.h"
using namespace std;
void store(int nNumer, int nDenom, CFraction& fr)
{
	fr.m_nNumerator = nNumer;
	fr.m_nDenominator = nDenom;
	int GCD = fr.GreatestComDiv(fr.m_nNumerator, fr.m_nDenominator);
	if (fr.m_nDenominator == 0)
	{
		cout << "Can not divide by 0!" << endl;
		exit(100);
	}
	else if (fr.m_nDenominator > 0)
	{
		fr.m_nNumerator = fr.m_nNumerator / GCD;
		fr.m_nDenominator = fr.m_nDenominator / GCD;
	}
	else
	{
		fr.m_nNumerator = fr.m_nNumerator*(-1) / GCD;
		fr.m_nDenominator = fr.m_nDenominator*(-1) / GCD;
	}
}
void print(const CFraction& fr)
{
	cout << fr.m_nNumerator << "/" << fr.m_nDenominator << endl;
}
void getData(int& nNumer, int& nDenom)
{
	cout << "Please enter the numeratot" << setw(5) << ": ";
	cin >> nNumer;
	cout << "Please enter the denumeratot" << setw(3) << ": ";
	cin >> nDenom;
}
int main()
{
	cout << "This program creates a fraction." << endl;
	int nNumer = 0, nDenom = 0;
	getData(nNumer, nDenom);
	CFraction fr1;
	store(nNumer, nDenom, fr1);
	cout << "fr1 contains:";
	print(fr1);
	cout << "Thank you for using fraction." << endl;
	return 0;
}