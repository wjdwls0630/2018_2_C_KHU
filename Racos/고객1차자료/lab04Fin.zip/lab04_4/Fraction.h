class CFraction
{
private:
	int m_nNumerator;
	int m_nDenominator;
	int GreatestComDiv(int nNumer, int nDenom);
public:
	CFraction();
	CFraction(int nNumer, int nDenom);
	CFraction(const CFraction& fr);
	friend void store(int nNumer, int nDenom, CFraction& fr);
	friend void print(const CFraction& fr);
};