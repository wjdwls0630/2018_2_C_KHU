class CFraction
{
private:
	int m_nNumerator;
	int m_nDenominator;
	int GreatestComDiv(int nNumer, int nDenom);
public:
	CFraction();
	CFraction(int nNumer, int nDenom);
	CFraction(const CFraction& fr);
	void store(int nNumer, int nDenom);
	void print() const;
	friend CFraction add(const CFraction& fr1, const CFraction& fr2);
	friend CFraction subtract(const CFraction& fr1, const CFraction& fr2);
	friend CFraction multiply(const CFraction& fr1, const CFraction& fr2);
	friend CFraction divide(const CFraction& fr1, const CFraction& fr2);
};