#include"Fraction.h"
CFraction add(const CFraction& fr1, const CFraction& fr2)
{
	CFraction fra;
	fra.m_nNumerator = fr1.m_nNumerator*fr2.m_nDenominator + fr1.m_nDenominator*fr2.m_nNumerator;
	fra.m_nDenominator = fr1.m_nDenominator*fr2.m_nDenominator;
	int GCD = fra.GreatestComDiv(fra.m_nNumerator, fra.m_nDenominator);
	fra.m_nNumerator /= GCD;
	fra.m_nDenominator /= GCD;
	return fra;
} // CFraction������ ��ȯ�ؾ� �ؼ� �Լ� ���� ���� ���� ������ �߰��� ������.
CFraction subtract(const CFraction& fr1, const CFraction& fr2)
{
	CFraction fra;
	fra.m_nNumerator = fr1.m_nNumerator*fr2.m_nDenominator - fr1.m_nDenominator*fr2.m_nNumerator;
	fra.m_nDenominator = fr1.m_nDenominator*fr2.m_nDenominator;
	int GCD = fra.GreatestComDiv(fra.m_nNumerator, fra.m_nDenominator);
	fra.m_nNumerator /= GCD;
	fra.m_nDenominator /= GCD;
	return fra;
}
CFraction multiply(const CFraction& fr1, const CFraction& fr2)
{
	CFraction fra;
	fra.m_nNumerator = fr1.m_nNumerator*fr2.m_nNumerator;
	fra.m_nDenominator = fr1.m_nDenominator*fr2.m_nDenominator;
	int GCD = fra.GreatestComDiv(fra.m_nNumerator, fra.m_nDenominator);
	fra.m_nNumerator /= GCD;
	fra.m_nDenominator /= GCD;
	return fra;
}
CFraction divide(const CFraction& fr1, const CFraction& fr2)
{
	CFraction fra;
	fra.m_nNumerator = fr1.m_nNumerator*fr2.m_nDenominator;
	fra.m_nDenominator = fr1.m_nDenominator*fr2.m_nNumerator;
	int GCD = fra.GreatestComDiv(fra.m_nNumerator, fra.m_nDenominator);
	fra.m_nNumerator /= GCD;
	fra.m_nDenominator /= GCD;
	return fra;
}