#include<iostream>
using namespace std;
int findFirstSequence(int* sequence, int size, int* result_seq_ptr)
{
	int count = 0;
	for (int i = 0; i < size; i++)
	{
		if (*sequence+i < *sequence + i+1)
		{
			if (*sequence + i + 1 < *sequence + i + 2)
			{
				result_seq_ptr = sequence + (i + 2);
				count++;
			}
		}
	}
	return count;
}
void ReverseOrder(int* sequence, int seq_size)
{

}
int main()
{
	int* target;
	int size;
	cout << "������ ũ��: ";
	cin >> size;
	target = new int[size];
	cout << "����: ";
	for (int i = 0; i < size; i++)
		cin >> target[i];
	delete[] target;
	return 0;
}