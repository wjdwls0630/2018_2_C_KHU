#ifndef MATRIXINT_H
#define MATRIXINT_H
#include<iostream>
using namespace std;
class MatrixInt
{
private:
	int** arr;
	int row;
	int col;
public:
	MatrixInt();
	MatrixInt(int, int);
	~MatrixInt();
	void InputData();
	void showMatrix();
};
#endif