#include "MatrixInt.h"
int main()
{
	MatrixInt matrix1;
	cout << "matrix1 input" << endl;
	matrix1.InputData();
	MatrixInt matrix2(2, 1);
	cout << endl << "matrix2 input" << endl;
	matrix2.InputData();
	cout << endl << "show matrix1" << endl;
	matrix1.showMatrix();
	cout << endl << "show matrix2" << endl;
	matrix2.showMatrix();
	return 0;
}