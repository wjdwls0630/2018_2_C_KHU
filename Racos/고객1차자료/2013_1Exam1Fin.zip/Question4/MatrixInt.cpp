#include "MatrixInt.h"
MatrixInt::MatrixInt()
	:row(2),col(2)
{
	arr = new int*[row];
	for (int i = 0; i < row; i++)
		arr[i] = new int[col];
}
MatrixInt::MatrixInt(int r, int c)
	: row(r), col(c)
{
	arr = new int*[row];
	for (int i = 0; i < row; i++)
		arr[i] = new int[col];
}
MatrixInt::~MatrixInt()
{
	for (int i = 0; i < row; i++)
		delete[] arr[i];
	delete[] arr;
}
void MatrixInt::InputData()
{
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			cout << "Matrix<" << i << "," << j << "> = ";
			cin >> arr[i][j];
		}
	}
}
void MatrixInt::showMatrix()
{
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
			cout << arr[i][j] << " ";
		cout << endl;
	}
}