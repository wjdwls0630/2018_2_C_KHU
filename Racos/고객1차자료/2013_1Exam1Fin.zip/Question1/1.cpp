#include<iostream>
using namespace std;
int Multiply(int num1, int num2)
{
	int mul_result = num1*num2;
	return mul_result;
}
void Count(int mul_result, int result[10])
{
	int count = 0;
	while (mul_result / pow(10, count) != 0)
		++count;
	int temp = mul_result;
	while (temp != 0)
	{
		for (int i = 0; i < 10; i++)
		{
			if (temp % 10 == i)
				result[i]++;
			else
				;
		}
		temp /= 10;
	}
}
int main()
{
	int a, b;
	int mul_result;
	int result[10] = {0};
	cout << "ù ��° ���� �Է��Ͻÿ�.";
	cin >> a;
	cout << "�� ��° ���� �Է��Ͻÿ�.";
	cin >> b;
	mul_result = Multiply(a, b);
	cout << "���� ���: " << mul_result << endl;
	Count(mul_result, result);
	for (int i = 0; i < 10; i++)
		cout << i << "��(��) ���� Ƚ�� : " << result[i] << endl;
	return 0;
}