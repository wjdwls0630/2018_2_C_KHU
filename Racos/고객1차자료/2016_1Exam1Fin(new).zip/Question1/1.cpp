#include<iostream>
#include<iomanip>
using namespace std;
int* crossProduct(int* a, int* b)
{
	int* c = new int[3];
	c[0] = a[1] * b[2] - a[2] * b[1];
	c[1] = a[2] * b[0] - a[0] * b[2];
	c[2] = a[0] * b[1] - a[1] * b[0];
	return c;
	delete c;
}
void transpose(int a[][3], int b[][3])
{
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			if (i == j)
				b[i][j] = a[i][j];
			else if (i < j)
				b[i][j] = a[j][i];
			else
				b[i][j] = a[j][i];
		}
	}
}
int main()
{
	srand((unsigned int)time(NULL));
	int a[3], b[3];
	for (int i = 0; i < 3; i++)
	{
		a[i] = rand() % 10 + 1;
		b[i] = rand() % 10 + 1;
	}
	int* cp = crossProduct(a, b);
	cout << "The cross product of" << endl;
	cout << "[";
	for (int i = 0; i < 3; i++)
	{
		if (i != 2)
			cout << a[i] << " ";
		else
			cout << a[i] << "] and [";
	}
	for (int i = 0; i < 3; i++)
	{
		if (i != 2)
			cout << b[i] << " ";
		else
			cout << b[i] << "] is [";
	}
	for (int i = 0; i < 3; i++)
	{
		if (i != 2)
			cout << cp[i] << " ";
		else
			cout << cp[i] << "]" << endl;
	}
	cout << endl;
	int c[3][3], d[3][3];
	cout << "The transpose of" << endl;
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			c[i][j] = rand() % 100 + 1;
			cout << c[i][j] << " ";
		}
		cout << endl;
	}
	cout << "is" << endl;
	transpose(c, d);
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
			cout << d[i][j] << " ";
		cout << endl;
	}
	return 0;
}