#include "User.h"
User::User()
	: name("Anonymous"), bonus(0), online(false), fnum(0)
{
	list = new User*[fnum + 1];
	cout << name << " created." << endl;
}
User::User(string n)
	: name(n), bonus(0), online(false), fnum(0)
{
	list = new User*[fnum + 1];
	cout << name << " created." << endl;
}
User::User(string n, int b, bool o)
	: name(n), bonus(b), online(o), fnum(0)
{
	list = new User*[fnum + 1];
	cout << name << " created." << endl;
}
User::~User()
{
	delete list;
}
void User::printFriends()
{
	cout << name << "'s friends are ";
	for (int i = 0; i < fnum; i++)
	{
		if (i != fnum)
			cout << list[i] << ", ";
		else
			cout << list[i] << "." << endl;
	}
	cout << endl;
}
void User::addFriend(User& u)
{
	if (fnum == 0)
	{
		*list[0] = u;
		if(u.fnum == 0)
			*u.list = this;
		else
		{
			User** nlist = new User*[fnum + 1];
			for (int i = 0; i < fnum + 1; i++)
			{
				if (i < fnum)
					nlist[i] = list[i];
				else
				{
					*nlist[i] = u;
					u.list[i + 1] = this;
				}
			}
		}
		fnum++;
		u.fnum++;
	}
}