#ifndef USER_H
#define USER_H
#include<iostream>
#include<string>
using namespace std;
class User
{
private:
	string name;
	int bonus;
	bool online;
	User** list;
	int fnum;
public:
	User();
	User(string);
	User(string, int, bool);
	~User();
	void printFriends();
	void addFriend(User&);
};
#endif // !USER_H
