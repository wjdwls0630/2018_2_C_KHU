#include "User.h"
int main()
{
	User user1("YellOw", 50, true);
	User user2("SlayerS", 20, true);
	User user3("GoGo", 30, false);
	User user4;
	user1.addFriend(user2);
	user1.addFriend(user4);
	user2.addFriend(user3);
	user1.printFriends();
	user2.printFriends();
	user3.printFriends();
	user4.printFriends();
	return 0;
}