#ifndef USER_H
#define USER_H
#include<iostream>
#include<string>
using namespace std;
class User
{
private:
	string name;
	int bonus;
	bool online;
public:
	User();
	User(string);
	User(string, int, bool);
	User(const User&);
	void changeName(string);
	void changeBonusPoint(int);
	void changeOnline(bool);
	void printInfo();
};
#endif // !USER_H
