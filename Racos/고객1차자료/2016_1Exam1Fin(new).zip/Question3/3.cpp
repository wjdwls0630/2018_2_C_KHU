#include "User.h"
int main()
{
	User user1;
	User user2("SlayerS", 20, true);
	User user3(user2);
	user1.printInfo();
	user2.printInfo();
	user3.printInfo();
	user1.changeName("YellOw");
	user1.changeOnline(true);
	user1.changeBonusPoint(50);
	user1.printInfo();
	return 0;
}