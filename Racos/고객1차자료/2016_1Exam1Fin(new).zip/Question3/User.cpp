#include "User.h"
User::User()
	: name("Anonymous"), bonus(0), online(false)
{
	cout << name << " created." << endl;
}
User::User(string n)
	: name(n), bonus(0), online(false)
{
	cout << name << " created." << endl;
}
User::User(string n, int b, bool o)
	: name(n),bonus(b),online(o)
{
	cout << name << " created." << endl;
}
User::User(const User& u)
	: name(u.name), bonus(u.bonus), online(u.online)
{}
void User::changeName(string n)
{
	name = n;
}
void User::changeBonusPoint(int b)
{
	bonus += b;
}
void User::changeOnline(bool o)
{
	online = o;
}
void User::printInfo()
{
	if (online == false)
		cout << name << " has " << bonus << " bonus points and is now offline." << endl;
	else
		cout << name << " has " << bonus << " bonus points and is now online." << endl;
}