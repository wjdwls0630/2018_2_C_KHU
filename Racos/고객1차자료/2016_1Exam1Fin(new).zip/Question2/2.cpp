#include<iostream>
using namespace std;
int main()
{
	int** pp, height;
	cout << "Height? ";
	cin >> height;
	pp = new int*[height];
	for (int i = 0; i < height; i++)
	{
		pp[i] = new int[i * 2 + 1];
		for (int j = 0; j < i * 2 + 1; j++)
		{
			if (j == 0)
				*(*(pp + i) + j) = 1;
			else if (i == 1 && j == 1)
				*(*(pp + i) + j) = 1;
			else if(j == i*2)
				*(*(pp + i) + j) = 1;
			else if (j == 1)
				*(*(pp + i) + j) = *(*(pp + i - 1) + j - 1) + *(*(pp + i - 1) + j);
			else if(j > i)
				*(*(pp + i) + j) = *(*(pp + i) + j - i);
			else
				*(*(pp + i) + j) = *(*(pp + i - 1) + j - 2) + *(*(pp + i - 1) + j - 1) + *(*(pp + i - 1) + j);
			cout << pp[i][j] << " ";
		}
		cout << endl;
	}
	for (int i = 0; i < height; i++)
		delete[] pp[i];
	delete pp;
	return 0;
}