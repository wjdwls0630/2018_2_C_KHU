#ifndef TUSER_H
#define TUSER_H
#include<iostream>
using namespace std;
class TUser
{
private:
	int need;
	int handle;
	bool use;
public:
	TUser();
	TUser(int, int);
	void getNeed();
	void getHandle();
	bool timer(int&);
	void toilet(int&);
};
#endif // !TUSER_H
