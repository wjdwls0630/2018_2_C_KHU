#include "TUser.h"
TUser::TUser()
{
	need = 0;
	handle = 0;
	use = false;
}
TUser::TUser(int n, int h)
{
	need = n;
	handle = h;
	use = false;
}
void TUser::getNeed()
{
	cin >> need;
}
void TUser::getHandle()
{
	cin >> handle;
}
bool TUser::timer(int& num)
{
	--need;
	--handle;
	if (need == 0)
	{
		--num;
		use = false;
		return false;
	}
	if (handle == 0)
		return false;
	else
		return true;
}
void TUser::toilet(int& num)
{
	use = true;
	num++;
}