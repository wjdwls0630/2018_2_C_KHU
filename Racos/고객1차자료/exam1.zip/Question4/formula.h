#ifndef FORMULA_H
#define FORMULA_H
#include<iostream>
using namespace std;
class formula
{
private:
	int value;
	formula* left;
	formula* right;
	char oper;
public:
	formula();
	formula(const formula*);
	~formula();
	int answer();
};
#endif // !FORMULA_H
