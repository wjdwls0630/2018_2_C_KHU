#include "formula.h"
formula::formula()
{

}
formula::formula(const formula* f)
{

}
formula::~formula()
{

}
int formula::answer()
{

}