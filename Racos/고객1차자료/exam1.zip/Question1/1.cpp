#include<iostream>
using namespace std;
int main()
{
	int size;
	cout << "�迭�� ũ�⸦ �Է��Ͻÿ�. ";
	cin >> size;
	int** arr = new int*[size];
	for (int i = 0; i < size; i++)
		arr[i] = NULL;
	int index = 0, count = 0, temp = 0;
	for (int i = 0; i < size; i++)
	{
		cout << "index�� ���� ���� �Է��Ͻÿ�. ";
		cin >> index;
		temp += index;
		if (arr[temp%size] != NULL)
		{
			arr[temp%size][0] = i + 1;
			count++;
		}
		else
		{
			arr[temp%size] = new int[1];
			arr[temp%size][0] = i + 1;
		}
	}
	for (int i = 0; i < size; i++)
	{
		if (arr[i] != NULL)
			cout << arr[i][0] << " ";
		else
			cout << 0;

	}
	cout << endl << "�浹 Ƚ�� " << count << endl;
	for (int i = 0; i < size; i++)
		delete arr[i];
	delete[] arr;
	return 0;
}