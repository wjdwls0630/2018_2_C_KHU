#include<iostream>
using namespace std;
void swap(int a[], int size)
{
	int temp = 0;
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < size-1; j++)
		{
			if (a[j] < a[j+1])
			{
				temp = a[j];
				a[j] = a[j + 1];
				a[j + 1] = temp;
			}
			else
				;
		}
	}
}
int main()
{
	int row, col;
	int count = 0;
	cout << "��ü ���� ������ �Է� ";
	cin >> row;
	int** arr = new int*[row];
	for (int i = 0; i < row; i++)
	{
		cout << i + 1 << "���� ���̸� �Է�";
		cin >> col;
		arr[i] = new int[col+1];
		cout << i + 1 << "���� ������ �Է�";
		for (int j = 0; j < col; j++)
			cin >> arr[i][j];
		arr[i][col] = 0;
		count += col;
	}
	cout << "2���� �迭�� ��" << endl;
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; arr[i][j] != 0 ; j++)
			cout << arr[i][j] << " ";
		cout << endl;
	}
	int* C = new int[count];
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; arr[i][j] != 0; j++)
			C[i * 2 + j] = arr[i][j];
	}
	swap(C, count);
	cout << "1���� �迭�� ���ĵ� ���" << endl;
	for (int i = 0; i < count; i++)
		cout << C[i] << " ";
	cout << endl;
	for (int i = 0; i < row; i++)
		delete arr[i];
	delete[] arr;
	delete C;
	return 0;
}