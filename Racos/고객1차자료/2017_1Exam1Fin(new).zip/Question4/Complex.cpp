#include "Complex.h"
Complex::Complex()
	: real(0.0), image(0.0)
{}
Complex::Complex(double r)
	: real(r), image(0.0)
{}
Complex::Complex(double r, double i)
	: real(r), image(i)
{}
Complex Complex::add(const Complex& c1)
{
	this->real += c1.real;
	this->image += c1.image;
	return *this;
}
Complex Complex::multi(const Complex& c1)
{
	this->real = this->real*c1.real - this->image*c1.image;
	this->image = this->real*c1.image + this->image*c1.real;
	return *this;
}
double Complex::getReal()
{
	return real;
}
double Complex::getImage()
{
	return image;
}
void Complex::setReal(double r)
{
	real = r;
}
void Complex::setImage(double i)
{
	image = i;
}
void Complex::print()
{
	if (image < 0)
		cout << real << "-" << -image << "i" << endl;
	else if (image == 0)
		cout << real << endl;
	else
		cout << real << "+" << image << "i" << endl;
}