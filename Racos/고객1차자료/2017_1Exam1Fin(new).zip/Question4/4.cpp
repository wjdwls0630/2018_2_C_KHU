#include "Complex.h"
Complex ADD(const Complex& c1, const Complex& c2)
{
	Complex temp;
	temp.real = c1.real + c2.real;
	temp.image = c1.image + c2.image;
	return temp;
}
Complex MULTI(const Complex& c1, const Complex& c2)
{
	Complex temp;
	temp.real = c1.real*c2.real - c1.image*c2.image;
	temp.image = c1.real*c2.image + c1.image*c2.real;
	return temp;
}
int main()
{
	Complex c1(3, 5), c2(7), c3;
	c3 = ADD(c1, c2);
	cout << "c1 : ";
	c1.print();
	cout << "c2 : ";
	c2.print();
	cout << "c3=c1+c2" << endl;
	cout << "c3 : ";
	c3.print();

	Complex x(1, 2), y(2), z;
	z = MULTI(x, y);
	cout << "x : ";
	x.print();
	cout << "y : ";
	y.print();
	cout << "z=x*y" << endl;
	cout << "z : ";
	z.print();

	c1.add(c2);
	x.multi(y);
	cout << "c1 : ";
	c1.print();
	cout << "x : ";
	x.print();
	return 0;
}