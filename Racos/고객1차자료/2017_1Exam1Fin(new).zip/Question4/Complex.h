#ifndef COMPLEX_H
#define COMPLEX_H
#include<iostream>
using namespace std;
class Complex
{
private:
	double real;
	double image;
public:
	Complex();
	Complex(double);
	Complex(double, double);
	double getReal();
	double getImage();
	void setReal(double);
	void setImage(double);
	void print();
	Complex add(const Complex& c1);
	Complex multi(const Complex& c1);
	friend Complex ADD(const Complex& c1, const Complex& c2);
	friend Complex MULTI(const Complex& c1, const Complex& c2);
};
#endif // !COMPLEX_H