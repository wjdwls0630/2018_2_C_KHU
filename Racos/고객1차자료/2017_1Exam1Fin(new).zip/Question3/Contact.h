#ifndef CONTACT_H
#define CONTACT_H
#include<iostream>
using namespace std;
class Contact
{
private:
	char name[20];
	char hphone[20];
	char email[30];
public:
	Contact();
	void setName(char*);
	void setPhone(char*);
	void setEmail(char*);
	void printContact();
};
#endif