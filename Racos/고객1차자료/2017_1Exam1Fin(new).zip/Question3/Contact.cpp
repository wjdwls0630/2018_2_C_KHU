#include "Contact.h"
Contact::Contact()
{
	strcpy(name, "ȫ�浿");
	strcpy(hphone, "010-1234-1234");
	strcpy(email, "noname@khu.ac.kr");
}
void Contact::setName(char* n)
{
	strcpy(name, n);
}
void Contact::setPhone(char* p)
{
	strcpy(hphone, p);
}
void Contact::setEmail(char* e)
{
	strcpy(email, e);
}
void Contact::printContact()
{
	cout << endl << "�̸� : " << name << endl;
	cout << "�ڵ��� : " << hphone << endl;
	cout << "�̸��� : " << email << endl;
	cout << "------------------------" << endl;
}