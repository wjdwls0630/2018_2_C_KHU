#include "Contact.h"
int main()
{
	Contact c1, c2, c3;
	c2.setName("������");
	c2.setPhone("010-0000-0000");
	c3.setName("�̼���");
	c3.setEmail("leesunsin@turtle.com");
	c1.printContact();
	c2.printContact();
	c3.printContact();
	return 0;
}