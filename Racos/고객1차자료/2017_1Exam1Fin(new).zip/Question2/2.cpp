#include<iostream>
#include<iomanip>
using namespace std;
void tournament(int** arr, int stageNum, int playerNum, int& currentStage)
{
	if(playerNum == 1)
		arr[currentStage + 1] = new int[playerNum];
	else
		arr[currentStage + 1] = new int[playerNum / 2];
	int temp = 0;
	while (temp < playerNum)
	{
		if (arr[currentStage][temp] >= arr[currentStage][temp + 1])
			arr[currentStage + 1][temp/2] = arr[currentStage][temp];
		else
			arr[currentStage + 1][temp/2] = arr[currentStage][temp + 1];
		temp += 2;
	}
	if (playerNum == 1)
	{
		for (int i = 0; i < playerNum; i++)
			cout << arr[currentStage + 1][i] << " ";
		cout << endl;
	}
	else
	{
		for (int i = 0; i < playerNum / 2; i++)
			cout << arr[currentStage + 1][i] << " ";
		cout << endl;
	}
}
int main()
{
	srand((unsigned int)time(NULL));
	int player, start = 0;
	cin >> player;
	int game = (int)sqrt(player);
	int** type = new int*[game + 1];
	type[0] = new int[player];
	for (int i = 0; i < player; i++)
	{
		type[0][i] = rand() % 1000 + 1;
		cout << type[0][i] << " ";
	}
	cout << endl;
	bool cond = true;
	while (cond)
	{
		tournament(type, game, player, start);
		player /= 2;
		start++; 
		if (player == 1)
			break;
	}
	for (int i = 0; i < start; i++)
		delete[] type[i];
	return 0;
}