#include<iostream>
using namespace std;
int main()
{
	int a, b = 3, c = 7;
	int* p = &b, *q, *r;
	q = &b, r = &b; // step1
	a = (b + c) / 2;
	p = &a; // step2
	c += a+b;
	r = &c; // step3
	cout << "a = " << *p << "(" << p << ")" << endl;
	cout << "b = " << *q << "(" << q << ")" << endl;
	cout << "c = " << *r << "(" << r << ")" << endl;
	return 0;
}