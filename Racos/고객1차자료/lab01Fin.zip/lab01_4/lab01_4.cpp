#include<iostream>
#include<iomanip>
using namespace std;
int* topGrade(int* px, int* py, int* pz)
{
	if (*px >= *py)
	{
		if (*px >= *pz)
			return px;
		else
			return pz;
	}
	else
	{
		if (*py >= *pz)
			return py;
		else
			return pz;
	}
}
int main()
{
	int grade1, grade2, grade3;
	int* pgrade1, *pgrade2, *pgrade3;
	pgrade1 = &grade1;
	pgrade2 = &grade2;
	pgrade3 = &grade3;
	cin >> grade1 >> grade2 >> grade3;
	cout << "Value: grade1 = " << setw(8) << grade1 << " *pgrade1 = " << setw(8) << *pgrade1 << " *&grade1 = " << setw(8) << *&grade1 << endl;
	cout << "Addr: &grade1 = " << &grade1 << "  pgrade1 = " << pgrade1 << " &pgrade1 = " << &pgrade1 << endl;
	cout << "Value: grade2 = " << setw(8) << grade2 << " *pgrade2 = " << setw(8) << *pgrade2 << " *&grade2 = " << setw(8) << *&grade2 << endl;
	cout << "Addr: &grade2 = " << &grade2 << "  pgrade2 = " << pgrade2 << " &pgrade2 = " << &pgrade2 << endl;
	cout << "Value: grade3 = " << setw(8) << grade3 << " *pgrade3 = " << setw(8) << *pgrade3 << " *&grade3 = " << setw(8) << *&grade3 << endl;
	cout << "Addr: &grade3 = " << &grade3 << "  pgrade3 = " << pgrade3 << " &pgrade3 = " << &pgrade3 << endl;
	int* top;
	top = topGrade(pgrade1, pgrade2, pgrade3);
	cout << "Top = " << *top << "(addr : " << top << ")" << endl;
	return 0;
}