#include<iostream>
using namespace std;
int main()
{
	int a, *p, **q, ***r;
	p = &a, q = &p, r = &q;
	cout << "Enter a number: ";
	cin >> a;
	cout << "Your number is : " << a << endl << endl;
	cout << "Enter a number: ";
	cin >> *p;
	cout << "Your number is : " << a << endl << endl;
	cout << "Enter a number: ";
	cin >> **q;
	cout << "Your number is : " << a << endl << endl;
	cout << "Enter a number: ";
	cin >> ***r;
	cout << "Your number is : " << a << endl;
	return 0;
}