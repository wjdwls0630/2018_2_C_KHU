#include<iostream>
using namespace std;
void swapDptr(int** x, int** y)
{
	int* temp = *x;
	*x = *y;
	*y = temp;
}
void swapRefPtr(int*& x, int*& y)
{
	int* temp = x;
	x = y;
	y = temp;
}
int main()
{
	int x = 5, y = 7;
	int* px = &x, *py = &y;
	cout << "swapDptr()�Լ� ȣ�� �� " << px << " " << py << " " << x << " " << y << endl;
	swapDptr(&px, &py);
	cout << "swapDptr()�Լ� ȣ�� �� " << px << " " << py << " " << x << " " << y << endl;
	swapRefPtr(px, py);
	cout << "swapRefPtr()�Լ� ȣ�� �� " << px << " " << py << " " << x << " " << y << endl;
	return 0;
}