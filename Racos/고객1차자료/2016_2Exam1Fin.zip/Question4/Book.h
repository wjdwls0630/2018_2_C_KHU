#ifndef BOOK_H
#define BOOK_H
#include<iostream>
using namespace std;
class Book
{
private:
	char* name;
	unsigned int price;
	unsigned int point;
	unsigned int pointnum;
	unsigned int booknum;
public:
	Book();
	Book(char*);
	Book(char*, unsigned int, unsigned int, unsigned int, unsigned int);
	Book(const Book& b);
	~Book();
	void changeName(char*);
	void addPoint(int);
	void addBook();
	void releaseBook();
	void printInfo();
};
#endif // !BOOK_H
