#include "Matrix.h"
Matrix::Matrix()
	: a(0), b(0), c(0), d(0)
{}
Matrix::Matrix(double x, double y, double z, double w)
	: a(x), b(y), c(z), d(w)
{}
double Matrix::matrixDet(Matrix& m)
{
	return m.a*m.d - m.b*m.c;
}
bool Matrix::isInversible(Matrix& m)
{
	if (matrixDet(m) != 0)
		return true;
	else
		return false;
}
void Matrix::printMatrix()
{
	cout << a << "\t   " << b << endl;
	cout << c << "\t   " << d << endl;
}