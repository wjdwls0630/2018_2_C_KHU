#ifndef MATRIX_H
#define MATRIX_H
#include<iostream>
using namespace std;
class Matrix
{
private:
	double a;
	double b;
	double c;
	double d;
public:
	Matrix();
	Matrix(double, double, double, double);
	double matrixDet(Matrix&);
	bool isInversible(Matrix&);
	friend Matrix matrixInverse(Matrix& m1, Matrix& m2);
	void printMatrix();
};
#endif // !MATRIX_H
