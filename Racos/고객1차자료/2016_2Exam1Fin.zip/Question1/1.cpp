#include<iostream>
#include<iomanip>
using namespace std;
int* pairwiseComparison1(int* A, int* B, int size)
{
	int* C = new int[size];
	for (int i = 0; i < size; i++)
	{
		if (A[i] > B[i])
			C[i] = -1;
		else if (A[i] == B[i])
			C[i] = 0;
		else
			C[i] = 1;
	}
	return C;
	delete C;
}
void pairwiseComparison2(int A[], int B[], int* C, int size)
{
	for (int i = 0; i < size; i++)
	{
		if (A[i] > B[i])
			C[i] = -1;
		else if (A[i] == B[i])
			C[i] = 0;
		else
			C[i] = 1;
	}
}
int main()
{
	srand((unsigned int)time(NULL));
	int size;
	cout << "Size of the array? ";
	cin >> size;
	int* a = new int[size];
	cout << "[";
	for (int i = 0; i < size; i++)
	{
		a[i] = rand() % 100 + 1;
		if (i == size - 1)
			cout << a[i] << "]";
		else
			cout << a[i] << " ";
	}
	cout << " and ";
	int* b = new int[size];
	cout << "[";
	for (int i = 0; i < size; i++)
	{
		b[i] = rand() % 100 + 1;
		if (i == size - 1)
			cout << b[i] << "]";
		else
			cout << b[i] << " ";
	}
	cout << " are created." << endl;
	int* c = pairwiseComparison1(a, b, size);
	cout << "The comparison result of the first function is [";
	for(int i=0;i<size;i++)
	{
		if (i == size - 1)
			cout << c[i] << "]";
		else
			cout << c[i] << " ";
	}
	cout << endl;
	int* d = a;
	pairwiseComparison2(a, b, d, size);
	cout << "The comparison result of the second function is [";
	for (int i = 0; i<size; i++)
	{
		if (i == size - 1)
			cout << d[i] << "]";
		else
			cout << d[i] << " ";
	}
	cout << endl;
	delete a;
	delete b;
	return 0;
}