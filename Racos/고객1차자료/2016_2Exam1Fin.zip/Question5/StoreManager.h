#ifndef STOREMANAGER_H
#define STOREMANAGER_H
#include "Book.h"
class StoreManager : public Book
{
private:
	Book* list;
	int location;
public:
	StoreManager();
	~StoreManager();
	void stockUpBook(Book&);
	void stockUpBook(Book [], int);
	void printStock();
};
#endif // !STOREMANAGER_H
