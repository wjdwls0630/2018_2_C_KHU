#include "StoreManager.h"
StoreManager::StoreManager()
	:location(0)
{
	list = new Book[10];
}
StoreManager::~StoreManager()
{
}
void StoreManager::stockUpBook(Book& b)
{
	list[location] = b;
	location++;
}
void StoreManager::stockUpBook(Book b[], int size)
{
	for (int i = 0; i < size; i++)
		list[i+location] = b[i];
	location += 2;
}
void StoreManager::printStock()
{
	for (int i = 0; i < location; i++)
		list[i].printInfo();
}