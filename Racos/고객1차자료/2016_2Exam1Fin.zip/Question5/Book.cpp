#include "Book.h"
Book::Book()
	: price(100), point(0), pointnum(0), booknum(1)
{
	name = new char[20];
	strcpy(name, "anybook");
}
Book::Book(char* n)
	: price(100), point(0), pointnum(0), booknum(1)
{
	name = new char[20];
	strcpy(name, n);
}
Book::Book(char* n, unsigned int p, unsigned int po, unsigned int pon, unsigned int b)
	: price(p), point(po), pointnum(pon), booknum(b)
{
	name = new char[20];
	strcpy(name, n);
}
Book::Book(const Book& b)
	: price(b.price), point(b.point), pointnum(b.pointnum), booknum(b.booknum)
{
	name = new char[20];
	strcpy(name, b.name);
}
Book::~Book()
{
}
void Book::changeName(char* n)
{
	cout << name << " -> " << n << "�� �̸� �ٲ�" << endl;
	strcpy(name, n);
}
void Book::addPoint(int p)
{
	point = point*pointnum + p;
	pointnum += 1;
	point /= pointnum;
	cout << "����(" << p << ") �߰�, �������(" << point << ")" << endl;
}
void Book::addBook()
{
	booknum++;
	cout << name << ":��� �ϳ� �߰�" << endl;
}
void Book::releaseBook()
{
	if(booknum==0)
		cout << name << ":����� ���� ��� �Ұ�!!!" << endl;
	else
	{
		booknum--;
		cout << name << ":��� �ϳ� ����" << endl;
	}
}
void Book::printInfo()
{
	cout << name << ":" << "����(" << point << "), ����(" << price << "), ���(" << booknum << ")" << endl;
}