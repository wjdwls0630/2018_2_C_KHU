#include "StoreManager.h"
int main()
{
	StoreManager KHB;
	Book book1("Peter Pan", 3000, 0, 0, 1);
	KHB.stockUpBook(book1);
	KHB.stockUpBook(Book("Bible", 50000, 75, 2, 5));
	Book batchBook[2] = { Book("Don Quixote",3000,90,4,2),Book("Moby Dick",200,45,2,3) };
	KHB.stockUpBook(batchBook, 2);
	KHB.printStock();
	return 0;
}