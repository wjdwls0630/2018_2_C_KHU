#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int Dsize;
	cout << "Enter a size of the array : ";
	cin >> Dsize;
	int* Dary = new int[Dsize];
	cout << "Enter a first element : ";
	cin >> Dary[0];
	cout << "Enter a second element : ";
	cin >> Dary[1];
	for (int i = 2; i < Dsize; i++)
		*(Dary + i) = *(Dary + i - 1) + *(Dary + i - 2);
	for (int j = 0; j < Dsize; j++)
		cout << setw(4) << Dary[j];
	cout << endl;
	delete[] Dary;
	return 0;
}