#include<iostream>
#include<iomanip>
using namespace std;
int** buildTable(int rowNum, int columnSizeAry[])
{
	int** table;
	table = new int* [rowNum + 1];
	int row;
	for (row = 0; row < rowNum; row++)
	{
		int tmpColSize = columnSizeAry[row];
		cout << "Size of column in row " << row + 1 << ": " << tmpColSize << endl;
		table[row] = new int[tmpColSize + 1];
		table[row][0] = tmpColSize;
	}
	table[row] = NULL;
	return table;
}
void fillTable(int** table)
{
	cout << "For each row enter a eumber";
	int row = 0;
	while (table[row] != NULL)
	{
		cout << "\n row " << row + 1 << " (" << table[row][0] << " integers) ========> ";
		for (int i = 1; i < table[row][0]+1; i++)
			cin >> table[row][i];
		row++;
	}
}
void printTable(int** table)
{
	cout << "\n Print Array => " << endl;
	int row = 0;
	while(table[row] != NULL)
	{
		for (int i = 1; i < table[row][0] + 1; i++)
			cout << setw(10) << table[row][i];
		cout << endl;
		row++;
	}
}
int main()
{
	int nRows = 3;
	int columnSizeAry[] = { 2,5,1 };
	int** table = buildTable(nRows, columnSizeAry); // Table�� ���� ������ ������
	fillTable(table); // Table ä���
	printTable(table); // Table ����ϱ�
	for (int i = 0; i<columnSizeAry[i] + 1; i++)
		delete[] table[i];
	delete[] table;
	return 0;
}