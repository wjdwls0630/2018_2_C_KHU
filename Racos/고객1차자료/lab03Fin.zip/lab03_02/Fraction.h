class CFraction
{
private:
	int m_nNumerator;
	int m_nDenominator;
public:
	CFraction(void); // ������
	void store(int nNumber, int nDenom);
	void print(void) const;
};