class SmartPhone
{
private:
	char name[20];
	int mem_size;
	void initialize();
	void savename(char* phonename);
public:
	SmartPhone(char phonename[], int size);
	SmartPhone();
	void changeMemSize(int nMemSize);
	void changeOSName(char name[]);
	void print();
};