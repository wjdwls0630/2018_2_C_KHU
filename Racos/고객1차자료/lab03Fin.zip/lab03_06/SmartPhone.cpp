#include<iostream>
#include "SmartPhone.h"
using namespace std;
SmartPhone::SmartPhone(char phonename[], int size)
{
	initialize();
	savename(phonename);
	mem_size = size;
}
SmartPhone::SmartPhone()
{
	initialize();
	mem_size = 0;
}
void SmartPhone::changeMemSize(int nMemSize)
{
	mem_size = nMemSize;
}
void SmartPhone::changeOSName(char name[])
{
	savename(name);
}
void SmartPhone::print()
{
	for (int i = 0; i < 20; i++)
		cout << name[i];
	cout << endl;
	cout << mem_size << "Byte" << endl;
}
void SmartPhone::initialize() // �ʱ�ȭ
{
	for (int i = 0; i < 20; i++)
		name[i] = 0;
}
void SmartPhone::savename(char* phonename)
{
	int count = 0;
	while (phonename[count]) // NULL�� �Ǳ� ������ �ݺ����� ������.
	{
		name[count] = phonename[count];
		count++;
	}
}