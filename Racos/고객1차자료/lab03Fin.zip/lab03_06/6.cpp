#include<iostream>
#include<iomanip>
#include"SmartPhone.h"
using namespace std;
void getPhone(char strName[], int& nMemsize)
{
	cout << "Please enter the Phone Name" << setw(6) << ": ";
	cin >> strName;
	cout << "Please enter the Memory Size" << setw(5) << ": ";
	cin >> nMemsize;
}
int main()
{
	cout << "This program creates SmartPhones" << endl;
	char strName[20] = { 0 };
	int nMemSize = 0;
	getPhone(strName, nMemSize);
	SmartPhone TomPhone(strName, nMemSize);
	TomPhone.print();
	SmartPhone MyPhone;
	MyPhone.print();
	getPhone(strName, nMemSize);
	MyPhone.changeOSName(strName);
	MyPhone.changeMemSize(nMemSize);
	MyPhone.print();
	cout << endl << "Thank you for using Smart Phones." << endl;
	return 0;
}