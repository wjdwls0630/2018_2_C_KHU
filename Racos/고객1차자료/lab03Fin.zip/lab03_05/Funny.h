class CFunny
{
private:
	int m_nNum;
public:
	CFunny(int nNum);
	~CFunny(void);
	void Print(void) const;
};