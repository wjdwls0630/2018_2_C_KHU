#include<iostream>
#include<iomanip>
#include"Fraction.h"
using namespace std;
void getData(int& nNumer, int& nDenom)
{
	cout << "Please enter the numeratot" << setw(5) << ": ";
	cin >> nNumer;
	cout << "Please enter the denumeratot" << setw(3) << ": ";
	cin >> nDenom;
}
void getData(int& nNumer)
{
	cout << "Please enter the numeratot" << setw(5) << ": ";
	cin >> nNumer;
}
int main()
{
	cout << "This program creates a fraction." << endl;
	int nNumer = 0, nDenom = 0;
	CFraction fr1;
	getData(nNumer, nDenom);
	fr1.store(nNumer, nDenom);
	cout << "fr1 contains : ";
	fr1.print();
	getData(nNumer);
	CFraction fr2 = CFraction(nNumer);
	cout << "fr2 contains : ";
	fr2.print();
	getData(nNumer, nDenom);
	CFraction fr3;
	fr3.store(nNumer, nDenom);
	cout << "fr3 contains : ";
	fr3.print();
	CFraction fr4 = CFraction(fr3);
	cout << "fr4 contains : ";
	fr4.print();
	return 0;
}