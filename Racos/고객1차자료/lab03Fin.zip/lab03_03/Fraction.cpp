#include<iostream>
#include "Fraction.h"
using namespace std;
CFraction::CFraction(void)
{
	m_nNumerator = 0;
	m_nDenominator = 1;
} // public�� �ִ� ������ ����(������ �ʱ�ȭ)
CFraction::CFraction(int nNumer)
{
	m_nNumerator = nNumer;
	m_nDenominator = 1;
}
CFraction::CFraction(int nNumer, int nDenom)
{
	m_nNumerator = nNumer;
	m_nDenominator = nDenom;
}
CFraction::CFraction(const CFraction& fr)
{
	m_nNumerator = fr.m_nNumerator;
	m_nDenominator = fr.m_nDenominator;
}
void CFraction::store(int nNumber, int nDenom)
{
	m_nNumerator = nNumber;
	m_nDenominator = nDenom;
} // ����
void CFraction::print(void) const
{
	cout << m_nNumerator << "/" << m_nDenominator << endl;
}// ����Լ�
CFraction::~CFraction()
{

}