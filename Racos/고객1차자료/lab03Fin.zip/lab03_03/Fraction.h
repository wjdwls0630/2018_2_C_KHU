class CFraction
{
private:
	int m_nNumerator;
	int m_nDenominator;
public:
	CFraction(void); // ������
	CFraction(int nNumer);
	CFraction(int nNumer, int nDenom);
	CFraction(const CFraction &fr);
	void store(int nNumber, int nDenom);
	void print(void) const;
	~CFraction();
};