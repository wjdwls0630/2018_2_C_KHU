#include <iostream>
using namespace std;

template <class TYPE, class KEY>
int search (TYPE arr[], KEY key, int size)
{
	int index = 0;
	while ( index < size )
	{
		if ( key != arr[index].key )
			index++;
		else
			return index;
	}
	return -1;
}

struct sBox {
	int key;
	int age;
	float salary;
};

void main()
{
	sBox arr[3] = { {5, 32, 3.23f}, {2, 48, 5.18f}, {7, 60, 6.01f} };

	int idx = search(arr, 2, 3);

	if( idx >= 0 ){
		cout << "Key : " << arr[idx].key << endl;
		cout << "Age : " << arr[idx].age << endl;
		cout << "Salary : " << arr[idx].salary << endl;
		cout << "found at location : " << idx << endl;
	}else{
		cout << "Can not find" << endl;
	}
}
