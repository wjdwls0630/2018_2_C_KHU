
#include <iostream>
#include <iomanip>
using namespace std;

template <class TYPE>
class smartAry
{
private:
	TYPE* m_ptr;
	int arySize;

public:
	smartAry(int size);
	~smartAry() { delete [] m_ptr;}
	int GetSize(){ return arySize; }

	TYPE& operator[] (int idx )
	{
		return m_ptr[idx];
	}
};

template <class TYPE>
smartAry<TYPE>::smartAry(int size)
{
	m_ptr = new TYPE[size];
	arySize = size;
}

void main()
{
	smartAry<int> arr1(4);
	arr1[0] = 1; arr1[1] = 4;
	for(int i=0; i<arr1.GetSize(); i++)
		cout << arr1[i] << endl;

	smartAry<double> arr2(4);
	arr2[0] = 5.5; arr2[3] = 3.14;

	for(int i=0; i<arr2.GetSize(); i++)
		cout << arr2[i] << endl;
}
