#include <sstream>
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main()
{
	cout << "[Output String Stream Example]" << endl;
	ostringstream ssOut;
	ssOut << "Year: " << 2012 << endl << "Month: " << 6 << endl << "Day: " << 14 << endl;
	cout << ssOut.str();

	cout << endl << "[Input String Stream Example]" << endl;
	string today = "Year: 2012 Month: 6 Day: 4";
	istringstream ssIn(today);

	string year, month, day;
	int intYear, intMonth, intDay;
	ssIn >> year;
	ssIn >> intYear;
	ssIn >> month >> intMonth >> day >> intDay;
	cout << year << " " << intYear << endl 
		<< month << " " << intMonth << endl 
		<< day << " " << intDay << endl;
		
	return 0;
}