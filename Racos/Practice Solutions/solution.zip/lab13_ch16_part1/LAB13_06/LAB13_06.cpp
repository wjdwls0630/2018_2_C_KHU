#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

void buildFile(fstream& fsData);
void printFile(fstream& fsData);
void randomPrint(fstream& fsData);

int main()
{
	fstream fsData;
	buildFile(fsData);
	printFile(fsData);
	randomPrint(fsData);
	return 0;
}

void buildFile(fstream& fsData)
{
	fsData.open("LAB13_06.dat", ios::in | ios::out | ios::trunc | ios::binary);

	if(!fsData)
	{
		cerr << "Error opening file for writing" << endl;
		exit(100);
	}

	for(int i=1; i<=10; i++)
	{
		int data;
		data = i * i;
		fsData.write((char*)&data, sizeof(int));
	}
}

void printFile(fstream& fsData)
{
	cout << "File contents in sequential order." << endl;
	fsData.seekg(0L, ios::beg);
	int data;
	int recNum = 0;

	while(fsData.read((char*)&data, sizeof(int)))
		cout << "Record " << setw(4) << recNum++ << " ==> " << setw(4) << data << endl;
	fsData.clear();
}

void randomPrint(fstream& fsData)
{
	cout << "\nFile contents in random sequence." << endl;

	int data;
	int randSeek;
	for(int i=0; i<10; i++)
	{
		randSeek = (rand() % 10);
		fsData.seekg(sizeof(int) * randSeek, ios::beg);
		fsData.read((char*)&data, sizeof(int));

		cout << "Record " << setw(4) << randSeek << " ==> " << setw(4) << data << endl;
	}
	fsData.close();
}