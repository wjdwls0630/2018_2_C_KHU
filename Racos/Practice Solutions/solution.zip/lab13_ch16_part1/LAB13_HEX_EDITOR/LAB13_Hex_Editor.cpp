
#include <fstream>
using namespace std;

int main()
{
	int aInt = 768;
	char aChar = 'A';
	// text file
	ofstream fsTextOut("data.txt"); // text mode
	fsTextOut << aInt << aChar;
	fsTextOut.close();
	
	// binary file
	ofstream fsBinOut("data.bin", ios::out|ios::binary); // binary mode
	fsBinOut.write((char*)&aInt, sizeof(int));
	fsBinOut.write(&aChar, sizeof(char));
	fsBinOut.close();

	return 0;
}