class Morse
{
private:
	bool convert( string& str1, int col, string& str2);

public:
	string encode( string& inStr );
	string decode( string& inStr );
};