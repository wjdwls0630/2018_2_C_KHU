using namespace std ;

class Error
{
public:
	virtual void printMessage()
	{
		cout << "**Error : type Error\n" ; 
	}
};
class Arithmetic: public Error
{
public:
	virtual void printMessage()
	{
		cout << "**Error : type Arithmetic\n" ; 
	}
};
class DivbyZero : public Arithmetic
{
public:
	virtual void printMessage()
	{
		cout << "**Error : 100 type DivbyZero\n" ; 
	}
};
class DivbyNeg : public Arithmetic
{
public:
	virtual void printMessage()
	{
		cout << "**Error : 101 type DivbyNeg\n" ; 
	}
};
class BadOperator : public Arithmetic
{
public:
	virtual void printMessage()
	{
		cout << "**Error : 102 invalid operator\n" ; 
	}
};
