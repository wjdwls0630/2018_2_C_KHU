class Base
{
protected:
	int m_val1;
	int m_val2;
public:
	Base(int val1, int val2);
	void printSum() const;
};

