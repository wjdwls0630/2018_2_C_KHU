#include <iostream>
using namespace std;

#include "Derived.h"

int main()
{
	// ��ĳ����
	cout << "[Upcasting Example]" << endl << endl;
	
	Base* basePtr = new Base(10, 20);
	Derived* derPtr = new Derived(30, 50);	
	basePtr->printSum();
	derPtr->printSum();
	
	basePtr = static_cast<Base*>(derPtr);
	cout << "After upcasting / Derived -> Base.." << endl;

	basePtr->printSum();
	derPtr->printSum();
	
	// �ٿ�ĳ���� ���� 1
	cout << endl << "[Downcasting Example1]" << endl << endl;
	Base* basePtr2 = new Derived(10, 20);
	Derived* derPtr2 = new Derived(30, 50);	
	basePtr2->printSum();
	derPtr2->printSum();

	cout << "After downcasting / Base -> Derived.." << endl;
	derPtr2 = static_cast<Derived*>(basePtr2);
	
	basePtr2->printSum();
	derPtr2->printSum();

	// �ٿ�ĳ���� ���� 2
	cout << endl << "[Downcasting Example2]" << endl << endl;
	Base* basePtr3 = new Base(10, 20);
	Derived* derPtr3 = new Derived(30, 50);	
	basePtr3->printSum();
	derPtr3->printSum();

	cout << "After downcasting / Base -> Derived.." << endl;
	derPtr3 = static_cast<Derived*>(basePtr3);
	
	basePtr3->printSum();
	derPtr3->printSum();
	
	return 0;
}


