class Subtract
{
private:
	double result;
public:
	Subtract(double val1, double val2);
	void sub_result();
};