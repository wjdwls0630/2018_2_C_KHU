class Add
{
private:
	double result;
public:
	Add(double val1, double val2);
	void add_result();
};