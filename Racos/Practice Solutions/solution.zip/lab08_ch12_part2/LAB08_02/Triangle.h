#include "Polygons.h"

class Triangle : public Polygons
{
private:
	double width;
	double height;

public:
	Triangle(double inputVal1, double inputVal2) : width(inputVal1),height(inputVal2)  {};	
	void calcArea();
	void calcPerimeter();
	void printArea() const;
	void printPerimeter() const;
};