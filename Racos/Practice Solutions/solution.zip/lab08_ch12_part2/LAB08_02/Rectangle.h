#include "Polygons.h"

class Rectangle : public Polygons
{
private:
	double sideA;
	double sideB;

public:
	Rectangle(double inputVal1, double inputVal2) : sideA(inputVal1), sideB(inputVal2) {};
	void calcArea();
	void calcPerimeter();
	void printArea() const;
	void printPerimeter() const;
};