#ifndef POLYGONS_H
#define POLYGONS_H

class Polygons
{
protected:
	double area;
	double perimeter;

public:
	Polygons() {};
	~Polygons() {};
	virtual void printArea() const = 0;
	virtual void printPerimeter() const = 0;
};

#endif