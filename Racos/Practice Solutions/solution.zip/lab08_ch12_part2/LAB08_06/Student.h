#include "Score.h"

class Student
{
private:
	char* m_name;
	int m_ID;
	Score m_score;

public:
	Student() {};
	Student(char* name, int ID, Score score) : m_ID(ID), m_score(score)
	{
		int temp = strlen(name)+1;
		m_name = new char[temp];
		for(int i=0; i<temp; i++)
			m_name[i] = name[i];
	};
	void setVal(char*, int, Score);
	void printVal();
};
