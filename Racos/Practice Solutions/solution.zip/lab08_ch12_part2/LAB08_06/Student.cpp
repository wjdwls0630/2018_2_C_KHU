#include <iostream>
using namespace std;

#include "Student.h"

void Student::setVal(char* name, int ID, Score score)
{
	int temp = strlen(name)+1;
	m_name = new char[temp];
	for(int i=0; i<temp; i++)
		m_name[i] = name[i];
	m_ID = ID;
	m_score = score;
}

void Student::printVal()
{
	cout << "Name : " << m_name << endl;
	cout << "Student ID : " << m_ID << endl;
	m_score.printScore();
}