class Score
{
private:
	int score_KOR;
	int score_ENG;
	int score_MATH;
	int score_SCI;

public:
	Score() {};
	Score(int val1, int val2, int val3, int val4) : score_KOR(val1), score_ENG(val2), score_MATH(val3), score_SCI(val4) {};
	void setScore(int, int, int, int);
	Score getScore();
	void printScore();
};