#include <iostream>
using namespace std;

#include "Score.h"

void Score::setScore(int val1, int val2, int val3, int val4) 
{
	score_KOR = val1;
	score_ENG = val2;
	score_MATH = val3;
	score_SCI = val4;
}

Score Score::getScore()
{
	return *this;
}

void Score::printScore()
{
	cout << "Score(KOR, ENG, MATH, SCI) : " << score_KOR << ", " << score_ENG << ", " << score_MATH << ", " << score_SCI << endl; 
}