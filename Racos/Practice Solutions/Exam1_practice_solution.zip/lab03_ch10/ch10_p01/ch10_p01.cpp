#include <iostream>
using namespace std;

#include "Fraction.h"

int main()
{
	CFraction fraction;
	cout << "The fraction object was created successfully." << endl;
 
	return 0;
}