#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
int main() {
  ifstream ifs;
  ifs.open("temp_UNIX.txt");
  double temp;
  std::vector<double> temp_v;
  int i=0;
  while (!ifs) {
    ifs>>temp;
    temp_v[i]=temp;
    i++;
  }
  double smallest=1000;
  int small_index=0;
  for (int i = 0; i < temp_v.size(); i++) {
    if (temp_v[i]<smallest) {
      smallest=temp_v[i];
      small_index=i;
    }
  }
  temp_v[small_index]=1000;
  double smallest_2=1000;
  int small_index_2=0;
  for (int i = 0; i < temp_v.size(); i++) {
    if (temp_v[i]<smallest_2) {
      smallest_2=temp_v[i];
      small_index_2=i;
    }
  }

  std::cout << "Coldest: " <<smallest<< '\n';
  std::cout << "Second coldest: " <<smallest_2<< '\n';

  ifs.close();


  return 0;
}
