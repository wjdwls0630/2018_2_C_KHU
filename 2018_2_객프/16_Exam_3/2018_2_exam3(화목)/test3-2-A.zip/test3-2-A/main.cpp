#include "application.h"
int main()
{
	Application photoManager;
	photoManager.Run();

	return 1;
}
