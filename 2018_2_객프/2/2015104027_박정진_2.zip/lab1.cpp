#include <iostream>

int main() {
  std::cout << "Hello Wolrd" << '\n';
  return 0;
}
