#include <iostream>

int main() {
  int num1,num2,num3;

  std::cin >> num1;
  std::cout <<num1<<" X 1 = " <<num1*1<< '\n';
  std::cout <<num1<<" X 2 = " <<num1*2<< '\n';
  std::cout <<num1<<" X 3 = " <<num1*3<< '\n';
  std::cout <<num1<<" X 4 = " <<num1*4<< '\n';
  std::cout <<num1<<" X 5 = " <<num1*5<< '\n';
  std::cout <<num1<<" X 6 = " <<num1*6<< '\n';
  std::cout <<num1<<" X 7 = " <<num1*7<< '\n';
  std::cout <<num1<<" X 8 = " <<num1*8<< '\n';
  std::cout <<num1<<" X 9 = " <<num1*9<< '\n';

  std::cin >> num2;
  std::cout <<num2<<" X 1 = " <<num2*1<< '\n';
  std::cout <<num2<<" X 2 = " <<num2*2<< '\n';
  std::cout <<num2<<" X 3 = " <<num2*3<< '\n';
  std::cout <<num2<<" X 4 = " <<num2*4<< '\n';
  std::cout <<num2<<" X 5 = " <<num2*5<< '\n';
  std::cout <<num2<<" X 6 = " <<num2*6<< '\n';
  std::cout <<num2<<" X 7 = " <<num2*7<< '\n';
  std::cout <<num2<<" X 8 = " <<num2*8<< '\n';
  std::cout <<num2<<" X 9 = " <<num2*9<< '\n';

  std::cin >> num3;
  std::cout <<num3<<" X 1 = " <<num3*1<< '\n';
  std::cout <<num3<<" X 2 = " <<num3*2<< '\n';
  std::cout <<num3<<" X 3 = " <<num3*3<< '\n';
  std::cout <<num3<<" X 4 = " <<num3*4<< '\n';
  std::cout <<num3<<" X 5 = " <<num3*5<< '\n';
  std::cout <<num3<<" X 6 = " <<num3*6<< '\n';
  std::cout <<num3<<" X 7 = " <<num3*7<< '\n';
  std::cout <<num3<<" X 8 = " <<num3*8<< '\n';
  std::cout <<num3<<" X 9 = " <<num3*9<< '\n';

  return 0;
}
