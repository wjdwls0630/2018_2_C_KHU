#include <iostream>
#include <string>
int main() {
  std::string UserName;
  std::cout << "당신의 이름을 입력하세요 : ";
  std::cin >> UserName;
  std::cout << UserName << '\n';
  return 0;
}
