#pragma once
#include <string>
#include <iomanip>
#include <iostream>
#include <stdio.h>
using namespace std; 

class photoType {
private:
	string name;
	string event;
public:
	void DisplayRecord() {
		cout << "\n name: " << name << "		event:  " << event << endl;
	}
	photoType(string nm, string en) {
		name = nm; event = en;
	}
	
	photoType& operator=(const photoType& other) 
	{
		if (this != &other) { 
			name=other.name;
			event = other.event;
		}
		return *this;
	}
};


	class baseClass {
	protected:
		static	vector<photoType> master;
		static int length;
	public:
		void AddMaster(photoType item) {
			if (length < 100) { master.push_back(item); length++; }
		}
	};

vector<photoType> baseClass::master;
int baseClass:: length = 0;

class eventType: public baseClass {
	private:
		string name;
		vector<int> list;
	public:
		eventType(string nm) {
			name = nm; list.clear();
		}
		eventType() { }

		void SetName(string in) { name = in; list.clear(); }
		void AddPhoto(int in) {
			list.push_back(in);
								}
		void DisplayDetail() {
			for (int i=0; i<list.size(); i++)
				master[list[i]].DisplayRecord();
		}
};




class appClass :public baseClass {
private:
	vector< eventType>  eList;
public:
	void GenerateEventList() {  
		eventType temp;
		temp.SetName("2017 ������"); temp.AddPhoto(0); temp.AddPhoto(2); temp.AddPhoto(4);
		eList.push_back(temp);
		temp.SetName("2016 �̱�����"); temp.AddPhoto(1); temp.AddPhoto(3);
		eList.push_back(temp);
		temp.SetName("2018 ����"); temp.AddPhoto(5);
		eList.push_back(temp);
	}
	void GeneratePhotoList() {// fill master
		photoType p0("���� 0", "2017 ������");
		photoType p1("���� 1", "2016 �̱�����");
		photoType p2("���� 2", "2017 ������");
		photoType p3("���� 3", "2016 �̱�����");
		photoType p4("���� 4", "2017 ������");
		photoType p5("���� 5", "2018 ����");
		AddMaster(p0);		AddMaster(p1);
		AddMaster(p2);		AddMaster(p3); 
		AddMaster(p4);		AddMaster(p5);
	}
	void DisplayEventDetailInfo() {
		for (int i = 0; i < eList.size(); i++) {
			cout << "\n << Event " << setw(3) << i <<"  photo list >> \n";
			eList[i].DisplayDetail();
		}
	}


};