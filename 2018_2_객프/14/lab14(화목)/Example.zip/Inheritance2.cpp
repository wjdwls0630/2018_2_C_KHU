#include <iomanip>
#include <stdio.h>
#include <fstream>
#include <vector>
#include "inheritance2.h"
using namespace std; 

int main() {
	appClass app;
	//Generate photo list
	app.GeneratePhotoList();
	// generate event list
	app.GenerateEventList();
	// access the mater list by using the index in the event list
	app.DisplayEventDetailInfo();

}
