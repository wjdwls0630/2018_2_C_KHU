#include<iostream> 
#include <stdio.h>
#include <vector>
#include <iomanip>
#include <fstream>
using namespace std;

void VectorTesting();
void FunctionPointer();
int main() {
	//FunctionPointer();
	VectorTesting();
	cout << " Enter 0 for stop -->";
	int indx;
	cin >> indx;
	return 1;
}


void DisplayVector(vector<int> list, int num) {
	cout << "\n Vector Display " << setw(3) << num << endl;
	for (unsigned int i = 0; i < list.size(); i++) { cout << list[i] << " , "; }
	cout << endl;

	for (vector<int>::size_type i = 0; i < list.size(); i++) { cout << list.at(i) << " , "; }
	cout << endl;

	for (vector<int>::size_type i = 0; i < list.size(); i++) { cout << list[i] << " , "; }
	cout << endl;
	
	for (int elem : list) cout << elem << " , ";
	cout << endl;
	for (vector<int>::iterator it = list.begin(); it != list.end(); it++) { cout << *it << " , "; }
	cout << endl;
}

void VectorTesting() {
	vector<int> list(10);
	for (int i = 0; i < 5; i++) list[i] = i;
	DisplayVector(list, 1);
	vector<int> list2;
	list2.clear();
	for (int i = 0; i < 5; i++) list2.push_back(i + 100);
	DisplayVector(list2, 2);
}



int add(int a, int b) { return a + b; }
int sub(int a, int b) { return a - b; }
int mul(int a, int b) { return a * b; }
int divis(int a, int b) { return (int)(a / b); }
int evaluation(int(*f)(int, int), int a, int b) { return f(a, b); }
void FunctionPointer() {
	int(*func)(int, int);
	func = add;
	cout << func(7, 2) << endl;
	cout << evaluation(&add, 7, 2) << endl;
	cout << evaluation(func, 7, 2) << endl;

	int(*funcA[4])(int, int);
	funcA[0] = add;
	funcA[1] = sub;
	funcA[2] = mul;
	funcA[3] = divis;
	int indx;
	cout << "Enter operation number(0: +, 1: -, 2: *, 3: /";
	cin >> indx;
	cout << evaluation(funcA[indx], 7, 2) << endl;
}

