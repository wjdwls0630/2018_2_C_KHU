#include<iostream>
#include<ctime>
#include <string>
#include <sstream>
#include <iomanip>
#include <stdio.h>
#include <fstream>


#include "ApplicationType.hpp"


int main(){

  ApplicationType App;

  App.Run();

  return 1;
}
